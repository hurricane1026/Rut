#include <stdint.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
using u64=uint64_t; using u32=uint32_t;
inline u32 baseline_date(char* out, u64 now_us) {
    static constexpr const char* kWeek[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static constexpr const char* kMonth[] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    time_t t = static_cast<time_t>(now_us / 1000000ULL);
    struct tm tm;
    if (gmtime_r(&t, &tm) == nullptr) return 0;
    char* p = out;
    auto two = [&](int v) {
        *p++ = static_cast<char>('0' + v / 10);
        *p++ = static_cast<char>('0' + v % 10);
    };
    for (const char* s = kWeek[tm.tm_wday]; *s; ++s) *p++ = *s;
    *p++ = ',';
    *p++ = ' ';
    two(tm.tm_mday);
    *p++ = ' ';
    for (const char* s = kMonth[tm.tm_mon]; *s; ++s) *p++ = *s;
    *p++ = ' ';
    int year = tm.tm_year + 1900;
    *p++ = static_cast<char>('0' + year / 1000);
    *p++ = static_cast<char>('0' + (year / 100) % 10);
    *p++ = static_cast<char>('0' + (year / 10) % 10);
    *p++ = static_cast<char>('0' + year % 10);
    *p++ = ' ';
    two(tm.tm_hour);
    *p++ = ':';
    two(tm.tm_min);
    *p++ = ':';
    two(tm.tm_sec);
    *p++ = ' ';
    *p++ = 'G';
    *p++ = 'M';
    *p++ = 'T';
    return static_cast<u32>(p - out);
}
inline u32 candidate_date(char* out, u64 now_us) {
    // HTTP dates have second precision. Each shard runs on one thread, so
    // reuse that thread's formatted second without sharing mutable state.
    struct DateCache {
        u64 second = 0;
        char bytes[29]{};
        bool valid = false;
    };
    static thread_local DateCache cache{};
    const u64 second = now_us / 1000000ULL;
    if (cache.valid && cache.second == second) {
        __builtin_memcpy(out, cache.bytes, sizeof(cache.bytes));
        return sizeof(cache.bytes);
    }
    static constexpr const char* kWeek[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    static constexpr const char* kMonth[] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    time_t t = static_cast<time_t>(second);
    struct tm tm;
    if (gmtime_r(&t, &tm) == nullptr) return 0;
    char* p = out;
    auto two = [&](int v) {
        *p++ = static_cast<char>('0' + v / 10);
        *p++ = static_cast<char>('0' + v % 10);
    };
    for (const char* s = kWeek[tm.tm_wday]; *s; ++s) *p++ = *s;
    *p++ = ',';
    *p++ = ' ';
    two(tm.tm_mday);
    *p++ = ' ';
    for (const char* s = kMonth[tm.tm_mon]; *s; ++s) *p++ = *s;
    *p++ = ' ';
    int year = tm.tm_year + 1900;
    *p++ = static_cast<char>('0' + year / 1000);
    *p++ = static_cast<char>('0' + (year / 100) % 10);
    *p++ = static_cast<char>('0' + (year / 10) % 10);
    *p++ = static_cast<char>('0' + year % 10);
    *p++ = ' ';
    two(tm.tm_hour);
    *p++ = ':';
    two(tm.tm_min);
    *p++ = ':';
    two(tm.tm_sec);
    *p++ = ' ';
    *p++ = 'G';
    *p++ = 'M';
    *p++ = 'T';
    const u32 len = static_cast<u32>(p - out);
    if (len == sizeof(cache.bytes)) {
        __builtin_memcpy(cache.bytes, out, sizeof(cache.bytes));
        cache.second = second;
        cache.valid = true;
    }
    return len;
}
static uint64_t ns() { timespec t; clock_gettime(CLOCK_MONOTONIC,&t);return uint64_t(t.tv_sec)*1000000000ULL+t.tv_nsec; }
int main(int argc,char**argv) {
 if(argc!=3)return 2;
 u32(*f)(char*,u64)=argv[1][0]=='c'?candidate_date:baseline_date;
 bool miss=argv[2][0]=='m';
 const u64 n=miss?1000000ULL:5000000ULL;
 char out[29];u64 checksum=0;
 const u64 before=ns();
 for(u64 i=0;i<n;i++){u64 now=1893456000000000ULL+(miss?i*1000000ULL:i%1000000ULL);if(f(out,now)!=29)return 3;checksum+=static_cast<unsigned char>(out[i%29]);}
 const u64 elapsed=ns()-before;
 printf("{\"variant\":\"%s\",\"mode\":\"%s\",\"iterations\":%llu,\"ns_per_op\":%.4f,\"checksum\":%llu}\n",argv[1],argv[2],(unsigned long long)n,double(elapsed)/n,(unsigned long long)checksum);
}
