import json,subprocess,sys,shlex,os
from pathlib import Path
root=Path(__file__).resolve().parent
variant=sys.argv[1]; group=sys.argv[2]; size=sys.argv[3] if len(sys.argv)>3 else "4093"
out=root/group
out.mkdir(exist_ok=False)
subprocess.run(["chcon","-t","container_file_t",str(out)],check=True)
argv=["python3","/home/hurricane/private/code/rut-perf-runtime-next/scripts/nginx_benchmark/run.py","--rut",str(root/(variant+"-bin")/"rut"),"--converter",str(root/(variant+"-bin")/"rut-nginx-convert"),"--wrk","/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/wrk-boringssl-src2","--output",str(out),"--server-cpu","2","--origin-cpu","3","--client-cpus","4,5","--static-profile","converter-return","--body-size",size,"--keepalive-header","implicit","--scenarios","static-keepalive","--concurrency","1","128","--warmup","2","--duration","15","--repeats","1","--first-engine", sys.argv[4] if len(sys.argv)>4 else "nginx","--front-port","8417","--origin-port","8517"]
(root/(group+"-command.json")).write_text(json.dumps(argv,indent=2))
with (root/(group+".log")).open("w") as log:
 result=subprocess.run(["sg","docker","-c",shlex.join(argv)],stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy())
print(group,result.returncode,flush=True)
sys.exit(result.returncode)
