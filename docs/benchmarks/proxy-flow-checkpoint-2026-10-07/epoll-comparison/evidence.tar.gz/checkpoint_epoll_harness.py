import contextlib,importlib.util,sys,os,json
from pathlib import Path
root=Path('/tmp/rut-window-study');source=root/'src/scripts/nginx_benchmark/run.py';sys.path.insert(0,str(source.parent))
spec=importlib.util.spec_from_file_location('backend_benchmark',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.engine_order=lambda first,rep: ('epoll','iouring-checkpoint') if rep%2 else ('iouring-checkpoint','epoll')
original=m.Harness.frontend;active={}
@contextlib.contextmanager
def frontend(self,engine,work,label):
 artifact=Path('/home/hurricane/private/code/rut-performance-checkpoints/proxy-flow-20261007')
 self.args.rut=artifact/('new-epoll/rut' if engine=='epoll' else 'old-iouring/rut')
 for key in list(os.environ):
  if key.startswith('RUT_STUDY_'):os.environ.pop(key,None)
 if engine!='epoll':os.environ.update(json.loads((artifact/'old-candidate-env.json').read_text()))
 with original(self,engine,work,label) as pid:
  log=(self.out/(label+'-server.log')).read_text();expected='Backend: epoll' if engine=='epoll' else 'Backend: io_uring'
  assert expected in log,(expected,log)
  active.update(pid=pid,label=label,out=self.out)
  try:yield pid
  finally:active.clear()
m.Harness.frontend=frontend
usage=m.proc_usage
def profile(pid):
 result=usage(pid);fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
 row=dict(label=active['label'],role='server' if pid==active['pid'] else 'origin',user_ticks=int(fields[11]),kernel_ticks=int(fields[12]),minor_faults=int(fields[7]),clock_ticks=os.sysconf('SC_CLK_TCK'))
 for path,tag in [('/proc/net/snmp','Tcp:'),('/proc/net/netstat','TcpExt:')]:
  lines=Path(path).read_text().splitlines()
  for i in range(len(lines)-1):
   if lines[i].startswith(tag) and lines[i+1].startswith(tag):
    row[tag.rstrip(':')]=dict(zip(lines[i].split()[1:],map(int,lines[i+1].split()[1:])))
    break
 with (active['out']/'cpu-split.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 return result
m.proc_usage=profile
sys.exit(m.main())
