import subprocess,sys,os,json,time,threading,datetime,hashlib
from pathlib import Path
r=Path('/tmp/rut-window-study');prefix='adaptive-cache-close-accept-c1-20261007';binary=r/'bin-adaptive-cache-close/rut'
plan=[('control-a',False,False),('both-a',True,True),('both-b',True,True),('control-b',False,False)]
(r/(prefix+'-plan.json')).write_text(json.dumps(dict(plan=plan,measurement_seconds=10,warmup_seconds=5,idle_bulk_cache_bytes=16*1024*1024,byte_window_kib=0,concurrency=1,whole_node_vector=True,binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),indent=2))
stop=threading.Event();current={'run':None};observations=[]
def monitor():
 while not stop.is_set():
  active=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    comm=(p/'comm').read_text().strip()
    if comm not in {'rustc','cargo','clang','clang++','gcc','g++','cc1','cc1plus'}:continue
    fields=(p/'stat').read_text().rsplit(')',1)[1].split()
    if fields[0]=='Z':continue
    active.append(dict(pid=int(p.name),comm=comm,state=fields[0],cpu=int(fields[36])))
   except (OSError,ValueError,IndexError):pass
  observations.append(dict(time=time.time(),run=current['run'],compilers=active))
  stop.wait(1)
t=threading.Thread(target=monitor);t.start();code=0
try:
 for suffix,align,small in plan:
  name=prefix+'-'+suffix;current['run']=name;env=os.environ.copy()
  for k in ['RUT_STUDY_ALIGN_RECV','RUT_STUDY_SMALL_TAIL','RUT_STUDY_HEADER_CORK','RUT_STUDY_PUBLISHED_CORK','RUT_STUDY_RECYCLE_TWO','RUT_STUDY_PHYSICAL_BLOCK_LIMIT','RUT_STUDY_SMALL_BODY_CORK','RUT_STUDY_BODY_POOL_REUSE']:env.pop(k,None)
  env['RUT_STUDY_BODY_POOL_LOG']='1'
  env['RUT_STUDY_BODY_POOL_REUSE']='1'
  env['RUT_STUDY_BULK_CACHE_MIB']='16'
  env.pop('RUT_STUDY_RECV_STEP_KIB',None)
  env.pop('RUT_STUDY_ZC_PUSH',None)
  env.pop('RUT_STUDY_SELECTIVE_VECTOR',None)
  env.pop('RUT_STUDY_SEND_ZC',None)
  env['RUT_STUDY_SELECTIVE_VECTOR']='1'
  env['RUT_STUDY_DIRECT_CLOSE_ONLY']='1'
  env.pop('RUT_STUDY_BODY_ALIGNMENT',None)
  env.pop('RUT_STUDY_ADAPTIVE_CACHE',None)
  if small:env['RUT_STUDY_ADAPTIVE_CACHE']='1'
  env.pop('RUT_STUDY_DIRECT_BODY_SEND',None)
  if align:env['RUT_STUDY_DIRECT_BODY_SEND']='1'
  
  code=subprocess.run([sys.executable,str(r/'default_run.py'),name,'0','10','1',str(binary)],env=env).returncode
  if code:break
finally:
 stop.set();t.join();(r/(prefix+'-load-monitor.json')).write_text(json.dumps(observations,indent=2))
sys.exit(code)
