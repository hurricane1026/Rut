#include "rut/runtime/io_uring_backend.h"

#include "core/expected.h"
#include "rut/runtime/callbacks.h"
#include "rut/runtime/connection.h"
#include "rut/runtime/error.h"
#include "rut/runtime/io_uring_memlock.h"
#include "rut/runtime/response_read_deadline.h"

#include <errno.h>
#include <linux/io_uring.h>
#include <poll.h>
#include <string.h>  // memset
#include <sys/mman.h>
#include <sys/sendfile.h>
#include <sys/socket.h>  // SOCK_NONBLOCK, SOCK_CLOEXEC
#include <sys/syscall.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>

// IORING_OP_CANCEL may not be defined on older kernel headers
#ifndef IORING_OP_ASYNC_CANCEL
#define IORING_OP_ASYNC_CANCEL 14
#endif

#ifndef IORING_ASYNC_CANCEL_ALL
#define IORING_ASYNC_CANCEL_ALL (1U << 0)
#endif

namespace rut {

static bool response_deadline_copy_owner(const Connection& conn, u32 upstream_episode, u32 aux) {
    const bool post_commit =
        conn.response_read_deadline_post_commit_phase != ResponseReadDeadlinePostCommitPhase::None;
    return aux == 0 && conn.fd >= 0 && conn.upstream_fd >= 0 &&
           (conn.state == ConnState::Proxying ||
            (post_commit && conn.state == ConnState::Sending)) &&
           conn.protocol == ConnProtocol::Http11 &&
           (!conn.tls_active || response_read_deadline_tls_complete_get_profile_is_stable(conn)) &&
           conn.h2 == nullptr &&
           (conn.response_read_deadline_state == ResponseReadDeadlineState::Armed ||
            (post_commit &&
             conn.response_read_deadline_state == ResponseReadDeadlineState::BodyComplete)) &&
           conn.response_read_deadline_owner_generation != 0 &&
           conn.response_read_deadline_owner_generation == conn.response_read_deadline_generation &&
           response_read_deadline_owner_is_stable(conn,
                                                  &on_upstream_response<IoUringEventLoop>,
                                                  ResponseReadDeadlineOwnerPhase::ArmedForCopy) &&
           conn.response_read_deadline_upstream_episode == upstream_episode &&
           conn.upstream_episode == upstream_episode && valid_upstream_episode(upstream_episode) &&
           conn.upstream_recv_armed &&
           (conn.on_upstream_recv == &on_upstream_response<IoUringEventLoop> ||
            (post_commit && conn.on_upstream_recv == nullptr)) &&
           !conn.upstream_recv_paused_for_send && !conn.upstream_recv_pause_cancel_pending &&
           !conn.upstream_recv_pause_rearm_pending && !conn.upstream_recv_cancel_inflight &&
           !conn.upstream_retirement_active && conn.upstream_retirement_target_owned == 0 &&
           conn.upstream_retirement_cancel_owned == 0 &&
           conn.upstream_retirement_cancel_retry == 0 && conn.upstream_close_episode == 0 &&
           conn.upstream_close_target_owned == 0 && conn.upstream_close_cancel_owned == 0 &&
           !conn.upstream_close_pause_cancel_owned && conn.idle_return_fd < 0 &&
           conn.idle_return_config == nullptr && !conn.close_after_idle_return &&
           !conn.h2_proxy_recv_draining && !conn.h2_proxy_synth_quarantined;
}

// IORING_OP_NOP result injection (Linux 6.10). Older UAPI headers lack the
// name and the nop_flags alias of the shared per-op flags word (rw_flags); the
// ABI is fixed, and support is probed at runtime.
#ifndef IORING_NOP_INJECT_RESULT
#define IORING_NOP_INJECT_RESULT (1U << 0)
#endif

// Sentinel conn_id for timer events (same value as epoll backend)
static constexpr u32 kTimerConnId = 0xFFFFFE;
// Sentinel conn_id for cancel completions (must not collide with real conn_ids or timer)
static constexpr u32 kCancelConnId = 0xFFFFFD;
// kPauseCancelAux (the pause-cancel completion tag) is defined in io_event.h so the
// event loop can recognize it on IoEvent::aux.

// --- Syscall wrappers (no liburing) ---

static i32 io_uring_setup(u32 entries, struct io_uring_params* p) {
    i32 ret = static_cast<i32>(syscall(__NR_io_uring_setup, static_cast<long>(entries), p));
    return ret >= 0 ? ret : -errno;
}

static i32 io_uring_enter(i32 fd, u32 to_submit, u32 min_complete, u32 flags) {
    i32 ret = static_cast<i32>(
        syscall(__NR_io_uring_enter, fd, to_submit, min_complete, flags, nullptr, 0));
    return ret >= 0 ? ret : -errno;
}

static i32 io_uring_register(i32 fd, u32 opcode, const void* arg, u32 nr_args) {
    i32 ret = static_cast<i32>(syscall(__NR_io_uring_register, fd, opcode, arg, nr_args));
    return ret >= 0 ? ret : -errno;
}

// --- user_data encoding ---
// Layout: [63:32] = auxiliary generation, [31:8] = 24-bit conn_id/sentinel,
// [7:0] = IoEventType. conn_id is still decoded as u32; 24 bits covers every
// live connection id and the io_uring sentinel ids while preserving the full
// u32 HandlerTimer generation used to reject stale timeout CQEs.

u64 IoUringBackend::encode_user_data(u32 conn_id, IoEventType type) {
    return encode_user_data(conn_id, type, 0);
}

u64 IoUringBackend::encode_user_data(u32 conn_id, IoEventType type, u32 aux) {
    return (static_cast<u64>(aux) << 32) | ((static_cast<u64>(conn_id) & 0xFFFFFFu) << 8) |
           static_cast<u64>(type);
}

u64 IoUringBackend::encode_upstream_user_data(u32 conn_id,
                                              IoEventType type,
                                              u32 upstream_episode,
                                              u8 aux) {
    return encode_upstream_event_token({conn_id, type, upstream_episode, aux});
}

void IoUringBackend::decode_user_data(u64 data, u32& conn_id, IoEventType& type) {
    u32 aux = 0;
    decode_user_data(data, conn_id, type, aux);
}

void IoUringBackend::decode_user_data(u64 data, u32& conn_id, IoEventType& type, u32& aux) {
    type = static_cast<IoEventType>(data & 0xFF);
    conn_id = static_cast<u32>((data >> 8) & 0xFFFFFFu);
    aux = static_cast<u32>(data >> 32);
}

void IoUringBackend::decode_user_data(
    u64 data, u32& conn_id, IoEventType& type, u32& aux, u32& upstream_episode) {
    type = static_cast<IoEventType>(data & 0xFFu);
    if (io_event_uses_upstream_episode(type)) {
        conn_id = static_cast<u32>((data >> 8) & kIoUserDataMaxConnId);
        aux = static_cast<u8>(data >> 56);
        upstream_episode = static_cast<u32>((data >> 32) & kIoUserDataMaxUpstreamEpisode);
        UpstreamEventToken token;
        if (decode_upstream_event_token(data, &token)) {
            return;
        }
        // Preserve the upstream type/connection identity, but make malformed
        // tokens unambiguously stale. In particular, do not let episode zero
        // fall through to the legacy decoder and invoke a current callback.
        upstream_episode = kInvalidUpstreamEventEpisode;
        return;
    }
    decode_user_data(data, conn_id, type, aux);
    upstream_episode = 0;
}

// --- SQE helpers ---

io_uring_sqe* IoUringBackend::get_sqe() {
    u32 tail = __atomic_load_n(sq_tail, __ATOMIC_RELAXED);
    u32 head = __atomic_load_n(sq_head, __ATOMIC_ACQUIRE);
    u32 mask = *sq_ring_mask;

    if (tail - head >= sq_ring_entries) {
        return nullptr;  // SQ is full
    }

    io_uring_sqe* sqe = &sq_entries[tail & mask];
    sq_array[tail & mask] = tail & mask;
    return sqe;
}

// get_sqe() for submitters that cannot park the request: when the SQ is full,
// hand the queued SQEs to the kernel (which frees every slot it consumes) and
// retry once, retrying the enter on EINTR. Used by every arm a caller may
// ignore or cannot defer (recvs, sends, connect, accept and its cancel, timers,
// cancels, wait()'s resubmits); callers drop a false return in many places, so a
// miss would leave the connection with nothing armed until a timeout. nullptr
// only when the enter failed (the error is recorded and stops the loop) or the
// kernel consumed nothing.
io_uring_sqe* IoUringBackend::get_sqe_flushing() {
    io_uring_sqe* sqe = get_sqe();
    if (sqe) return sqe;
    if (disable_full_sq_flush) return nullptr;
    if (ring_fd >= 0 && pending > 0) {
        for (;;) {
            const i32 flushed = io_uring_enter(ring_fd, pending, 0, IORING_ENTER_SQ_WAKEUP);
            if (flushed >= 0) {
                pending -= static_cast<u32>(flushed);
                break;
            }
            if (flushed == -EINTR) continue;
            record_enter_error(flushed);
            break;
        }
    }
    return get_sqe();
}

static void sqe_advance_tail(u32* sq_tail) {
    u32 tail = __atomic_load_n(sq_tail, __ATOMIC_RELAXED);
    __atomic_store_n(sq_tail, tail + 1, __ATOMIC_RELEASE);
}

// --- Init ---

core::Expected<void, Error> IoUringBackend::init_send_state_storage(u32 capacity) {
    if (!validate_connection_capacity(capacity))
        return core::make_unexpected(Error::make(EINVAL, Error::Source::Mmap));
    auto downstream = send_state.init(capacity);
    if (!downstream) return core::make_unexpected(downstream.error());
    auto upstream = upstream_send_state.init(capacity);
    if (!upstream) {
        send_state.destroy();
        return core::make_unexpected(upstream.error());
    }
    for (u32 i = 0; i < capacity; i++) {
        send_state[i] = {nullptr, -1, 0, 0, IoEventType::Send, 0, 0};
        upstream_send_state[i] = {nullptr, -1, 0, 0, IoEventType::UpstreamSend, 0, 0};
    }
    connection_capacity = capacity;
    return {};
}

void IoUringBackend::destroy_send_state_storage() {
    connection_capacity = 0;
    upstream_send_state.destroy();
    send_state.destroy();
}

core::Expected<void, Error> IoUringBackend::init(u32 /*shard_id*/, i32 lfd, u32 capacity) {
    last_init_failure_detail = IoUringInitFailureDetail::None;
    if ((connection_capacity != 0 && connection_capacity != capacity) || ring_fd >= 0 ||
        timer_fd >= 0) {
        last_init_failure_detail = IoUringInitFailureDetail::InvalidLifecycle;
        return core::make_unexpected(Error::make(EINVAL, Error::Source::IoUring));
    }
    auto storage = init_send_state_storage(capacity);
    if (!storage) {
        last_init_failure_detail = IoUringInitFailureDetail::SendStateStorage;
        return core::make_unexpected(storage.error());
    }
    listen_fd = lfd;
    // Explicitly init fds to -1: mmap-zeroed memory skips default member initializers,
    // so timer_fd/ring_fd could be 0. If init fails early and calls shutdown(), closing
    // fd 0 (stdin) would be catastrophic.
    ring_fd = -1;
    timer_fd = -1;
    timer_read_armed = false;
    fatal_error.store(0, std::memory_order_relaxed);
    // mmap-zeroed storage skips member initializers; the window array and side
    // table are not allocated yet, so there is nothing to clear.
    downstream_recv_terminal_windows = nullptr;
    downstream_recv_terminal_slots = nullptr;
    downstream_recv_terminal_window_capacity = 0;
    downstream_recv_terminal_window_start = 0;
    downstream_recv_terminal_window_count = 0;
    downstream_recv_terminal_slot_capacity = 0;
    downstream_recv_terminal_out_of_range_windows = 0;
    reset_downstream_recv_wait_state();
    // Setup io_uring with desired flags
    struct io_uring_params params;
    memset(&params, 0, sizeof(params));
    // wait() consults IORING_SQ_TASKRUN before bypassing enter. Request the
    // notification so a busy visible CQ cannot hide cooperative task work.
    // SINGLE_ISSUER / DEFER_TASKRUN were evaluated and not adopted; see the
    // comment above IoUringBackend in io_uring_backend.h.
    params.flags = IORING_SETUP_COOP_TASKRUN | IORING_SETUP_TASKRUN_FLAG | IORING_SETUP_CQSIZE;
    // Rings scale with the connection capacity (see io_uring_memlock.h) instead
    // of a fixed 16384 / 32768 pair that cost 1.6 MiB of RLIMIT_MEMLOCK per shard.
    const IoUringRingSizes sizes = io_uring_ring_sizes(capacity);
    params.cq_entries = sizes.cq_entries;
    // Note: SQPOLL requires CAP_SYS_NICE or io_uring_register credentials.
    // Omit for now, add as optimization later.

    ring_fd = io_uring_setup(sizes.sq_entries, &params);
    if (ring_fd < 0) {
        i32 err = -ring_fd;
        last_init_failure_detail = IoUringInitFailureDetail::QueueSetup;
        if (err == EINVAL) {
            struct io_uring_params baseline_params;
            memset(&baseline_params, 0, sizeof(baseline_params));
            baseline_params.cq_entries = sizes.cq_entries;
            baseline_params.flags =
                params.flags & ~(IORING_SETUP_COOP_TASKRUN | IORING_SETUP_TASKRUN_FLAG);
            const i32 baseline_fd = io_uring_setup(sizes.sq_entries, &baseline_params);
            if (baseline_fd >= 0 && close(baseline_fd) == 0)
                last_init_failure_detail =
                    IoUringInitFailureDetail::QueueSetupFeatureFlagsUnsupported;
        }
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::IoUring));
    }

    sq_ring_entries = params.sq_entries;
    cq_ring_entries = params.cq_entries;

    // Map SQ ring
    sq_ring_sz = params.sq_off.array + params.sq_entries * sizeof(u32);
    sq_ring_ptr = mmap(nullptr,
                       sq_ring_sz,
                       PROT_READ | PROT_WRITE,
                       MAP_SHARED | MAP_POPULATE,
                       ring_fd,
                       IORING_OFF_SQ_RING);
    if (sq_ring_ptr == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::SqRingMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }

    auto* sq_base = static_cast<u8*>(sq_ring_ptr);
    sq_head = reinterpret_cast<u32*>(sq_base + params.sq_off.head);
    sq_tail = reinterpret_cast<u32*>(sq_base + params.sq_off.tail);
    sq_flags = reinterpret_cast<u32*>(sq_base + params.sq_off.flags);
    sq_ring_mask = reinterpret_cast<u32*>(sq_base + params.sq_off.ring_mask);
    sq_array = reinterpret_cast<u32*>(sq_base + params.sq_off.array);

    // Map SQEs
    sqes_sz = params.sq_entries * sizeof(io_uring_sqe);
    sqes_ptr = mmap(nullptr,
                    sqes_sz,
                    PROT_READ | PROT_WRITE,
                    MAP_SHARED | MAP_POPULATE,
                    ring_fd,
                    IORING_OFF_SQES);
    if (sqes_ptr == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::SqeMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }
    sq_entries = static_cast<io_uring_sqe*>(sqes_ptr);

    // Map CQ ring
    cq_ring_sz = params.cq_off.cqes + params.cq_entries * sizeof(io_uring_cqe);
    cq_ring_ptr = mmap(nullptr,
                       cq_ring_sz,
                       PROT_READ | PROT_WRITE,
                       MAP_SHARED | MAP_POPULATE,
                       ring_fd,
                       IORING_OFF_CQ_RING);
    if (cq_ring_ptr == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::CqRingMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }

    auto* cq_base = static_cast<u8*>(cq_ring_ptr);
    cq_head = reinterpret_cast<u32*>(cq_base + params.cq_off.head);
    cq_tail = reinterpret_cast<u32*>(cq_base + params.cq_off.tail);
    cq_ring_mask = reinterpret_cast<u32*>(cq_base + params.cq_off.ring_mask);
    cq_entries = reinterpret_cast<io_uring_cqe*>(cq_base + params.cq_off.cqes);

    // Terminal-recv quarantine inventory (see the header): a FIFO ring sized for
    // the worst case of one window per CQ slot, plus an 8-byte-per-connection
    // side table.  Both are demand-paged so an idle shard pays nothing.
    if ((cq_ring_entries & (cq_ring_entries - 1u)) != 0 || cq_ring_entries == 0) {
        last_init_failure_detail = IoUringInitFailureDetail::RingSizeInvariant;
        shutdown();
        return core::make_unexpected(Error::make(EINVAL, Error::Source::IoUring));
    }
    const u64 windows_sz = static_cast<u64>(cq_ring_entries) * sizeof(DownstreamRecvTerminalWindow);
    void* windows_mem =
        mmap(nullptr, windows_sz, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (windows_mem == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::TerminalWindowMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }
    downstream_recv_terminal_windows = static_cast<DownstreamRecvTerminalWindow*>(windows_mem);
    downstream_recv_terminal_window_capacity = cq_ring_entries;
    const u64 slots_sz = static_cast<u64>(connection_capacity) * sizeof(DownstreamRecvTerminalSlot);
    void* slots_mem =
        mmap(nullptr, slots_sz, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (slots_mem == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::TerminalSlotMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }
    downstream_recv_terminal_slots = static_cast<DownstreamRecvTerminalSlot*>(slots_mem);
    downstream_recv_terminal_slot_capacity = connection_capacity;

    // Setup provided buffer ring for zero-copy recv
    TRY_VOID(setup_buf_ring());
    probe_nop_inject_result();

    // Create timerfd for 1-second ticks (drives timer wheel)
    timer_fd = timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK | TFD_CLOEXEC);
    if (timer_fd < 0) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::TimerfdCreate;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Timerfd));
    }
    struct itimerspec ts;
    memset(&ts, 0, sizeof(ts));
    ts.it_interval.tv_sec = 1;
    ts.it_value.tv_sec = 1;
    if (timerfd_settime(timer_fd, 0, &ts, nullptr) < 0) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::TimerfdSettime;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Timerfd));
    }

    // Submit initial read on timerfd
    submit_timer_read();

    return {};
}

// --- Provided buffer ring ---

core::Expected<void, Error> IoUringBackend::setup_buf_ring() {
    // Allocate buffer memory: kProvidedBufCount * kProvidedBufSize
    u64 total_buf_sz = static_cast<u64>(kProvidedBufCount) * kProvidedBufSize;
    buf_base = static_cast<u8*>(mmap(nullptr,
                                     total_buf_sz,
                                     PROT_READ | PROT_WRITE,
                                     MAP_PRIVATE | MAP_ANONYMOUS | MAP_POPULATE,
                                     -1,
                                     0));
    if (buf_base == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::ProvidedBufferMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }

    // Allocate the buf_ring structure itself
    u64 ring_sz = sizeof(io_uring_buf_ring) + kProvidedBufCount * sizeof(io_uring_buf);
    void* ring_mem = mmap(nullptr,
                          ring_sz,
                          PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS | MAP_POPULATE,
                          -1,
                          0);
    if (ring_mem == MAP_FAILED) {
        i32 err = errno;
        last_init_failure_detail = IoUringInitFailureDetail::ProvidedBufferRingMapping;
        shutdown();
        return core::make_unexpected(Error::make(err, Error::Source::Mmap));
    }
    buf_ring = static_cast<io_uring_buf_ring*>(ring_mem);

    // Register the buffer ring with io_uring
    struct io_uring_buf_reg reg;
    memset(&reg, 0, sizeof(reg));
    reg.ring_addr = reinterpret_cast<u64>(buf_ring);
    reg.ring_entries = kProvidedBufCount;
    reg.bgid = kBufGroupId;

    i32 rc = io_uring_register(ring_fd, IORING_REGISTER_PBUF_RING, &reg, 1);
    if (rc < 0) {
        last_init_failure_detail = IoUringInitFailureDetail::ProvidedBufferRingRegistration;
        const long page_size = sysconf(_SC_PAGESIZE);
        bool registration_is_valid =
            page_size > 0 && reg.ring_addr != 0 &&
            (reg.ring_addr % static_cast<u64>(page_size)) == 0 &&
            reg.ring_entries == kProvidedBufCount && reg.ring_entries != 0 &&
            (reg.ring_entries & (reg.ring_entries - 1u)) == 0 && reg.ring_entries < 65536u &&
            reg.bgid == kBufGroupId && reg.flags == 0;
        if (rc == -EINVAL && registration_is_valid)
            last_init_failure_detail = IoUringInitFailureDetail::ProvidedBufferRingUnsupported;
        shutdown();
        return core::make_unexpected(Error::make(-rc, Error::Source::IoUring));
    }

    // Fill the ring with buffer entries
    for (u32 i = 0; i < kProvidedBufCount; i++) {
        io_uring_buf* buf = &buf_ring->bufs[i];
        buf->addr = reinterpret_cast<u64>(buf_base + static_cast<u64>(i) * kProvidedBufSize);
        buf->len = kProvidedBufSize;
        buf->bid = static_cast<u16>(i);
    }
    // Advance the ring tail to make all buffers available
    __atomic_store_n(&buf_ring->tail, static_cast<u16>(kProvidedBufCount), __ATOMIC_RELEASE);

    setup_extra_buf_ring(kLargeProvidedBufCount,
                         kLargeProvidedBufSize,
                         kLargeBufGroupId,
                         kLargeProvidedBufIdBase,
                         large_buf_ring,
                         large_buf_base);
    // Bulk-sized recvs use a direct one-shot IORING_OP_RECV straight into the
    // caller's bulk buffer (add_recv_upstream_direct) instead of a third
    // provided-buffer ring: there is no ring-to-buffer copy to save a ring for.
    return {};
}

void IoUringBackend::setup_extra_buf_ring(
    u32 count, u32 size, u16 group, u32 id_base, io_uring_buf_ring*& ring_out, u8*& base_out) {
    // Buffer memory is faulted in on first use: idle shards keep it unresident.
    const u64 total_buf_sz = static_cast<u64>(count) * size;
    void* base =
        mmap(nullptr, total_buf_sz, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (base == MAP_FAILED) return;
    const u64 ring_sz = sizeof(io_uring_buf_ring) + count * sizeof(io_uring_buf);
    void* ring_mem = mmap(nullptr,
                          ring_sz,
                          PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS | MAP_POPULATE,
                          -1,
                          0);
    if (ring_mem == MAP_FAILED) {
        munmap(base, total_buf_sz);
        return;
    }
    auto* ring = static_cast<io_uring_buf_ring*>(ring_mem);

    struct io_uring_buf_reg reg;
    memset(&reg, 0, sizeof(reg));
    reg.ring_addr = reinterpret_cast<u64>(ring);
    reg.ring_entries = count;
    reg.bgid = group;
    if (io_uring_register(ring_fd, IORING_REGISTER_PBUF_RING, &reg, 1) < 0) {
        munmap(ring_mem, ring_sz);
        munmap(base, total_buf_sz);
        return;
    }

    auto* data = static_cast<u8*>(base);
    for (u32 i = 0; i < count; i++) {
        io_uring_buf* buf = &ring->bufs[i];
        buf->addr = reinterpret_cast<u64>(data + static_cast<u64>(i) * size);
        buf->len = size;
        buf->bid = static_cast<u16>(id_base + i);
    }
    __atomic_store_n(&ring->tail, static_cast<u16>(count), __ATOMIC_RELEASE);
    base_out = data;
    ring_out = ring;
}

void IoUringBackend::return_buffer(u16 buf_id) {
    if (buf_id >= kLargeProvidedBufIdBase) {
        if (!provided_buffer_id_valid(buf_id)) return;
        const u16 tail = __atomic_load_n(&large_buf_ring->tail, __ATOMIC_RELAXED);
        io_uring_buf* buf = &large_buf_ring->bufs[tail & (kLargeProvidedBufCount - 1)];
        buf->addr = reinterpret_cast<u64>(provided_buffer_data(buf_id));
        buf->len = kLargeProvidedBufSize;
        buf->bid = buf_id;
        __atomic_store_n(&large_buf_ring->tail, static_cast<u16>(tail + 1), __ATOMIC_RELEASE);
        return;
    }
    // Add buffer back to the provided ring
    u16 tail = __atomic_load_n(&buf_ring->tail, __ATOMIC_RELAXED);
    u16 mask = kProvidedBufCount - 1;  // power of 2

    io_uring_buf* buf = &buf_ring->bufs[tail & mask];
    buf->addr = reinterpret_cast<u64>(buf_base + static_cast<u64>(buf_id) * kProvidedBufSize);
    buf->len = kProvidedBufSize;
    buf->bid = buf_id;

    __atomic_store_n(&buf_ring->tail, static_cast<u16>(tail + 1), __ATOMIC_RELEASE);
}

void IoUringBackend::submit_timer_read() {
    if (timer_read_armed) return;  // already in-flight
    io_uring_sqe* sqe = get_sqe();
    if (!sqe) return;  // SQ full — will retry on next wait()

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_READ;
    sqe->fd = timer_fd;
    sqe->addr = reinterpret_cast<u64>(&timer_ticks_buf);
    sqe->len = sizeof(timer_ticks_buf);
    sqe->user_data = encode_user_data(kTimerConnId, IoEventType::Timeout);

    sqe_advance_tail(sq_tail);
    pending++;
    timer_read_armed = true;
}

// --- Operations ---

bool IoUringBackend::add_accept() {
    // listen_fd < 0 means the listener was closed (close_listen()); never arm on
    // -1 or a recycled fd number.
    if (ring_fd < 0 || listen_fd < 0) return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_ACCEPT;
    sqe->fd = listen_fd;
    sqe->accept_flags = SOCK_NONBLOCK | SOCK_CLOEXEC;
    sqe->ioprio = IORING_ACCEPT_MULTISHOT;  // multishot: one SQE, continuous accept
    sqe->user_data = encode_user_data(0, IoEventType::Accept);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_recv(i32 fd, u32 conn_id) {
    if (conn_id >= connection_capacity || connection_capacity == 0) return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_RECV;
    sqe->fd = fd;
    sqe->len = kProvidedBufSize;  // max bytes to read from provided buffer
    sqe->buf_group = kBufGroupId;
    sqe->flags = IOSQE_BUFFER_SELECT;
    sqe->ioprio = IORING_RECV_MULTISHOT;  // multishot: continuous recv
    sqe->user_data = encode_user_data(conn_id, IoEventType::Recv);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_recv_upstream(i32 fd, u32 conn_id, u32 upstream_episode) {
    if (conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode)) return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_RECV;
    sqe->fd = fd;
    sqe->len = kProvidedBufSize;
    sqe->buf_group = kBufGroupId;
    sqe->flags = IOSQE_BUFFER_SELECT;
    sqe->ioprio = IORING_RECV_MULTISHOT;
    sqe->user_data =
        encode_upstream_user_data(conn_id, IoEventType::UpstreamRecv, upstream_episode);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_recv_upstream_once(i32 fd,
                                            u32 conn_id,
                                            u32 upstream_episode,
                                            u32 max_len) {
    if (conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode) ||
        max_len == 0 || max_len > upstream_once_max_len())
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_RECV;
    sqe->fd = fd;
    sqe->len = max_len;
    sqe->buf_group = large_buf_ring != nullptr ? kLargeBufGroupId : kBufGroupId;
    sqe->flags = IOSQE_BUFFER_SELECT;
    sqe->user_data =
        encode_upstream_user_data(conn_id, IoEventType::UpstreamRecv, upstream_episode);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_recv_upstream_direct(
    i32 fd, u32 conn_id, u32 upstream_episode, u8* dst, u32 len) {
    if (conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode) ||
        dst == nullptr || len == 0)
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_RECV;
    sqe->fd = fd;
    sqe->addr = reinterpret_cast<u64>(dst);
    sqe->len = len;
    // msg_flags stays 0 (memset above): no MSG_WAITALL, see the declaration.
    // No IOSQE_BUFFER_SELECT / buf_group: the kernel writes straight into
    // dst, so this CQE never carries IORING_CQE_F_BUFFER. wait() recognizes
    // it by Connection::upstream_recv_direct_armed rather than by opcode.
    sqe->user_data =
        encode_upstream_user_data(conn_id, IoEventType::UpstreamRecv, upstream_episode);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_relay_poll(i32 fd, u32 conn_id, IoEventType type, u32 upstream_episode) {
    if (fd < 0 || conn_id >= connection_capacity ||
        (type != IoEventType::RelayRead && type != IoEventType::RelayWrite) ||
        !valid_upstream_episode(upstream_episode))
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;
    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_POLL_ADD;
    sqe->fd = fd;
    sqe->poll32_events = type == IoEventType::RelayRead ? POLLIN : POLLOUT;
    sqe->user_data = encode_upstream_user_data(conn_id, type, upstream_episode);
    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_first_response_recv(
    i32 fd, u32 conn_id, u32 upstream_episode, bool separate_body_ring, bool one_shot) {
    if (fd < 0 || conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode))
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_RECV;
    sqe->fd = fd;
    const bool large = separate_body_ring && large_buf_ring != nullptr;
    sqe->len = large ? kLargeProvidedBufSize : kProvidedBufSize;
    sqe->buf_group = large ? kLargeBufGroupId : kBufGroupId;
    sqe->flags = IOSQE_BUFFER_SELECT;
    if (!one_shot) sqe->ioprio = IORING_RECV_MULTISHOT;
    sqe->user_data =
        encode_upstream_user_data(conn_id, IoEventType::UpstreamRecv, upstream_episode);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::pause_recv(i32 fd, u32 conn_id) {
    if (fd < 0 || conn_id >= connection_capacity) return false;
    return cancel_by_user_data(
        encode_user_data(conn_id, IoEventType::Recv), conn_id, IoEventType::Recv, kPauseCancelAux);
}

// Pause the multishot upstream recv by cancelling it by user_data (recv-only — it
// never touches a concurrent upstream send, unlike a cancel-by-fd). The cancel's OWN
// completion is tagged with the real conn_id + kPauseCancelAux, so it routes to the
// connection rather than being silently dropped: the loop counts it in pending_ops
// (pinning the slot until it drains) and re-arms the recv only once it arrives — so
// the in-flight cancel can never match a freshly-armed recv on the reused conn_id.
bool IoUringBackend::pause_upstream_recv(i32 fd, u32 conn_id, u32 upstream_episode) {
    if (fd < 0 || conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode))
        return false;
    return cancel_by_user_data(
        encode_upstream_user_data(conn_id, IoEventType::UpstreamRecv, upstream_episode),
        conn_id,
        IoEventType::UpstreamRecv,
        kPauseCancelAux,
        upstream_episode);
}

bool IoUringBackend::cancel_retiring_upstream(u32 conn_id, IoEventType type, u32 upstream_episode) {
    if (conn_id >= connection_capacity || !io_event_uses_upstream_episode(type) ||
        !valid_upstream_episode(upstream_episode))
        return false;
    return cancel_by_user_data(encode_upstream_user_data(conn_id, type, upstream_episode),
                               conn_id,
                               type,
                               kUpstreamRetirementCancelAux,
                               upstream_episode);
}

bool IoUringBackend::add_send(i32 fd,
                              u32 conn_id,
                              const u8* buf,
                              u32 len,
                              u32 generation,
                              bool more_follows,
                              BufferedSendVector* vector) {
    if (conn_id >= connection_capacity || connection_capacity == 0) return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;  // no SQE even after a flush: don't record send_state for it
    if (vector && !vector->matches(buf, len)) return false;
    const u32 extra_flags = more_follows ? static_cast<u32>(MSG_MORE) : 0u;

    // Record send state only after acquiring SQE — if kernel returns partial,
    // wait() re-submits the remainder.
    if (conn_id < connection_capacity) {
        send_state[conn_id] = {buf, fd, 0, len, IoEventType::Send, 0, generation, extra_flags};
        send_state[conn_id].vector = vector;
    }

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = vector ? IORING_OP_SENDMSG : IORING_OP_SEND;
    // MSG_NOSIGNAL explicit; current kernels also force it for io_uring.
    sqe->msg_flags = MSG_NOSIGNAL | extra_flags;
    sqe->fd = fd;
    sqe->addr = vector ? reinterpret_cast<u64>(&vector->message) : reinterpret_cast<u64>(buf);
    sqe->len = vector ? 1u : len;
    sqe->user_data = encode_user_data(conn_id, IoEventType::Send, generation);

    static const bool study_zc_enabled = ::getenv("RUT_STUDY_SEND_ZC") != nullptr;
    const u32 study_charge = len + 2 * 4096;
    if (study_zc_enabled && !study_zc_disabled && len >= 128 * 1024 && generation != 0 &&
        study_charge <= 4 * 1024 * 1024 - study_zc_live_bytes) {
        sqe->opcode = vector ? IORING_OP_SENDMSG_ZC : IORING_OP_SEND_ZC;
        sqe->ioprio |= IORING_SEND_ZC_REPORT_USAGE;
        static const bool study_zc_push = ::getenv("RUT_STUDY_ZC_PUSH") != nullptr;
        if (study_zc_push) {
            sqe->msg_flags &= ~static_cast<u32>(MSG_MORE);
            send_state[conn_id].msg_flags &= ~static_cast<u32>(MSG_MORE);
        }
        send_state[conn_id].study_zc = true;
        send_state[conn_id].study_zc_charge = study_charge;
        study_zc_live_bytes += study_charge;
        ++study_zc_requests;
    }
    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_send_file(i32 fd,
                                   u32 conn_id,
                                   i32 file_fd,
                                   u32 file_off,
                                   u32 len,
                                   u32 generation,
                                   bool shutdown_when_done,
                                   bool* wrote_all,
                                   bool allow_sync_completion) {
    if (wrote_all) *wrote_all = false;
    if (conn_id >= connection_capacity || connection_capacity == 0 || fd < 0 || file_fd < 0 ||
        len == 0 || len > static_cast<u32>(INT32_MAX))
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;  // the completion must stay accountable
    off_t pos = static_cast<off_t>(file_off);
    const ssize_t n = ::sendfile(fd, file_fd, &pos, len);
    // get_sqe() only reserves the slot; leaving it unsubmitted needs no undo.
    if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) return false;
    const u32 written = n > 0 ? static_cast<u32>(n) : 0;
    if (written == len) {
        if (shutdown_when_done) (void)::shutdown(fd, SHUT_WR);
        if (wrote_all) *wrote_all = true;
        if (!shutdown_when_done && allow_sync_completion) {
            // A keep-alive continuation that finished in this one call needs
            // no completion round trip through the ring: every byte is
            // already on the wire (n == len) and the caller can account the
            // response synchronously — the caller decided this is safe to
            // offer (not already inside another synchronous completion), so
            // this no longer depends on nop_inject_result at all. The
            // reserved SQE is left untouched — get_sqe() only peeked at the
            // tail, so the next real submission reuses the same slot.
            return true;
        }
    }
    memset(sqe, 0, sizeof(*sqe));
    if (written == len && nop_inject_result) {
        // Complete through the ordinary proactor path, like a direct write.
        send_state[conn_id] = {nullptr, fd, 0, len, IoEventType::Send, 0, generation};
        sqe->opcode = IORING_OP_NOP;
        sqe->rw_flags = static_cast<decltype(sqe->rw_flags)>(IORING_NOP_INJECT_RESULT);
        sqe->len = len;
    } else {
        send_state[conn_id] = {nullptr,
                               fd,
                               written,
                               len - written,
                               IoEventType::Send,
                               0,
                               generation,
                               0,
                               file_fd,
                               file_off,
                               shutdown_when_done && written != len};
        sqe->opcode = IORING_OP_POLL_ADD;
        sqe->fd = fd;
        sqe->poll32_events = POLLOUT;
    }
    sqe->user_data = encode_user_data(conn_id, IoEventType::Send, generation);
    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

void IoUringBackend::probe_nop_inject_result() {
    // Runs before any other submission, so the only CQE is this probe's.
    // Kernels without IORING_NOP_INJECT_RESULT fail the NOP with -EINVAL.
    static constexpr u32 kProbeResult = 7;
    nop_inject_result = false;
    const u32 tail_before = __atomic_load_n(sq_tail, __ATOMIC_RELAXED);
    io_uring_sqe* sqe = get_sqe();
    if (!sqe) return;
    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_NOP;
    sqe->rw_flags = static_cast<decltype(sqe->rw_flags)>(IORING_NOP_INJECT_RESULT);
    sqe->len = kProbeResult;
    sqe->user_data = encode_user_data(kCancelConnId, IoEventType::Send);
    sqe_advance_tail(sq_tail);
    // -EINTR means nothing was submitted. A probe the kernel did not accept
    // is withdrawn, so the next submission starts with the runtime's own SQEs.
    i32 rc = 0;
    do {
        rc = io_uring_enter(ring_fd, 1, 1, IORING_ENTER_GETEVENTS);
    } while (rc == -EINTR);
    if (rc < 1) {
        __atomic_store_n(sq_tail, tail_before, __ATOMIC_RELEASE);
        return;
    }
    // Accepted: consume its completion here rather than in the first wait().
    u32 head = __atomic_load_n(cq_head, __ATOMIC_RELAXED);
    while (head == __atomic_load_n(cq_tail, __ATOMIC_ACQUIRE)) {
        rc = io_uring_enter(ring_fd, 0, 1, IORING_ENTER_GETEVENTS);
        if (rc < 0 && rc != -EINTR) return;  // wait() drops the sentinel completion
    }
    nop_inject_result = cq_entries[head & *cq_ring_mask].res == static_cast<i32>(kProbeResult);
    __atomic_store_n(cq_head, head + 1, __ATOMIC_RELEASE);
}

bool IoUringBackend::add_send_after_direct_write(i32 fd,
                                                 u32 conn_id,
                                                 const u8* buf,
                                                 u32 len,
                                                 u32 written,
                                                 u32 generation,
                                                 BufferedSendVector* vector,
                                                 u32 extra_flags) {
    if (vector && !vector->matches(buf, len)) return false;
    if (conn_id >= connection_capacity || connection_capacity == 0 || written > len ||
        (written == len && !nop_inject_result))
        return false;
    io_uring_sqe* sqe = get_sqe();
    if (!sqe) return false;
    // Same send state as add_send, advanced past the bytes the caller already
    // wrote directly; the Send completion still reports the whole length.
    send_state[conn_id] = {
        buf, fd, written, len - written, IoEventType::Send, 0, generation, extra_flags};
    send_state[conn_id].vector = vector;
    memset(sqe, 0, sizeof(*sqe));
    if (written == len) {
        sqe->opcode = IORING_OP_NOP;
        sqe->rw_flags = static_cast<decltype(sqe->rw_flags)>(IORING_NOP_INJECT_RESULT);
        sqe->len = len;
        send_state[conn_id].offset = 0;
        send_state[conn_id].remaining = len;
    } else {
        if (vector) vector->advance(written);
        sqe->opcode = vector ? IORING_OP_SENDMSG : IORING_OP_SEND;
        sqe->msg_flags = MSG_NOSIGNAL | extra_flags;
        sqe->fd = fd;
        sqe->addr =
            vector ? reinterpret_cast<u64>(&vector->message) : reinterpret_cast<u64>(buf + written);
        sqe->len = vector ? 1u : len - written;
    }
    sqe->user_data = encode_user_data(conn_id, IoEventType::Send, generation);
    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::flush_pending_nonblocking() {
    return flush_pending_nonblocking_impl([](i32 fd, u32 to_submit, u32 min_complete, u32 flags) {
        return io_uring_enter(fd, to_submit, min_complete, flags);
    });
}

bool IoUringBackend::add_send_upstream(
    i32 fd, u32 conn_id, const u8* buf, u32 len, u32 upstream_episode) {
    if (conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode)) return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    if (conn_id < connection_capacity) {
        upstream_send_state[conn_id] = {
            buf, fd, 0, len, IoEventType::UpstreamSend, upstream_episode, 0};
    }

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_SEND;
    sqe->msg_flags = MSG_NOSIGNAL;  // explicit; current kernels also force it for io_uring
    sqe->fd = fd;
    sqe->addr = reinterpret_cast<u64>(buf);
    sqe->len = len;
    sqe->user_data =
        encode_upstream_user_data(conn_id, IoEventType::UpstreamSend, upstream_episode);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_connect(
    i32 fd, u32 conn_id, const void* addr, u32 addr_len, u32 upstream_episode) {
    if (conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode)) return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_CONNECT;
    sqe->fd = fd;
    sqe->addr = reinterpret_cast<u64>(addr);
    sqe->off = addr_len;  // connect uses off field for addrlen
    sqe->user_data =
        encode_upstream_user_data(conn_id, IoEventType::UpstreamConnect, upstream_episode);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_yield_timeout(u32 conn_id, Connection& conn, u32 ms) {
    if (connection_capacity == 0 || conn_id >= connection_capacity || conn.id != conn_id)
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    // Relative timeout; kernel reads &conn.yield_timespec asynchronously
    // so the storage must live on the Connection (not on the stack).
    conn.yield_timespec.tv_sec = ms / 1000;
    conn.yield_timespec.tv_nsec = static_cast<long long>(ms % 1000) * 1'000'000LL;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_TIMEOUT;
    sqe->fd = -1;  // unused for IORING_OP_TIMEOUT
    sqe->addr = reinterpret_cast<u64>(&conn.yield_timespec);
    sqe->len = 1;  // one timespec
    sqe->off = 0;  // count=0 → plain relative timeout (no "wait for N events" semantics)
    conn.yield_timer_gen++;
    sqe->user_data = encode_user_data(conn_id, IoEventType::HandlerTimer, conn.yield_timer_gen);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::add_response_read_timer(u32 conn_id,
                                             Connection& conn,
                                             u32 milliseconds,
                                             u32 deadline_generation,
                                             u32 upstream_episode) {
    if (conn_id >= connection_capacity || conn_id > kIoUserDataMaxConnId || conn.id != conn_id ||
        milliseconds == 0 || deadline_generation == 0 ||
        !valid_upstream_episode(upstream_episode) || !conn.response_read_timer_owner_is_neutral() ||
        conn.response_read_timer_generation >= kResponseReadTimerGenerationMask)
        return false;

    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    // Publish no owner until an SQE slot is secured. From this point onward
    // every operation is infallible and the kernel-stable timespec remains
    // immutable until the target CQE is harvested.
    if (!conn.next_response_read_timer_generation()) return false;
    conn.response_read_timer_timespec.tv_sec = milliseconds / 1000;
    conn.response_read_timer_timespec.tv_nsec =
        static_cast<long long>(milliseconds % 1000) * 1'000'000LL;
    conn.response_read_timer_deadline_generation = deadline_generation;
    conn.response_read_timer_upstream_episode = upstream_episode;
    conn.response_read_timer_phase = ResponseReadTimerPhase::Armed;
    conn.response_read_timer_target_owned = true;
    conn.response_read_timer_cancel_owned = false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_TIMEOUT;
    sqe->fd = -1;
    sqe->addr = reinterpret_cast<u64>(&conn.response_read_timer_timespec);
    sqe->len = 1;
    sqe->off = 0;
    sqe->user_data = encode_user_data(
        conn_id, IoEventType::ResponseReadTimer, conn.response_read_timer_owner_generation);
    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::cancel_response_read_timer(u32 conn_id, Connection& conn) {
    if (conn_id >= connection_capacity || conn_id > kIoUserDataMaxConnId || conn.id != conn_id ||
        conn.response_read_timer_phase != ResponseReadTimerPhase::Armed ||
        !conn.response_read_timer_owner_is_valid())
        return false;

    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    const u32 generation = conn.response_read_timer_owner_generation;
    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_ASYNC_CANCEL;
    sqe->fd = -1;
    sqe->addr = encode_user_data(conn_id, IoEventType::ResponseReadTimer, generation);
    // The generation is unique within this connection/event domain, so an
    // exact single-target cancel is sufficient and yields one cancel CQE.
    sqe->cancel_flags = 0;
    sqe->user_data = encode_user_data(
        conn_id, IoEventType::ResponseReadTimer, generation | kResponseReadTimerCancelBit);

    // Publish CancelPending only after its SQE is fully initialized. Neither
    // immutable identity key changes while the two owners drain independently.
    conn.response_read_timer_phase = ResponseReadTimerPhase::CancelPending;
    conn.response_read_timer_cancel_owned = true;
    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

void IoUringBackend::cancel_accept() {
    if (ring_fd < 0) return;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_ASYNC_CANCEL;
    sqe->fd = listen_fd;
    // Cancel by user_data — matches the multishot accept SQE.
    sqe->addr = encode_user_data(0, IoEventType::Accept);
    sqe->cancel_flags = IORING_ASYNC_CANCEL_ALL;
    sqe->user_data = encode_user_data(kCancelConnId, IoEventType::Accept);

    sqe_advance_tail(sq_tail);
    pending++;

    // Submit immediately so the cancel takes effect before close_listen()
    // closes the fd. Without this, the cancel SQE sits in the SQ until
    // the next wait(), by which time the fd may already be closed/reused.
    if (pending > 0) {
        i32 ret = io_uring_enter(ring_fd, pending, 0, IORING_ENTER_SQ_WAKEUP);
        if (ret > 0)
            pending -= static_cast<u32>(ret);
        else if (ret < 0)
            record_enter_error(ret);
    }
}

// Submit a cancel SQE matching a specific user_data value.
// Returns true if the SQE was queued, false if SQ is full.
bool IoUringBackend::cancel_by_user_data(
    u64 target, u32 conn_id, IoEventType type, u32 aux, u32 upstream_episode) {
    if (conn_id != kCancelConnId && (connection_capacity == 0 || conn_id >= connection_capacity))
        return false;
    if (io_event_uses_upstream_episode(type) &&
        (conn_id >= connection_capacity || !valid_upstream_episode(upstream_episode)))
        return false;
    io_uring_sqe* sqe = get_sqe_flushing();
    if (!sqe) return false;

    memset(sqe, 0, sizeof(*sqe));
    sqe->opcode = IORING_OP_ASYNC_CANCEL;
    // Cancel by user_data match (not fd) — safe across fd reuse after close().
    sqe->addr = target;
    sqe->cancel_flags = IORING_ASYNC_CANCEL_ALL;
    // Encode the caller-provided conn_id/type/aux in the cancel CQE. Close-path
    // cancels use the real conn_id so dispatch can account pending_ops; mid-wait
    // timeout disarms use kCancelConnId so the cancel CQE is consumed silently.
    sqe->user_data =
        io_event_uses_upstream_episode(type)
            ? encode_upstream_user_data(conn_id, type, upstream_episode, static_cast<u8>(aux))
            : encode_user_data(conn_id, type, aux);

    sqe_advance_tail(sq_tail);
    pending++;
    return true;
}

bool IoUringBackend::cancel_yield_timeout(u32 conn_id, u32 yield_timer_gen) {
    if (connection_capacity == 0 || conn_id >= connection_capacity) return false;
    return cancel_by_user_data(
        encode_user_data(conn_id, IoEventType::HandlerTimer, yield_timer_gen),
        kCancelConnId,
        IoEventType::HandlerTimer,
        yield_timer_gen);
}

u32 IoUringBackend::cancel(i32 /*fd*/,
                           u32 conn_id,
                           bool recv_armed,
                           bool send_armed,
                           bool upstream_connect_armed,
                           bool upstream_recv_armed,
                           bool upstream_send_armed,
                           bool has_upstream,
                           u32 upstream_episode,
                           bool yield_armed,
                           u32 yield_timer_gen,
                           u8* upstream_cancel_mask,
                           bool* send_cancel_owned) {
    if (upstream_cancel_mask) *upstream_cancel_mask = 0;
    if (send_cancel_owned) *send_cancel_owned = false;
    if (connection_capacity == 0 || conn_id >= connection_capacity) return 0;
    if ((has_upstream || upstream_connect_armed || upstream_recv_armed || upstream_send_armed) &&
        !valid_upstream_episode(upstream_episode))
        return 0;
    // Only cancel op types that are actually in flight to avoid wasting
    // SQ/CQ capacity with no-op cancels that produce -ENOENT completions.
    u32 submitted = 0;
    if (recv_armed) {
        if (cancel_by_user_data(encode_user_data(conn_id, IoEventType::Recv),
                                conn_id,
                                IoEventType::Recv,
                                kDownstreamCloseCancelAux))
            submitted++;
    }
    if (send_armed) {
        const u32 generation = conn_id < connection_capacity ? send_state[conn_id].generation : 0;
        if (cancel_by_user_data(encode_user_data(conn_id, IoEventType::Send, generation),
                                conn_id,
                                IoEventType::Send,
                                generation == 0 ? 0 : generation | kNonUpstreamSendCancelBit)) {
            submitted++;
            if (send_cancel_owned) *send_cancel_owned = generation != 0;
        }
    }
    // Upstream ops only if the connection was proxying.
    if (has_upstream) {
        if (upstream_recv_armed) {
            if (cancel_by_user_data(
                    encode_upstream_user_data(conn_id, IoEventType::UpstreamRecv, upstream_episode),
                    conn_id,
                    IoEventType::UpstreamRecv,
                    kUpstreamCloseCancelAux,
                    upstream_episode)) {
                submitted++;
                if (upstream_cancel_mask) *upstream_cancel_mask |= kUpstreamOpRecv;
            }
        }
        if (upstream_send_armed) {
            if (cancel_by_user_data(
                    encode_upstream_user_data(conn_id, IoEventType::UpstreamSend, upstream_episode),
                    conn_id,
                    IoEventType::UpstreamSend,
                    kUpstreamCloseCancelAux,
                    upstream_episode)) {
                submitted++;
                if (upstream_cancel_mask) *upstream_cancel_mask |= kUpstreamOpSend;
            }
        }
        if (upstream_connect_armed &&
            cancel_by_user_data(
                encode_upstream_user_data(conn_id, IoEventType::UpstreamConnect, upstream_episode),
                conn_id,
                IoEventType::UpstreamConnect,
                kUpstreamCloseCancelAux,
                upstream_episode)) {
            submitted++;
            if (upstream_cancel_mask) *upstream_cancel_mask |= kUpstreamOpConnect;
        }
    }
    // JIT handler yield timer (IORING_OP_TIMEOUT) — cancel pins the slot
    // until the target CQE arrives, preventing stale HandlerTimer events
    // from resuming a handler on a reused slot.
    if (yield_armed) {
        if (cancel_by_user_data(
                encode_user_data(conn_id, IoEventType::HandlerTimer, yield_timer_gen),
                conn_id,
                IoEventType::HandlerTimer,
                yield_timer_gen))
            submitted++;
    }

    // Submit immediately so cancels take effect before close_conn_impl()
    // closes the fd. Retry on EINTR; subtract actually submitted count.
    for (;;) {
        i32 ret = io_uring_enter(ring_fd, pending, 0, IORING_ENTER_SQ_WAKEUP);
        if (ret >= 0) {
            pending -= static_cast<u32>(ret);
            break;
        }
        if (ret == -EINTR) continue;
        record_enter_error(ret);
        break;  // other error — event loop will stop instead of retrying forever
    }
    return submitted;
}

// --- Wait (submit + harvest) ---

u32 IoUringBackend::wait(IoEvent* events, u32 max_events, Connection* conns, u32 max_conns) {
    if (failure_code() != 0) return 0;
    // Retry timer read if previous submit_timer_read() failed (SQ was full)
    if (timer_fd >= 0 && !timer_read_armed) submit_timer_read();

    // A previous submission (including close-path cancellation) may already
    // have produced CQEs. Harvest them without another enter when there is no
    // SQ work to flush. Never defer pending submissions behind a busy CQ.
    const bool ready =
        __atomic_load_n(cq_head, __ATOMIC_ACQUIRE) != __atomic_load_n(cq_tail, __ATOMIC_ACQUIRE);
    const u32 kernel_flags = sq_flags ? __atomic_load_n(sq_flags, __ATOMIC_ACQUIRE) : 0;
    const bool kernel_work = (kernel_flags & (IORING_SQ_CQ_OVERFLOW | IORING_SQ_TASKRUN)) != 0;
    u32 flags = IORING_ENTER_GETEVENTS;
    i32 ret;
    while (pending != 0 || !ready || kernel_work) {
        if (pending > 0) {
            ret = io_uring_enter(ring_fd, pending, 1, flags);
            if (ret >= 0) pending -= static_cast<u32>(ret);
        } else {
            ret = io_uring_enter(ring_fd, 0, 1, flags);
        }
        if (ret >= 0) break;
        if (ret == -EINTR) continue;
        record_enter_error(ret);
        return 0;
    }

    // Harvest CQEs
    u32 head = __atomic_load_n(cq_head, __ATOMIC_ACQUIRE);
    u32 tail = __atomic_load_n(cq_tail, __ATOMIC_ACQUIRE);
    u32 mask = *cq_ring_mask;
    u32 count = 0;
    u64 last_read_owner_token = 0;
    u32 last_read_owner_head = 0;
    bool last_read_owner_valid = false;

    auto protocol_failure = [&]() { fatal_error.store(EPROTO, std::memory_order_release); };
    if (tail - head > cq_ring_entries ||
        (downstream_recv_progress_valid && downstream_recv_progress_head != head) ||
        (!downstream_recv_progress_valid &&
         (deferred_downstream_recv.active || downstream_recv_terminal_window_count != 0))) {
        protocol_failure();
        return 0;
    }

    // Quarantine lookup, O(1).  Returns 0 and the frozen tail when `user_data`
    // is inside a live window, -1 when it is not, -2 on a corrupt front window.
    // Only an aux-0 downstream Recv token can own a window, so every other CQE
    // skips the table.  A window whose tail equals head has reached its
    // boundary and no longer quarantines anything.
    const u32 ring_mask = downstream_recv_terminal_window_capacity - 1u;
    auto terminal_window_lookup = [&](u64 user_data, u32& window_tail) -> i32 {
        // Steady state: no live window, so never touch the side table.
        if (downstream_recv_terminal_window_count == 0) return -1;
        if (downstream_recv_terminal_window_count != 0 &&
            downstream_recv_terminal_windows[downstream_recv_terminal_window_start].tail_exclusive -
                    head >
                cq_ring_entries)
            return -2;
        u32 token_conn = 0;
        IoEventType token_type = IoEventType::Count;
        u32 token_aux = 0;
        decode_user_data(user_data, token_conn, token_type, token_aux);
        if (token_type != IoEventType::Recv || token_aux != 0) return -1;
        if (token_conn < downstream_recv_terminal_slot_capacity) {
            const auto& slot = downstream_recv_terminal_slots[token_conn];
            if (slot.live == 0 || slot.tail_exclusive == head) return -1;
            window_tail = slot.tail_exclusive;
            return 0;
        }
        if (downstream_recv_terminal_out_of_range_windows == 0) return -1;
        for (u32 i = 0; i < downstream_recv_terminal_window_count; i++) {
            const auto& window =
                downstream_recv_terminal_windows[(downstream_recv_terminal_window_start + i) &
                                                 ring_mask];
            if (window.user_data == user_data && window.tail_exclusive != head) {
                window_tail = window.tail_exclusive;
                return 0;
            }
        }
        return -1;
    };
    auto expire_terminal_windows = [&]() {
        bool expired = false;
        while (downstream_recv_terminal_window_count != 0) {
            auto& window = downstream_recv_terminal_windows[downstream_recv_terminal_window_start];
            if (window.tail_exclusive - head > cq_ring_entries) {
                protocol_failure();
                return false;
            }
            if (window.tail_exclusive != head) break;
            const u32 conn_id = terminal_window_conn_id(window.user_data);
            if (conn_id < downstream_recv_terminal_slot_capacity)
                downstream_recv_terminal_slots[conn_id] = {};
            else if (downstream_recv_terminal_out_of_range_windows != 0)
                downstream_recv_terminal_out_of_range_windows--;
            window = {};
            downstream_recv_terminal_window_start =
                (downstream_recv_terminal_window_start + 1u) & ring_mask;
            downstream_recv_terminal_window_count--;
            expired = true;
        }
        // Reaching a frozen tail is an event-loop boundary.  Never classify a
        // CQE appended after it in the same wait invocation.
        return !expired;
    };
    auto valid_positive_downstream_buffer = [&](const io_uring_cqe& cqe) {
        if ((cqe.flags & IORING_CQE_F_BUFFER) == 0 || static_cast<u32>(cqe.res) > kProvidedBufSize)
            return false;
        const u16 buf_id = static_cast<u16>(cqe.flags >> IORING_CQE_BUFFER_SHIFT);
        return buf_id < kProvidedBufCount;
    };
    auto add_terminal_window = [&](u64 user_data, u32 tail_exclusive) {
        if (tail_exclusive - head > cq_ring_entries ||
            downstream_recv_terminal_window_count >= downstream_recv_terminal_window_capacity) {
            protocol_failure();
            return false;
        }
        const u32 conn_id = terminal_window_conn_id(user_data);
        if (conn_id < downstream_recv_terminal_slot_capacity) {
            auto& slot = downstream_recv_terminal_slots[conn_id];
            // One live window per token: a duplicate inside the window is
            // quarantined, and one after it only arrives once it has expired.
            if (slot.live != 0) {
                protocol_failure();
                return false;
            }
            slot = {tail_exclusive, 1};
        } else {
            downstream_recv_terminal_out_of_range_windows++;
        }
        downstream_recv_terminal_windows[(downstream_recv_terminal_window_start +
                                          downstream_recv_terminal_window_count++) &
                                         ring_mask] = {user_data, tail_exclusive};
        return true;
    };

    // Only entries below the count are read, and each is written first, so the
    // array is left uninitialized: zeroing 2 KiB on every wait() call showed up
    // as ~8% of userspace CPU in body-streaming proxy profiles.
    u64 positive_downstream_tokens[kMaxEventsPerWait];
    u32 positive_downstream_token_count = 0;

    if (deferred_downstream_recv.active) {
        if (head == tail || deferred_downstream_recv.head != head ||
            deferred_downstream_recv.frozen_tail - head > cq_ring_entries) {
            protocol_failure();
        } else {
            const io_uring_cqe& deferred = cq_entries[head & mask];
            u32 deferred_conn = 0;
            u32 deferred_aux = 0;
            u32 deferred_episode = 0;
            IoEventType deferred_type = IoEventType::Count;
            decode_user_data(
                deferred.user_data, deferred_conn, deferred_type, deferred_aux, deferred_episode);
            u32 window_tail = 0;
            const i32 window = terminal_window_lookup(deferred.user_data, window_tail);
            if (deferred.user_data != deferred_downstream_recv.user_data ||
                deferred_type != IoEventType::Recv || deferred_aux != 0 || deferred.res <= 0 ||
                !valid_positive_downstream_buffer(deferred) || window == -2 ||
                (deferred_downstream_recv.prior_terminal &&
                 (window < 0 || window_tail != deferred_downstream_recv.frozen_tail)) ||
                (!deferred_downstream_recv.prior_terminal && window >= 0))
                protocol_failure();
        }
    }

    while (failure_code() == 0 && head != tail && count < max_events) {
        if (!expire_terminal_windows()) break;
        io_uring_cqe* cqe = &cq_entries[head & mask];

        // The destination array is reused across waits.  Clear the complete
        // slot before decoding so metadata from a prior CQE can never become
        // evidence for the current one.
        events[count] = {};

        u32 conn_id;
        IoEventType type;
        u32 aux = 0;
        u32 upstream_episode = 0;
        decode_user_data(cqe->user_data, conn_id, type, aux, upstream_episode);

        // Dispatch an already completed downstream send before copying
        // or publishing a later receive for that same connection. A sequential
        // client can receive the response and submit its next request before
        // userspace dispatches the send CQE; eager copying must not turn that
        // request into a pipelined successor of the still-live old request.
        // The same boundary keeps a following FIN out of the old completed-body
        // deadline batch. Tagged sends with an active deadline retain whole-batch
        // arbitration; only BodyComplete no longer has an expiry to arbitrate.
        // Prebuilt header/retirement rendezvous already owns late receive
        // bytes explicitly and must retain its existing whole-batch settlement.
        if (type == IoEventType::Recv && aux == 0 &&
            (conns == nullptr || conn_id >= max_conns ||
             conns[conn_id].http1_prebuilt_disposition == Http1RequestBufferDisposition::None)) {
            bool prior_send = false;
            for (u32 i = 0; i < count; ++i)
                prior_send |= events[i].conn_id == conn_id && events[i].type == IoEventType::Send &&
                              (events[i].non_upstream_generation == 0 ||
                               (conns != nullptr && conn_id < max_conns &&
                                conns[conn_id].response_read_deadline_state ==
                                    ResponseReadDeadlineState::BodyComplete));
            if (prior_send) break;
        }

        // Cancel CQEs — silently consume, don't emit event
        if (conn_id == kCancelConnId) {
            head++;
            continue;
        }

        // A timeout/cancel completion never owns a provided buffer and is
        // never multishot. Reject malformed flags before any generic recv
        // handling can inspect, copy, or return a selected buffer.
        if (type == IoEventType::ResponseReadTimer &&
            (cqe->flags & (IORING_CQE_F_BUFFER | IORING_CQE_F_MORE)) != 0) {
            protocol_failure();
            break;
        }

        const bool downstream_recv_target = type == IoEventType::Recv && aux == 0;
        const bool downstream_recv_close_cancel =
            type == IoEventType::Recv && aux == kDownstreamCloseCancelAux;
        const bool downstream_recv_pause_cancel =
            type == IoEventType::Recv && aux == kPauseCancelAux;
        if (type == IoEventType::Recv && !downstream_recv_target && !downstream_recv_close_cancel &&
            !downstream_recv_pause_cancel) {
            protocol_failure();
            break;
        }
        // The close cancel's own CQE can report a positive cancellation count,
        // but it never owns a selected buffer or F_MORE.  Only the aux-0 recv
        // target can expose future payload and participate in the barrier.
        if (downstream_recv_close_cancel &&
            (cqe->flags & (IORING_CQE_F_BUFFER | IORING_CQE_F_MORE)) != 0) {
            protocol_failure();
            break;
        }
        if (downstream_recv_pause_cancel &&
            (cqe->flags & (IORING_CQE_F_BUFFER | IORING_CQE_F_MORE)) != 0) {
            protocol_failure();
            break;
        }
        const bool positive_downstream_recv = downstream_recv_target && cqe->res > 0;
        if (downstream_recv_target && cqe->res <= 0 && (cqe->flags & IORING_CQE_F_BUFFER) != 0) {
            protocol_failure();
            break;
        }
        u32 quarantined_tail = 0;
        const i32 quarantined_window =
            downstream_recv_target ? terminal_window_lookup(cqe->user_data, quarantined_tail) : -1;
        if (quarantined_window == -2) {
            protocol_failure();
            break;
        }
        if (positive_downstream_recv && !valid_positive_downstream_buffer(*cqe)) {
            protocol_failure();
            break;
        }
        bool positive_downstream_already_seen = false;
        if (positive_downstream_recv) {
            for (u32 i = 0; i < positive_downstream_token_count; i++)
                positive_downstream_already_seen |= positive_downstream_tokens[i] == cqe->user_data;
            if (positive_downstream_already_seen) {
                deferred_downstream_recv = {cqe->user_data,
                                            head,
                                            quarantined_window >= 0 ? quarantined_tail : tail,
                                            true,
                                            quarantined_window >= 0};
                break;
            }
        }
        if (quarantined_window >= 0 && downstream_recv_target) {
            // This exact token is inside a tail snapshot taken before its
            // terminal callback could rearm/reuse the slot. It owns no live
            // Connection accounting. Return a positive record's validated
            // selected buffer exactly once; duplicate target terminals/errors
            // have no buffer and are consumed without publication. The tagged
            // close-cancel completion has different user_data and remains
            // visible because it owns a separate pending-op count.
            if (positive_downstream_recv) {
                const u16 buf_id = static_cast<u16>(cqe->flags >> IORING_CQE_BUFFER_SHIFT);
                return_buffer(buf_id);
            }
            if (deferred_downstream_recv.active) deferred_downstream_recv = {};
            head++;
            continue;
        }

        if (positive_downstream_recv) {
            if (positive_downstream_token_count >= kMaxEventsPerWait) {
                protocol_failure();
                break;
            }
            positive_downstream_tokens[positive_downstream_token_count++] = cqe->user_data;
        }
        if (deferred_downstream_recv.active) deferred_downstream_recv = {};

        // --- #3: Timer tick handling ---
        if (conn_id == kTimerConnId && type == IoEventType::Timeout) {
            timer_read_armed = false;
            if (cqe->res == static_cast<i32>(sizeof(timer_ticks_buf))) {
                // Clamp tick count to avoid i32 overflow after long stalls
                i32 ticks =
                    (timer_ticks_buf > 0x7FFFFFFF) ? 0x7FFFFFFF : static_cast<i32>(timer_ticks_buf);
                events[count].conn_id = 0;
                events[count].type = IoEventType::Timeout;
                events[count].result = ticks;
                events[count].buf_id = 0;
                events[count].has_buf = 0;
                events[count].more = 0;
                events[count].aux = 0;
                events[count].upstream_episode = 0;
                count++;
            }
            // Re-submit read on timerfd for next tick
            submit_timer_read();
            head++;
            continue;
        }

        // --- #4: Provided buffer handling ---
        // MUST return the buffer to the ring regardless of result or conn_id validity,
        // otherwise the provided buffer ring drains and recv stalls.
        if (cqe->flags & IORING_CQE_F_BUFFER) {
            u16 buf_id = static_cast<u16>(cqe->flags >> IORING_CQE_BUFFER_SHIFT);

            // Append data into the appropriate recv buffer only on success + valid conn.
            // UpstreamRecv → upstream_recv_buf; Recv → recv_buf.
            // Buffer is NOT reset here — callback resets when it consumes data.
            i32 buf_result = cqe->res;
            bool stale_upstream = false;
            bool deadline_active = false;
            bool deadline_owner = false;
            if (type == IoEventType::UpstreamRecv && conns != nullptr && conn_id < max_conns) {
                const auto& conn = conns[conn_id];
                deadline_active =
                    (conn.response_read_deadline_state == ResponseReadDeadlineState::Armed ||
                     conn.response_read_deadline_state ==
                         ResponseReadDeadlineState::BodyComplete) &&
                    conn.response_read_deadline_owner_generation != 0 &&
                    conn.response_read_deadline_owner_generation ==
                        conn.response_read_deadline_generation;
            }
            if (io_event_is_upstream(type)) {
                stale_upstream = conns == nullptr || conn_id >= max_conns ||
                                 upstream_episode == 0 ||
                                 upstream_episode != conns[conn_id].upstream_episode;
                if (!stale_upstream && type == IoEventType::UpstreamRecv) {
                    const auto& conn = conns[conn_id];
                    deadline_owner =
                        (conn.response_read_deadline_state == ResponseReadDeadlineState::Armed ||
                         conn.response_read_deadline_state ==
                             ResponseReadDeadlineState::BodyComplete) &&
                        conn.response_read_deadline_upstream_episode == upstream_episode &&
                        conn.response_read_deadline_owner_generation != 0 &&
                        conn.response_read_deadline_owner_generation ==
                            conn.response_read_deadline_generation;
                    // Episode equality alone is not ownership: a forged or
                    // duplicate aux-0 CQE must not mutate the live recv buffer,
                    // and a closed successor's target must drain accounting
                    // without copying bytes into reset storage.
                    stale_upstream =
                        aux != 0 || conn.fd < 0 ||
                        (!conn.upstream_recv_armed && !conn.upstream_recv_cancel_inflight);
                }
            }
            const bool valid_buffer_id = provided_buffer_id_valid(buf_id);
            const bool stale_downstream =
                type == IoEventType::Recv &&
                (conns == nullptr || conn_id >= max_conns || conns[conn_id].fd < 0);
            if (cqe->res > 0 && conn_id < max_conns && !stale_upstream && !stale_downstream &&
                valid_buffer_id) {
                u32 nbytes = static_cast<u32>(cqe->res);
                // TLS client connections receive ciphertext: land it in
                // tls_in_buf so the event-loop TLS layer can decrypt into
                // recv_buf (plaintext). Upstream + plaintext use their buffers.
                auto& target_buf = (type == IoEventType::UpstreamRecv)
                                       ? conns[conn_id].upstream_recv_buf
                                   : conns[conn_id].tls_active ? conns[conn_id].tls_in_buf
                                                               : conns[conn_id].recv_buf;
                const u8* src = provided_buffer_data(buf_id);
                u32 avail = target_buf.write_avail();
                auto& conn = conns[conn_id];
                const bool buffered_overflow =
                    deadline_owner && response_pool != nullptr &&
                    forward_response_buffering_uses_content_length_machinery(
                        conn.response_read_deadline_buffering) &&
                    (conn.response_body_tail.size != 0 || nbytes > avail);
                bool deadline_copy_eligible =
                    type == IoEventType::UpstreamRecv && deadline_owner &&
                    nbytes <= provided_buffer_size(buf_id) &&
                    (nbytes <= avail || buffered_overflow) &&
                    ((last_read_owner_valid && head == last_read_owner_head + 1u &&
                      cqe->user_data == last_read_owner_token) ||
                     response_deadline_copy_owner(conn, upstream_episode, aux));
                const u32 copy_begin =
                    deadline_owner ? conn.buffered_response_len() : target_buf.len();
                u32 prefix_copy = 0;
                if (deadline_copy_eligible && buffered_overflow) {
                    // Keep the receive buffer's contiguous prefix visible to the
                    // header parser. Reserve the overflow first so a failed
                    // allocation leaves both buffers and the witness unchanged.
                    prefix_copy =
                        conn.response_body_tail.size == 0 ? (nbytes < avail ? nbytes : avail) : 0;
                    const u32 overflow = nbytes - prefix_copy;
                    deadline_copy_eligible =
                        overflow == 0 ||
                        conn.response_body_tail.append(*response_pool,
                                                       src + prefix_copy,
                                                       overflow,
                                                       conn.buffered_response_bulk_after());
                    if (deadline_copy_eligible && prefix_copy != 0) {
                        __builtin_memcpy(target_buf.write_ptr(), src, prefix_copy);
                        target_buf.commit(prefix_copy);
                    }
                }
                // A matching explicit-deadline owner never enters the legacy
                // partial-copy path.  Its provided-buffer payload is one
                // indivisible witness: exact and fully eligible, or zero bytes.
                u32 to_copy = deadline_owner ? (deadline_copy_eligible ? nbytes : 0)
                                             : (nbytes < avail ? nbytes : avail);
                if (to_copy > 0 && !buffered_overflow) {
                    __builtin_memcpy(target_buf.write_ptr(), src, to_copy);
                    target_buf.commit(to_copy);
                }
                // Adjacent fragments only append bytes: dispatch has not run,
                // so their previously checked logical owner cannot change.
                // Do not reuse this proof across another CQE or a send phase.
                if (deadline_copy_eligible &&
                    conn.response_read_deadline_state == ResponseReadDeadlineState::Armed &&
                    (conn.response_read_deadline_post_commit_phase ==
                         ResponseReadDeadlinePostCommitPhase::None ||
                     conn.response_read_deadline_post_commit_phase ==
                         ResponseReadDeadlinePostCommitPhase::Buffering)) {
                    last_read_owner_valid = true;
                    last_read_owner_token = cqe->user_data;
                    last_read_owner_head = head;
                }
                // Report actual bytes copied, not kernel bytes (may differ if buf full)
                buf_result = (to_copy < nbytes) ? -ENOBUFS : static_cast<i32>(to_copy);
                if (deadline_owner) {
                    events[count].copy_witness = deadline_copy_eligible && to_copy == nbytes
                                                     ? IoEventCopyWitness::Full
                                                     : IoEventCopyWitness::Invalid;
                    events[count].copy_deadline_generation =
                        conns[conn_id].response_read_deadline_generation;
                    events[count].copy_deadline_profile =
                        static_cast<u8>(conns[conn_id].response_read_deadline_profile);
                    events[count].copy_deadline_method =
                        conns[conn_id].response_read_deadline_method;
                    if (events[count].copy_witness == IoEventCopyWitness::Full) {
                        events[count].copy_begin = copy_begin;
                        events[count].copy_end = conn.buffered_response_len();
                    }
                }
            } else if (cqe->res > 0 && deadline_active) {
                events[count].copy_witness = IoEventCopyWitness::Invalid;
                events[count].copy_deadline_generation =
                    conns[conn_id].response_read_deadline_generation;
                events[count].copy_deadline_profile =
                    static_cast<u8>(conns[conn_id].response_read_deadline_profile);
                events[count].copy_deadline_method = conns[conn_id].response_read_deadline_method;
                if (!stale_upstream) buf_result = -ENOBUFS;
            } else if (cqe->res > 0 && !valid_buffer_id) {
                buf_result = -ENOBUFS;
            }
            if (deadline_active && (stale_upstream || cqe->res == -ECANCELED || aux != 0)) {
                events[count].copy_witness = IoEventCopyWitness::Invalid;
                events[count].copy_deadline_generation =
                    conns[conn_id].response_read_deadline_generation;
                events[count].copy_deadline_profile =
                    static_cast<u8>(conns[conn_id].response_read_deadline_profile);
                events[count].copy_deadline_method = conns[conn_id].response_read_deadline_method;
            }

            // Always return the buffer, even on error
            if (valid_buffer_id) return_buffer(buf_id);

            // Emit event (buffer already returned, clear has_buf)
            events[count].conn_id = conn_id;
            events[count].type = type;
            events[count].result = buf_result;
            events[count].buf_id = 0;
            events[count].has_buf = 0;
            events[count].more = (cqe->flags & IORING_CQE_F_MORE) ? 1 : 0;
            events[count].aux = static_cast<u8>(aux);  // 0 for recv data
            events[count].upstream_episode = upstream_episode;
            head++;
            count++;
            if (downstream_recv_target && (cqe->flags & IORING_CQE_F_MORE) == 0 &&
                !add_terminal_window(cqe->user_data, tail))
                break;
            continue;
        }

        // --- #4b: Direct recv handling (bulk-buffer one-shot upstream recv) ---
        // Complete-buffered body recvs have a separate immutable target owner:
        // Connection::reset() may already have cleared the logical Buffering
        // phase when close deferred this slot for the outstanding kernel write.
        if (type == IoEventType::UpstreamRecv && aux == 0 && conns != nullptr &&
            conn_id < max_conns && conns[conn_id].chain_direct_recv_owner.active &&
            upstream_episode == conns[conn_id].chain_direct_recv_owner.episode) {
            Connection& conn = conns[conn_id];
            const ChainDirectRecvOwner target = conn.chain_direct_recv_owner;
            const bool more = (cqe->flags & IORING_CQE_F_MORE) != 0;
            if (more || (cqe->flags & IORING_CQE_F_BUFFER) != 0) {
                protocol_failure();
                break;
            }
            if (cqe->res > 0) {
                const u32 nbytes = static_cast<u32>(cqe->res);
                if (nbytes > target.len || response_pool == nullptr ||
                    !conn.response_body_tail.record_direct_write(
                        target.node, target.ptr, nbytes, *response_pool)) {
                    protocol_failure();
                    break;
                }
            }

            const bool bounded_live_post_commit =
                conn.response_read_deadline_buffering == ForwardResponseBufferingMode::Bounded &&
                (conn.response_read_deadline_post_commit_phase ==
                     ResponseReadDeadlinePostCommitPhase::HeaderSend ||
                 conn.response_read_deadline_post_commit_phase ==
                     ResponseReadDeadlinePostCommitPhase::BodySend ||
                 conn.response_read_deadline_post_commit_phase ==
                     ResponseReadDeadlinePostCommitPhase::WaitingBody) &&
                !conn.response_read_deadline_post_commit_terminal_pending &&
                !conn.response_read_deadline_post_commit_close_after_drain;
            const bool stale_target =
                conn.fd < 0 || conn.upstream_fd < 0 || !conn.upstream_recv_armed ||
                target.episode != conn.upstream_episode ||
                (conn.response_read_deadline_post_commit_phase !=
                     ResponseReadDeadlinePostCommitPhase::Buffering &&
                 !bounded_live_post_commit) ||
                conn.response_read_deadline_post_commit_episode != target.episode;
            const u32 declared = conn.response_read_deadline_post_commit_declared_body;
            const u32 received = conn.response_read_deadline_post_commit_origin_received;
            const bool logical_commit =
                cqe->res > 0 && !stale_target && received <= declared &&
                static_cast<u32>(cqe->res) <= declared - received &&
                received <= ResponseBodyChain::kMaxBody &&
                static_cast<u32>(cqe->res) <= ResponseBodyChain::kMaxBody - received &&
                target.node == conn.response_body_tail.tail && response_pool != nullptr &&
                target.ptr == conn.response_body_tail.write_ptr(*response_pool);
            const bool deadline_active =
                (conn.response_read_deadline_state == ResponseReadDeadlineState::Armed ||
                 conn.response_read_deadline_state == ResponseReadDeadlineState::BodyComplete) &&
                conn.response_read_deadline_owner_generation != 0 &&
                conn.response_read_deadline_owner_generation ==
                    conn.response_read_deadline_generation;
            const bool deadline_owner =
                deadline_active && conn.response_read_deadline_upstream_episode == target.episode;
            const bool deadline_copy_eligible =
                deadline_owner && ((last_read_owner_valid && head == last_read_owner_head + 1u &&
                                    cqe->user_data == last_read_owner_token) ||
                                   response_deadline_copy_owner(conn, target.episode, aux));
            i32 direct_result = cqe->res;
            if (logical_commit) {
                const u32 copy_begin = conn.buffered_response_len();
                conn.response_body_tail.commit(static_cast<u32>(cqe->res));
                direct_result = cqe->res;
                events[count].copy_witness =
                    deadline_copy_eligible ? IoEventCopyWitness::Full : IoEventCopyWitness::Invalid;
                events[count].copy_deadline_generation = conn.response_read_deadline_generation;
                events[count].copy_deadline_profile =
                    static_cast<u8>(conn.response_read_deadline_profile);
                events[count].copy_deadline_method = conn.response_read_deadline_method;
                if (events[count].copy_witness == IoEventCopyWitness::Full) {
                    events[count].copy_begin = copy_begin;
                    events[count].copy_end = conn.buffered_response_len();
                }
            } else if (cqe->res > 0 && deadline_active) {
                events[count].copy_witness = IoEventCopyWitness::Invalid;
                events[count].copy_deadline_generation = conn.response_read_deadline_generation;
                events[count].copy_deadline_profile =
                    static_cast<u8>(conn.response_read_deadline_profile);
                events[count].copy_deadline_method = conn.response_read_deadline_method;
            }

            // A canceled bounded target can complete with bytes already written
            // into reserved capacity. They are custody-only after the terminal
            // release was frozen, just like a natural canceled receive target.
            if (cqe->res > 0 && conn.response_read_deadline_post_commit_terminal_pending &&
                conn.upstream_recv_cancel_inflight && conn.upstream_recv_terminal_stale) {
                direct_result = -ECANCELED;
                events[count].copy_witness = IoEventCopyWitness::None;
            }
            conn.chain_direct_recv_owner = {};
            conn.upstream_recv_direct_armed = false;
            events[count].conn_id = conn_id;
            events[count].type = type;
            events[count].result = direct_result;
            events[count].buf_id = 0;
            events[count].has_buf = 0;
            events[count].more = 0;
            events[count].aux = static_cast<u8>(aux);
            events[count].upstream_episode = upstream_episode;
            head++;
            count++;
            continue;
        }

        // A direct recv (add_recv_upstream_direct) owns no provided buffer, so
        // its CQE never carries IORING_CQE_F_BUFFER — the kernel already wrote
        // the bytes straight into the destination captured at arm time. Only a
        // connection that actually armed one is treated as owning this CQE
        // (upstream_recv_direct_armed); every other UpstreamRecv without a
        // selected buffer (cancels, errors, stale episodes) falls through to
        // the default handling below unchanged.
        //
        // Ownership: the destination is pinned until this exact terminal CQE
        // is consumed (see add_recv_upstream_direct's contract) — clearing
        // upstream_recv_direct_armed here, unconditionally, is what lets the
        // event loop's rebinding sites (upgrade_upstream_recv_to_bulk,
        // release_upstream_relay_slice, take_relay_recv_buffer) safely reuse
        // that buffer once dispatch observes this event.
        if (type == IoEventType::UpstreamRecv && aux == 0 && conns != nullptr &&
            conn_id < max_conns && conns[conn_id].upstream_recv_direct_armed &&
            !conns[conn_id].chain_direct_recv_owner.active) {
            Connection& conn = conns[conn_id];
            conn.upstream_recv_direct_armed = false;

            // Mirrors the #4 provided-buffer branch's staleness/deadline
            // accounting exactly (same fields, same formulas) minus the copy:
            // the bytes are already resident, and a direct recv's SQE length
            // is always write_avail() at arm time, so a non-stale positive
            // completion is always a full, exact commit — no partial-copy or
            // buffered-overflow case is possible.
            const bool deadline_active =
                (conn.response_read_deadline_state == ResponseReadDeadlineState::Armed ||
                 conn.response_read_deadline_state == ResponseReadDeadlineState::BodyComplete) &&
                conn.response_read_deadline_owner_generation != 0 &&
                conn.response_read_deadline_owner_generation ==
                    conn.response_read_deadline_generation;
            bool stale_direct = upstream_episode == 0 || upstream_episode != conn.upstream_episode;
            bool deadline_owner = false;
            if (!stale_direct) {
                deadline_owner =
                    (conn.response_read_deadline_state == ResponseReadDeadlineState::Armed ||
                     conn.response_read_deadline_state ==
                         ResponseReadDeadlineState::BodyComplete) &&
                    conn.response_read_deadline_upstream_episode == upstream_episode &&
                    conn.response_read_deadline_owner_generation != 0 &&
                    conn.response_read_deadline_owner_generation ==
                        conn.response_read_deadline_generation;
                stale_direct = aux != 0 || conn.fd < 0 ||
                               (!conn.upstream_recv_armed && !conn.upstream_recv_cancel_inflight);
            }

            // Same eligibility formula as #4's deadline_copy_eligible, minus the
            // buffer-size/overflow terms that never apply to a direct recv (its
            // SQE length is always <= write_avail() at arm time, enforced below).
            const bool deadline_copy_eligible =
                deadline_owner && ((last_read_owner_valid && head == last_read_owner_head + 1u &&
                                    cqe->user_data == last_read_owner_token) ||
                                   response_deadline_copy_owner(conn, upstream_episode, aux));

            i32 direct_result = cqe->res;
            if (cqe->res > 0 && !stale_direct) {
                const u32 nbytes = static_cast<u32>(cqe->res);
                const u32 target_avail = conn.upstream_recv_buf.write_avail();
                if (nbytes > target_avail) {
                    // A direct recv's destination length was set from write_avail()
                    // at arm time and is pinned until this CQE; the kernel can never
                    // legitimately report more bytes than it was asked to read.
                    protocol_failure();
                    break;
                }
                const u32 copy_begin =
                    deadline_owner ? conn.buffered_response_len() : conn.upstream_recv_buf.len();
                conn.upstream_recv_buf.commit(nbytes);
                direct_result = static_cast<i32>(nbytes);
                if (deadline_owner) {
                    events[count].copy_witness = deadline_copy_eligible
                                                     ? IoEventCopyWitness::Full
                                                     : IoEventCopyWitness::Invalid;
                    events[count].copy_deadline_generation = conn.response_read_deadline_generation;
                    events[count].copy_deadline_profile =
                        static_cast<u8>(conn.response_read_deadline_profile);
                    events[count].copy_deadline_method = conn.response_read_deadline_method;
                    if (events[count].copy_witness == IoEventCopyWitness::Full) {
                        events[count].copy_begin = copy_begin;
                        events[count].copy_end = conn.buffered_response_len();
                    }
                }
                // Adjacent fragments only append bytes: dispatch has not run, so
                // their previously checked logical owner cannot change. Do not
                // reuse this proof across another CQE or a send phase.
                if (deadline_copy_eligible &&
                    conn.response_read_deadline_state == ResponseReadDeadlineState::Armed &&
                    (conn.response_read_deadline_post_commit_phase ==
                         ResponseReadDeadlinePostCommitPhase::None ||
                     conn.response_read_deadline_post_commit_phase ==
                         ResponseReadDeadlinePostCommitPhase::Buffering)) {
                    last_read_owner_valid = true;
                    last_read_owner_token = cqe->user_data;
                    last_read_owner_head = head;
                }
            } else if (cqe->res > 0 && deadline_active) {
                events[count].copy_witness = IoEventCopyWitness::Invalid;
                events[count].copy_deadline_generation = conn.response_read_deadline_generation;
                events[count].copy_deadline_profile =
                    static_cast<u8>(conn.response_read_deadline_profile);
                events[count].copy_deadline_method = conn.response_read_deadline_method;
            }
            if (deadline_active && (stale_direct || cqe->res == -ECANCELED || aux != 0)) {
                events[count].copy_witness = IoEventCopyWitness::Invalid;
                events[count].copy_deadline_generation = conn.response_read_deadline_generation;
                events[count].copy_deadline_profile =
                    static_cast<u8>(conn.response_read_deadline_profile);
                events[count].copy_deadline_method = conn.response_read_deadline_method;
            }

            events[count].conn_id = conn_id;
            events[count].type = type;
            events[count].result = direct_result;
            events[count].buf_id = 0;
            events[count].has_buf = 0;
            events[count].more = 0;  // direct recv is always one-shot
            events[count].aux = static_cast<u8>(aux);
            events[count].upstream_episode = upstream_episode;
            head++;
            count++;
            continue;
        }

        // Kernel ring exhaustion has consumed no response bytes. Replace the
        // completed multishot recv under its existing logical owner, just as
        // partial sends below retain their owner until completion. Selected-
        // buffer copy failures already took the branch above and never retry.
        if (type == IoEventType::UpstreamRecv && cqe->res == -ENOBUFS &&
            (cqe->flags & IORING_CQE_F_MORE) == 0 && conns != nullptr && conn_id < max_conns &&
            forward_response_buffering_uses_content_length_machinery(
                conns[conn_id].response_read_deadline_buffering) &&
            response_deadline_copy_owner(conns[conn_id], upstream_episode, aux) &&
            add_first_response_recv(conns[conn_id].upstream_fd,
                                    conn_id,
                                    upstream_episode,
                                    /*separate_body_ring=*/true,
                                    /*one_shot=*/true)) {
            head++;
            continue;
        }

        // Study-only conservative ownership: keep the existing logical Send
        // and every body span pinned until the notification retires kernel refs.
        // Partial progress is applied only then; continuation uses copied SEND.
        io_uring_cqe study_normalized{};
        if (type == IoEventType::Send && conn_id < connection_capacity &&
            aux == send_state[conn_id].generation && send_state[conn_id].study_zc) {
            auto& zc = send_state[conn_id];
            if (cqe->flags & IORING_CQE_F_NOTIF) {
                if (!zc.study_notif_pending) {
                    protocol_failure();
                    break;
                }
                ++study_zc_notifications;
                if (static_cast<u32>(cqe->res) & IORING_NOTIF_USAGE_ZC_COPIED) ++study_zc_copied;
                __builtin_memcpy(&study_normalized, cqe, sizeof(study_normalized));
                study_normalized.res = zc.study_zc_result;
                study_normalized.flags = 0;
                cqe = &study_normalized;
                study_zc_live_bytes -= zc.study_zc_charge;
                zc.study_zc_charge = 0;
                zc.study_zc = false;
                zc.study_notif_pending = false;
            } else if (cqe->flags & IORING_CQE_F_MORE) {
                if (zc.study_notif_pending) {
                    protocol_failure();
                    break;
                }
                zc.study_zc_result = cqe->res;
                zc.study_notif_pending = true;
                head++;
                continue;
            } else {
                study_zc_live_bytes -= zc.study_zc_charge;
                zc.study_zc_charge = 0;
                zc.study_zc = false;
            }
            if (!zc.study_zc &&
                (cqe->res == -ENOMEM || cqe->res == -EOPNOTSUPP || cqe->res == -EINVAL)) {
                // No bytes sent; retry the same owned span with ordinary copying.
                // If MORE was set, this path is reached only after its notification.
                study_zc_disabled = true;
                const bool live_fd =
                    conns == nullptr ||
                    (conn_id < max_conns && conns[conn_id].fd >= 0 && conns[conn_id].fd == zc.fd);
                io_uring_sqe* retry = live_fd ? get_sqe_flushing() : nullptr;
                if (retry) {
                    memset(retry, 0, sizeof(*retry));
                    retry->opcode = zc.vector ? IORING_OP_SENDMSG : IORING_OP_SEND;
                    retry->msg_flags = MSG_NOSIGNAL | zc.msg_flags;
                    retry->fd = zc.fd;
                    retry->addr = zc.vector ? reinterpret_cast<u64>(&zc.vector->message)
                                            : reinterpret_cast<u64>(zc.src + zc.offset);
                    retry->len = zc.vector ? 1u : zc.remaining;
                    retry->user_data = encode_user_data(conn_id, type, zc.generation);
                    sqe_advance_tail(sq_tail);
                    pending++;
                    ++study_zc_fallbacks;
                    head++;
                    continue;
                }
            }
        }

        // --- Send completion: enforce full-send proactor semantics ---
        // If IORING_OP_SEND returned partial, re-submit the remainder.
        // Only emit completion when all bytes sent (or error).
        // A downstream token authenticates the SendState whose byte counters
        // the proactor is about to mutate. Stale/cancel tokens and multishot
        // records reach the default emitter unchanged for dispatch to handle.
        bool downstream_send_proactor = false;
        if (type == IoEventType::Send && conn_id < connection_capacity) {
            const u32 current_generation = send_state[conn_id].generation;
            downstream_send_proactor = aux == current_generation &&
                                       (aux & kNonUpstreamSendCancelBit) == 0 &&
                                       (cqe->flags & IORING_CQE_F_MORE) == 0;
        }
        if ((type == IoEventType::Send && downstream_send_proactor) ||
            (type == IoEventType::UpstreamSend && aux == 0 && conn_id < connection_capacity)) {
            auto& ss = (type == IoEventType::UpstreamSend) ? upstream_send_state[conn_id]
                                                           : send_state[conn_id];
            const bool live_upstream_send_owned =
                type != IoEventType::UpstreamSend ||
                (valid_upstream_episode(upstream_episode) &&
                 ss.upstream_episode == upstream_episode &&
                 (conns == nullptr || (conn_id < max_conns && conns[conn_id].fd >= 0 &&
                                       conns[conn_id].upstream_episode == upstream_episode &&
                                       conns[conn_id].upstream_send_armed)));
            if (!live_upstream_send_owned) {
                // This CQE belongs to a previous upstream episode (or is
                // malformed). Never apply its byte count to the state now
                // installed for this connection ID and never resubmit it.
                // Emit a tagged terminal event so the common async pending-op
                // accounting can retire the old operation.
                if (cqe->res > 0 && ss.remaining > 0) {
                    events[count].conn_id = conn_id;
                    events[count].type = type;
                    events[count].result = -ESTALE;
                    events[count].buf_id = 0;
                    events[count].has_buf = 0;
                    events[count].more = 0;
                    events[count].aux = static_cast<u8>(aux);
                    events[count].upstream_episode = upstream_episode;
                    events[count].non_upstream_generation =
                        type == IoEventType::Send ? ss.generation : 0;
                    head++;
                    count++;
                    continue;
                }
            }
            if (type == IoEventType::Send && ss.file_fd >= 0) {
                // File-backed send: this CQE is POLLOUT readiness (a mask) or
                // a poll error, never a byte count. ss.remaining can already
                // be 0 here — add_send_file's sendfile(2) call wrote the
                // whole length synchronously (a closing chunk, or a
                // keep-alive one with a synchronous completion the caller
                // declined) and still queued this POLL_ADD (e.g. no
                // IORING_NOP_INJECT_RESULT to complete a closing chunk
                // through instead). This CQE is then just cleanup for an SQE
                // that was never really waiting on more bytes: own it here
                // rather than falling through to the generic byte-count path
                // below, which would misreport the poll mask as the send
                // result.
                i32 result = cqe->res < 0 ? cqe->res : 0;
                // Unlike IORING_OP_SEND, sendfile(2) below names the socket by
                // number, and no kernel reference keeps that number ours: a
                // POLLOUT that became ready before close_conn's cancel still
                // lands here after the fd was closed, and the number may by
                // now belong to another connection. Continue only while this
                // connection still owns the exact descriptor; its slot cannot
                // be reused before this terminal CQE (pending_ops holds it).
                if (result == 0 && ss.remaining > 0 &&
                    (conns == nullptr || conn_id >= max_conns || conns[conn_id].fd < 0 ||
                     conns[conn_id].fd != ss.fd))
                    result = -ECANCELED;
                if (result == 0 && ss.remaining > 0) {
                    off_t pos = static_cast<off_t>(ss.file_base) + ss.offset;
                    const ssize_t n = ::sendfile(ss.fd, ss.file_fd, &pos, ss.remaining);
                    if (n > 0) {
                        ss.offset += static_cast<u32>(n);
                        ss.remaining -= static_cast<u32>(n);
                    } else if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                        result = -errno;
                    }
                }
                if (result == 0 && ss.remaining > 0) {
                    io_uring_sqe* sqe = get_sqe_flushing();
                    if (sqe) {
                        memset(sqe, 0, sizeof(*sqe));
                        sqe->opcode = IORING_OP_POLL_ADD;
                        sqe->fd = ss.fd;
                        sqe->poll32_events = POLLOUT;
                        sqe->user_data = encode_user_data(conn_id, type, ss.generation);
                        sqe_advance_tail(sq_tail);
                        pending++;
                        head++;
                        continue;  // don't emit event yet
                    }
                    result = -ENOSPC;  // SQ full: fail rather than stall
                }
                if (result == 0 && ss.shutdown_when_done) (void)::shutdown(ss.fd, SHUT_WR);
                ss.remaining = 0;
                ss.file_fd = -1;
                ss.shutdown_when_done = false;
                events[count].conn_id = conn_id;
                events[count].type = type;
                events[count].result = result < 0 ? result : static_cast<i32>(ss.offset);
                events[count].buf_id = 0;
                events[count].has_buf = 0;
                events[count].more = 0;
                events[count].aux = 0;
                events[count].upstream_episode = upstream_episode;
                events[count].non_upstream_generation = ss.generation;
                head++;
                count++;
                continue;
            }
            if (cqe->res > 0 && ss.remaining > 0) {
                u32 nw = static_cast<u32>(cqe->res);
                if (nw > ss.remaining || ss.offset > UINT32_MAX - nw) {
                    // A completion may never claim bytes outside the submitted
                    // range.  Clear the state and emit one terminal failure;
                    // wrapping remaining would otherwise manufacture a complete
                    // fixed request upload (and can also address past src).
                    ss.remaining = 0;
                    events[count].conn_id = conn_id;
                    events[count].type = type;
                    events[count].result = -EOVERFLOW;
                    events[count].buf_id = 0;
                    events[count].has_buf = 0;
                    events[count].more = 0;
                    events[count].aux = static_cast<u8>(aux);
                    events[count].upstream_episode = upstream_episode;
                    events[count].non_upstream_generation =
                        type == IoEventType::Send ? ss.generation : 0;
                    head++;
                    count++;
                    continue;
                }
                if (ss.vector) ss.vector->advance(nw);
                ss.offset += nw;
                ss.remaining -= nw;
                if (ss.remaining > 0) {
                    // Partial — re-submit remaining bytes
                    io_uring_sqe* sqe = get_sqe_flushing();
                    if (sqe) {
                        memset(sqe, 0, sizeof(*sqe));
                        sqe->opcode = ss.vector ? IORING_OP_SENDMSG : IORING_OP_SEND;
                        sqe->msg_flags = MSG_NOSIGNAL | ss.msg_flags;
                        sqe->fd = ss.fd;
                        sqe->addr = ss.vector ? reinterpret_cast<u64>(&ss.vector->message)
                                              : reinterpret_cast<u64>(ss.src + ss.offset);
                        sqe->len = ss.vector ? 1u : ss.remaining;
                        sqe->user_data =
                            type == IoEventType::UpstreamSend
                                ? encode_upstream_user_data(conn_id, type, ss.upstream_episode)
                                : encode_user_data(conn_id, type, ss.generation);
                        sqe_advance_tail(sq_tail);
                        pending++;
                        head++;
                        continue;  // don't emit event yet
                    }
                    // SQ full — can't re-submit. Emit error to prevent deadlock.
                    ss.remaining = 0;
                    events[count].conn_id = conn_id;
                    events[count].type = type;
                    events[count].result = -ENOSPC;
                    events[count].buf_id = 0;
                    events[count].has_buf = 0;
                    events[count].more = 0;
                    events[count].aux = 0;
                    events[count].upstream_episode = upstream_episode;
                    events[count].non_upstream_generation =
                        type == IoEventType::Send ? ss.generation : 0;
                    head++;
                    count++;
                    continue;
                }
                // All bytes sent — emit completion with total
                events[count].conn_id = conn_id;
                events[count].type = type;
                events[count].result = static_cast<i32>(ss.offset);
                events[count].buf_id = 0;
                events[count].has_buf = 0;
                events[count].more = 0;
                events[count].aux = 0;
                events[count].upstream_episode = upstream_episode;
                events[count].non_upstream_generation =
                    type == IoEventType::Send ? ss.generation : 0;
                head++;
                count++;
                continue;
            }
            // Error or no send_state — fall through to default emit
        }

        // --- Default: non-buffer events (Accept, Connect, error Send/Recv) ---
        events[count].conn_id = conn_id;
        events[count].type = type;
        events[count].result = type == IoEventType::HandlerTimer ? static_cast<i32>(aux) : cqe->res;
        events[count].buf_id = 0;
        events[count].has_buf = 0;
        events[count].more = (cqe->flags & IORING_CQE_F_MORE) ? 1 : 0;
        // Forward the decoded aux so dispatch can recognize a pause cancel's own
        // completion (UpstreamRecv + kPauseCancelAux); 0 for every normal op.
        events[count].aux = (type == IoEventType::Send || type == IoEventType::ResponseReadTimer)
                                ? 0
                                : static_cast<u8>(aux);
        events[count].upstream_episode = upstream_episode;
        events[count].non_upstream_generation =
            (type == IoEventType::Send || type == IoEventType::ResponseReadTimer) ? aux : 0;
        // Selected-buffer completions were handled above, so a recv -ENOBUFS
        // here is the kernel reporting an empty provided ring. The downstream
        // target (aux 0) is flagged too when the multishot ended (no F_MORE):
        // its request bytes are still in the socket, so the loop must re-arm it
        // rather than treat it as fatal.
        events[count].provided_ring_empty =
            cqe->res == -ENOBUFS &&
                    (type == IoEventType::UpstreamRecv || (type == IoEventType::Recv && aux == 0))
                ? 1
                : 0;
        if (type == IoEventType::UpstreamRecv && conns != nullptr && conn_id < max_conns &&
            conns[conn_id].response_read_deadline_state == ResponseReadDeadlineState::Armed &&
            conns[conn_id].response_read_deadline_owner_generation != 0 &&
            conns[conn_id].response_read_deadline_owner_generation ==
                conns[conn_id].response_read_deadline_generation &&
            (cqe->res > 0 || cqe->res == -ECANCELED || aux != 0)) {
            events[count].copy_witness = IoEventCopyWitness::Invalid;
            events[count].copy_deadline_generation =
                conns[conn_id].response_read_deadline_generation;
            events[count].copy_deadline_profile =
                static_cast<u8>(conns[conn_id].response_read_deadline_profile);
            events[count].copy_deadline_method = conns[conn_id].response_read_deadline_method;
            if (cqe->res > 0 && upstream_episode == conns[conn_id].upstream_episode)
                events[count].result = -ENOBUFS;
        }

        head++;
        count++;
        if (downstream_recv_target && (cqe->flags & IORING_CQE_F_MORE) == 0 &&
            !add_terminal_window(cqe->user_data, tail))
            break;
    }

    __atomic_store_n(cq_head, head, __ATOMIC_RELEASE);
    if (deferred_downstream_recv.active || downstream_recv_terminal_window_count != 0) {
        downstream_recv_progress_head = head;
        downstream_recv_progress_valid = true;
    } else {
        downstream_recv_progress_head = 0;
        downstream_recv_progress_valid = false;
    }
    return count;
}

// --- Shutdown ---

void IoUringBackend::shutdown() {
    reset_downstream_recv_wait_state();
    if (timer_fd >= 0) {
        close(timer_fd);
        timer_fd = -1;
    }
    if (buf_base != nullptr) {
        munmap(buf_base, static_cast<u64>(kProvidedBufCount) * kProvidedBufSize);
        buf_base = nullptr;
    }
    if (buf_ring != nullptr) {
        u64 ring_sz = sizeof(io_uring_buf_ring) + kProvidedBufCount * sizeof(io_uring_buf);
        munmap(buf_ring, ring_sz);
        buf_ring = nullptr;
    }
    if (large_buf_base != nullptr) {
        munmap(large_buf_base, static_cast<u64>(kLargeProvidedBufCount) * kLargeProvidedBufSize);
        large_buf_base = nullptr;
    }
    if (large_buf_ring != nullptr) {
        munmap(large_buf_ring,
               sizeof(io_uring_buf_ring) + kLargeProvidedBufCount * sizeof(io_uring_buf));
        large_buf_ring = nullptr;
    }
    if (downstream_recv_terminal_windows != nullptr) {
        munmap(downstream_recv_terminal_windows,
               static_cast<u64>(downstream_recv_terminal_window_capacity) *
                   sizeof(DownstreamRecvTerminalWindow));
        downstream_recv_terminal_windows = nullptr;
        downstream_recv_terminal_window_capacity = 0;
    }
    if (downstream_recv_terminal_slots != nullptr) {
        munmap(downstream_recv_terminal_slots,
               static_cast<u64>(downstream_recv_terminal_slot_capacity) *
                   sizeof(DownstreamRecvTerminalSlot));
        downstream_recv_terminal_slots = nullptr;
        downstream_recv_terminal_slot_capacity = 0;
    }
    if (sqes_ptr != nullptr) {
        munmap(sqes_ptr, sqes_sz);
        sqes_ptr = nullptr;
    }
    if (cq_ring_ptr != nullptr) {
        munmap(cq_ring_ptr, cq_ring_sz);
        cq_ring_ptr = nullptr;
    }
    if (sq_ring_ptr != nullptr) {
        munmap(sq_ring_ptr, sq_ring_sz);
        sq_ring_ptr = nullptr;
    }
    if (ring_fd >= 0) {
        close(ring_fd);
        ring_fd = -1;
    }
    destroy_send_state_storage();
}

}  // namespace rut
