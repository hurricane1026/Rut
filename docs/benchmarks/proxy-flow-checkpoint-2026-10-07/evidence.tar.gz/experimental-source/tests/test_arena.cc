// Arena tests — comprehensive code path coverage for both backends.
// MmapArena: mmap-backed, variable-size blocks (compiler use).
// SliceArena: SlicePool-backed, fixed 16KB blocks (runtime hot path).
#include "fault_injection.h"
#include "rut/runtime/arena.h"
#include "rut/runtime/response_body_chain.h"
#include "rut/runtime/slice_pool.h"
#include "test.h"

using namespace rut;
using rut::test_fault::ScopedMemoryFault;

// ============================================================
// Block internals
// ============================================================

TEST(block, data_starts_after_header) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* b = a.current;
    u64 hdr = (sizeof(MmapArena::Block) + 15) & ~u64(15);
    u8* expected = reinterpret_cast<u8*>(b) + hdr;
    CHECK_EQ(b->data(), expected);
    a.destroy();
}

TEST(block, capacity_equals_size_minus_header) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* b = a.current;
    u64 hdr = (sizeof(MmapArena::Block) + 15) & ~u64(15);
    CHECK_EQ(b->capacity(), b->size - hdr);
    a.destroy();
}

TEST(block, remaining_decreases_after_alloc) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    u64 r0 = a.current->remaining();
    a.alloc(100);
    u64 r1 = a.current->remaining();
    CHECK_EQ(r0 - r1, 104u);  // 100 aligned to 104
    a.destroy();
}

TEST(block, chain_integrity) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    MmapArena::Block* first = a.current;
    CHECK(first->prev == nullptr);

    // Force new block
    a.alloc(first->capacity());
    a.alloc(64);

    MmapArena::Block* second = a.current;
    CHECK(second != first);
    CHECK_EQ(second->prev, first);
    CHECK(first->prev == nullptr);
    a.destroy();
}

TEST(block, three_block_chain) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    MmapArena::Block* b0 = a.current;

    // Force 3 blocks by allocating more than one block can hold each time
    a.alloc(b0->capacity() + 64);  // overflow → b1
    MmapArena::Block* b1 = a.current;
    CHECK_NE(b1, b0);

    a.alloc(b1->capacity() + 64);  // overflow → b2
    MmapArena::Block* b2 = a.current;
    CHECK_NE(b2, b1);

    // Verify chain: b2→b1→b0→nullptr
    CHECK_EQ(b2->prev, b1);
    CHECK_EQ(b1->prev, b0);
    CHECK(b0->prev == nullptr);
    a.destroy();
}

// ============================================================
// Basic allocation (from clapdb ArenaTest.AllocateTest)
// ============================================================

TEST(arena, init_succeeds) {
    MmapArena a;
    CHECK(a.init(4096).has_value());
    CHECK(a.current != nullptr);
    CHECK_GT(a.space_allocated(), 0u);
    a.destroy();
}

TEST(arena, init_reports_mmap_failure) {
    ScopedMemoryFault fault(1);
    MmapArena a;
    auto rc = a.init(4096);
    CHECK(!rc.has_value());
    CHECK_EQ(rc.error().code, ENOMEM);
    CHECK(rc.error().source == Error::Source::Arena);
    CHECK(a.current == nullptr);
    CHECK_EQ(a.space_allocated(), 0u);
}

TEST(arena, init_min_256) {
    MmapArena a;
    REQUIRE(a.init(1).has_value());
    CHECK_GE(a.current->size, 256u);
    a.destroy();
}

TEST(arena, small_alloc) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    void* p = a.alloc(64);
    CHECK(p != nullptr);
    CHECK_EQ(a.space_used(), 64u);
    a.destroy();
}

TEST(arena, alloc_returns_sequential_addresses) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    u8* p1 = static_cast<u8*>(a.alloc(16));
    u8* p2 = static_cast<u8*>(a.alloc(32));
    u8* p3 = static_cast<u8*>(a.alloc(8));
    CHECK_EQ(p2 - p1, 16);
    CHECK_EQ(p3 - p2, 32);
    a.destroy();
}

TEST(arena, multiple_allocs_in_one_block) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    void* p1 = a.alloc(100);
    void* p2 = a.alloc(200);
    void* p3 = a.alloc(300);
    CHECK(p1 && p2 && p3);
    CHECK_NE(p1, p2);
    CHECK_NE(p2, p3);
    // 100→104, 200→200, 300→304 (aligned)
    CHECK_EQ(a.space_used(), 104u + 200u + 304u);
    a.destroy();
}

// ============================================================
// Alignment (from clapdb AlignTest)
// ============================================================

TEST(arena, alignment_8byte) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    void* p1 = a.alloc(1);
    void* p2 = a.alloc(1);
    CHECK_EQ(reinterpret_cast<u64>(p1) % 8, 0u);
    CHECK_EQ(reinterpret_cast<u64>(p2) % 8, 0u);
    CHECK_EQ(static_cast<u8*>(p2) - static_cast<u8*>(p1), 8);
    a.destroy();
}

TEST(arena, alignment_various_sizes) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    for (u64 sz = 1; sz <= 64; sz++) {
        void* p = a.alloc(sz);
        CHECK_EQ(reinterpret_cast<u64>(p) % 8, 0u);
    }
    a.destroy();
}

TEST(arena, zero_size_alloc) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    void* p = a.alloc(0);
    CHECK(p != nullptr);
    a.destroy();
}

// ============================================================
// Block overflow (from clapdb ArenaTest.NewBlockTest)
// ============================================================

TEST(arena, overflow_to_new_block) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    u64 cap = a.current->capacity();
    a.alloc(cap);
    a.alloc(64);
    CHECK(a.current->prev != nullptr);
    CHECK_GE(a.space_allocated(), 256u * 2);
    a.destroy();
}

TEST(arena, overflow_mmap_failure_keeps_existing_block_usable) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    MmapArena::Block* first = a.current;
    const u64 initial_allocated = a.space_allocated();
    REQUIRE(a.alloc(first->capacity()) != nullptr);

    {
        ScopedMemoryFault fault(1);
        CHECK(a.alloc(64) == nullptr);
    }

    CHECK_EQ(a.current, first);
    CHECK_EQ(a.space_allocated(), initial_allocated);
    a.reset();
    CHECK_EQ(a.current, first);
    CHECK(a.alloc(32) != nullptr);
    a.destroy();
}

TEST(arena, large_alloc_gets_own_block) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    void* p = a.alloc(1024);
    CHECK(p != nullptr);
    CHECK_GE(a.current->size, 1024u + sizeof(MmapArena::Block));
    a.destroy();
}

TEST(arena, many_blocks) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    for (int i = 0; i < 100; i++) CHECK(a.alloc(200) != nullptr);
    int blocks = 0;
    for (MmapArena::Block* b = a.current; b; b = b->prev) blocks++;
    CHECK_GT(blocks, 1);
    a.destroy();
}

TEST(arena, alloc_exact_block_capacity) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    u64 cap = a.current->capacity();
    u64 aligned_cap = cap & ~static_cast<u64>(7);
    void* p = a.alloc(aligned_cap);
    CHECK(p != nullptr);
    CHECK_EQ(a.current->remaining(), cap - aligned_cap);
    a.destroy();
}

// ============================================================
// Reset (from clapdb ArenaTest.ResetTest, FreeBlocksExceptFirstTest)
// ============================================================

TEST(arena, reset_single_block_only) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    MmapArena::Block* first = a.current;
    a.alloc(100);
    a.alloc(200);
    CHECK_GT(a.space_used(), 0u);
    a.reset();
    CHECK_EQ(a.current, first);
    CHECK_EQ(a.current->used, 0u);
    CHECK_EQ(a.space_used(), 0u);
    a.destroy();
}

TEST(arena, reset_reuses_first_block) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    MmapArena::Block* first = a.current;
    a.alloc(100);
    a.reset();
    // Alloc again — should use same first block
    void* p = a.alloc(64);
    CHECK(p != nullptr);
    CHECK_EQ(a.current, first);
    a.destroy();
}

TEST(arena, reset_frees_extra_blocks) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    u64 initial = a.space_allocated();
    for (int i = 0; i < 10; i++) a.alloc(4000);
    CHECK_GT(a.space_allocated(), initial);
    a.reset();
    CHECK_EQ(a.space_allocated(), initial);
    CHECK(a.current->prev == nullptr);
    a.destroy();
}

TEST(arena, reset_total_allocated_tracking) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    u64 initial = a.space_allocated();
    // Create 3 extra blocks
    for (int i = 0; i < 3; i++) {
        a.alloc(a.current->capacity());
        a.alloc(64);
    }
    u64 peak = a.space_allocated();
    CHECK_GT(peak, initial);
    a.reset();
    CHECK_EQ(a.space_allocated(), initial);
    a.destroy();
}

TEST(arena, reset_then_alloc_10_cycles) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    for (int cycle = 0; cycle < 10; cycle++) {
        for (int i = 0; i < 20; i++) CHECK(a.alloc(100) != nullptr);
        a.reset();
        CHECK_EQ(a.space_used(), 0u);
    }
    a.destroy();
}

// ============================================================
// Typed alloc (from clapdb ArenaTest.CreateTest, CreateArrayTest)
// ============================================================

struct Point {
    i32 x, y;
};

TEST(arena, alloc_t_pod) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* p = a.alloc_t<Point>(10, 20);
    CHECK(p != nullptr);
    CHECK_EQ(p->x, 10);
    CHECK_EQ(p->y, 20);
    a.destroy();
}

struct Counter {
    i32 value;
    Counter() : value(42) {}
};

TEST(arena, alloc_t_with_constructor) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* c = a.alloc_t<Counter>();
    CHECK(c != nullptr);
    CHECK_EQ(c->value, 42);
    a.destroy();
}

struct Large {
    u8 data[512];
};

TEST(arena, alloc_t_large_struct) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* l = a.alloc_t<Large>();
    CHECK(l != nullptr);
    // Write pattern and verify
    for (int i = 0; i < 512; i++) l->data[i] = static_cast<u8>(i & 0xFF);
    for (int i = 0; i < 512; i++) CHECK_EQ(l->data[i], static_cast<u8>(i & 0xFF));
    a.destroy();
}

TEST(arena, alloc_t_multiple_types) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* p = a.alloc_t<Point>(1, 2);
    auto* c = a.alloc_t<Counter>();
    auto* l = a.alloc_t<Large>();
    CHECK(p && c && l);
    CHECK_EQ(p->x, 1);
    CHECK_EQ(c->value, 42);
    a.destroy();
}

TEST(arena, alloc_array_int) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* arr = a.alloc_array<i32>(10);
    CHECK(arr != nullptr);
    for (int i = 0; i < 10; i++) CHECK_EQ(arr[i], 0);
    for (int i = 0; i < 10; i++) arr[i] = i * 10;
    for (int i = 0; i < 10; i++) CHECK_EQ(arr[i], i * 10);
    a.destroy();
}

TEST(arena, alloc_array_struct) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* arr = a.alloc_array<Point>(5);
    CHECK(arr != nullptr);
    for (int i = 0; i < 5; i++) {
        CHECK_EQ(arr[i].x, 0);
        CHECK_EQ(arr[i].y, 0);
    }
    a.destroy();
}

TEST(arena, alloc_array_zero_count) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* arr = a.alloc_array<i32>(0);
    CHECK(arr != nullptr);  // zero-count returns valid pointer
    a.destroy();
}

// ============================================================
// Destroy (from clapdb ArenaTest.DstrTest, FreeBlocksTest)
// ============================================================

TEST(arena, destroy_frees_all) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    for (int i = 0; i < 20; i++) a.alloc(200);
    a.destroy();
    CHECK(a.current == nullptr);
    CHECK_EQ(a.total_allocated, 0u);
}

TEST(arena, double_destroy_safe) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    a.alloc(100);
    a.destroy();
    a.destroy();
    CHECK(a.current == nullptr);
}

TEST(arena, destroy_single_block) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    a.alloc(64);
    a.destroy();
    CHECK(a.current == nullptr);
    CHECK_EQ(a.total_allocated, 0u);
}

// ============================================================
// Metrics (from clapdb ArenaTest.SpaceTest, RemainsTest)
// ============================================================

TEST(arena, space_used_single_block) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    a.alloc(100);  // → 104
    a.alloc(8);
    CHECK_EQ(a.space_used(), 104u + 8u);
    a.destroy();
}

TEST(arena, space_used_across_blocks) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    u64 cap = a.current->capacity();
    a.alloc(cap);  // fill first block
    a.alloc(64);   // second block
    // First block: cap used. Second block: 64 used.
    CHECK_EQ(a.space_used(), cap + 64u);
    a.destroy();
}

TEST(arena, space_allocated_grows_with_blocks) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    u64 a0 = a.space_allocated();
    a.alloc(a.current->capacity());
    a.alloc(64);
    u64 a1 = a.space_allocated();
    CHECK_GT(a1, a0);
    a.destroy();
}

TEST(arena, space_used_zero_after_reset) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    a.alloc(500);
    CHECK_GT(a.space_used(), 0u);
    a.reset();
    CHECK_EQ(a.space_used(), 0u);
    a.destroy();
}

// ============================================================
// Stress tests
// ============================================================

TEST(arena, stress_10k_small_allocs) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    for (int i = 0; i < 10000; i++) CHECK(a.alloc(8) != nullptr);
    CHECK_EQ(a.space_used(), 80000u);
    a.destroy();
}

TEST(arena, stress_mixed_sizes) {
    MmapArena a;
    REQUIRE(a.init(1024).has_value());
    for (int i = 0; i < 1000; i++) {
        u64 sz = static_cast<u64>((i % 7 + 1) * 8);  // 8,16,24,32,40,48,56
        CHECK(a.alloc(sz) != nullptr);
    }
    a.destroy();
}

TEST(arena, stress_alloc_reset_1000_cycles) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    for (int cycle = 0; cycle < 1000; cycle++) {
        a.alloc(128);
        a.alloc(256);
        a.alloc(64);
        a.reset();
    }
    CHECK_EQ(a.space_used(), 0u);
    a.destroy();
}

TEST(arena, stress_large_allocs_across_blocks) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    // Each alloc forces a new block
    for (int i = 0; i < 50; i++) CHECK(a.alloc(4000) != nullptr);
    int blocks = 0;
    for (MmapArena::Block* b = a.current; b; b = b->prev) blocks++;
    CHECK_GE(blocks, 50);
    a.destroy();
}

TEST(arena, stress_reset_preserves_first_block_across_cycles) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    MmapArena::Block* first = a.current;
    for (int cycle = 0; cycle < 100; cycle++) {
        for (int i = 0; i < 10; i++) a.alloc(100);
        a.reset();
        CHECK_EQ(a.current, first);
    }
    a.destroy();
}

// ============================================================
// Data integrity — write then read back
// ============================================================

TEST(arena, data_integrity_after_alloc) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    auto* buf = static_cast<u8*>(a.alloc(256));
    REQUIRE(buf != nullptr);
    for (int i = 0; i < 256; i++) buf[i] = static_cast<u8>(i);
    for (int i = 0; i < 256; i++) CHECK_EQ(buf[i], static_cast<u8>(i));
    a.destroy();
}

TEST(arena, data_integrity_across_blocks) {
    MmapArena a;
    REQUIRE(a.init(256).has_value());
    // Fill first block, force second
    u64 cap = a.current->capacity();
    auto* buf1 = static_cast<u8*>(a.alloc(cap));
    for (u64 i = 0; i < cap; i++) buf1[i] = static_cast<u8>(i & 0xFF);

    auto* buf2 = static_cast<u8*>(a.alloc(128));
    for (int i = 0; i < 128; i++) buf2[i] = static_cast<u8>(i + 100);

    // Verify first block data still intact
    for (u64 i = 0; i < cap; i++) CHECK_EQ(buf1[i], static_cast<u8>(i & 0xFF));
    // Verify second block
    for (int i = 0; i < 128; i++) CHECK_EQ(buf2[i], static_cast<u8>(i + 100));
    a.destroy();
}

// === Null guard tests (Copilot round 6) ===

// alloc() on uninitialized MmapArena (current==nullptr) must return nullptr, not crash.
// Without the null guard, this would segfault.
TEST(arena, alloc_before_init_returns_null) {
    MmapArena a;
    a.current = nullptr;
    CHECK(a.alloc(64) == nullptr);
}

// alloc() after destroy (current==nullptr) must return nullptr.
TEST(arena, alloc_after_destroy_returns_null) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    a.destroy();
    CHECK(a.alloc(64) == nullptr);
}

// reset() after destroy (current==nullptr) must not crash.
TEST(arena, reset_after_destroy_no_crash) {
    MmapArena a;
    REQUIRE(a.init(4096).has_value());
    a.destroy();
    a.reset();  // must be a no-op, not a crash
    CHECK(a.current == nullptr);
}

// reset() on uninitialized MmapArena must not crash.
TEST(arena, reset_before_init_no_crash) {
    MmapArena a;
    a.current = nullptr;
    a.reset();
    CHECK(a.current == nullptr);
}

// ============================================================
// SliceArena tests (Arena<SlicePoolBackend>)
// ============================================================

// Helper: create a small SlicePool for tests.
// 16 slices = 256KB — enough for arena tests.
struct PoolCtx {
    SlicePool pool;

    bool init() {
        return pool.init(16, 16).has_value();  // 16 slices, all precommitted
    }
    void destroy() { pool.destroy(); }
};

// Fixture: manages PoolCtx + SliceArena lifecycle.
// Tests that need custom pool sizes or pre-init pool counts stay as TEST().
struct SliceArenaF {
    PoolCtx pc;
    SliceArena a;
    bool ok;

    void SetUp() {
        ok = pc.init();
        if (ok) ok = a.init(&pc.pool).has_value();
    }
    void TearDown() {
        a.destroy();
        pc.destroy();
    }
};

TEST_F(SliceArenaF, basic_alloc) {
    REQUIRE(self.ok);
    CHECK(self.a.current != nullptr);

    void* p = self.a.alloc(64);
    CHECK(p != nullptr);
}

TEST_F(SliceArenaF, alloc_t) {
    REQUIRE(self.ok);

    struct Foo {
        u32 x;
        u32 y;
    };
    auto* f = self.a.alloc_t<Foo>(42, 99);
    REQUIRE(f != nullptr);
    CHECK_EQ(f->x, 42u);
    CHECK_EQ(f->y, 99u);
}

TEST_F(SliceArenaF, alloc_array) {
    REQUIRE(self.ok);

    auto* arr = self.a.alloc_array<u64>(100);
    REQUIRE(arr != nullptr);
    for (u32 i = 0; i < 100; i++) CHECK_EQ(arr[i], 0ull);

    arr[0] = 42;
    arr[99] = 99;
    CHECK_EQ(arr[0], 42ull);
    CHECK_EQ(arr[99], 99ull);
}

TEST_F(SliceArenaF, chain_to_second_slice) {
    REQUIRE(self.ok);

    auto* first_block = self.a.current;
    u64 cap = first_block->capacity();

    void* p1 = self.a.alloc(cap - 8);
    REQUIRE(p1 != nullptr);
    CHECK(self.a.current == first_block);

    void* p2 = self.a.alloc(64);
    REQUIRE(p2 != nullptr);
    CHECK(self.a.current != first_block);
    CHECK_EQ(self.a.current->prev, first_block);
}

TEST_F(SliceArenaF, chain_three_slices) {
    REQUIRE(self.ok);

    u64 cap = self.a.current->capacity();

    self.a.alloc(cap);
    auto* s1 = self.a.current;
    self.a.alloc(cap);
    auto* s2 = self.a.current;

    CHECK_NE(s1, s2);
    CHECK_EQ(s2->prev, s1);
}

TEST_F(SliceArenaF, single_alloc_exceeding_slice_fails) {
    REQUIRE(self.ok);

    // 16KB slice minus header ≈ 16368 bytes usable.
    void* p = self.a.alloc(SlicePool::kSliceSize);  // 16384 > usable capacity
    CHECK(p == nullptr);

    // Arena should still be usable after failed alloc
    void* p2 = self.a.alloc(32);
    CHECK(p2 != nullptr);
}

TEST_F(SliceArenaF, reset_then_reuse) {
    REQUIRE(self.ok);

    // Alloc, reset, alloc again — simulates request cycle
    for (int cycle = 0; cycle < 10; cycle++) {
        auto* v = self.a.alloc_t<u32>(static_cast<u32>(cycle));
        REQUIRE(v != nullptr);
        CHECK_EQ(*v, static_cast<u32>(cycle));
        self.a.reset();
    }
}

// --- Tests that need pre-init pool counts or custom pool configs stay as TEST() ---

TEST(slice_arena, init_reports_pool_grow_failure) {
    SlicePool pool;
    REQUIRE(pool.init(2, 0).has_value());

    ScopedMemoryFault fault(0, true);
    SliceArena a;
    auto rc = a.init(&pool);
    CHECK(!rc.has_value());
    CHECK_EQ(rc.error().code, ENOMEM);
    CHECK(rc.error().source == Error::Source::Arena);
    CHECK(a.current == nullptr);
    CHECK_EQ(a.space_allocated(), 0u);
    CHECK_EQ(pool.count, 0u);
    CHECK_EQ(pool.available(), 0u);

    pool.destroy();
}

TEST(slice_arena, overflow_pool_grow_failure_keeps_existing_slice_usable) {
    SlicePool pool;
    REQUIRE(pool.init(SlicePool::kGrowStep + 1, 0).has_value());

    SliceArena a;
    REQUIRE(a.init(&pool).has_value());
    SliceArena::Block* first = a.current;
    const u64 initial_allocated = a.space_allocated();
    const u64 cap = first->capacity();

    for (u32 i = 0; i < SlicePool::kGrowStep; i++) {
        REQUIRE(a.alloc(cap) != nullptr);
    }
    CHECK_EQ(pool.available(), 0u);
    CHECK_EQ(pool.count, SlicePool::kGrowStep);

    {
        ScopedMemoryFault fault(0, true);
        CHECK(a.alloc(64) == nullptr);
    }

    CHECK_EQ(pool.count, SlicePool::kGrowStep);
    CHECK_EQ(pool.available(), 0u);
    CHECK(a.current != nullptr);
    CHECK_EQ(a.space_allocated(), initial_allocated * SlicePool::kGrowStep);
    a.reset();
    CHECK_EQ(a.current, first);
    CHECK(a.alloc(32) != nullptr);

    a.destroy();
    pool.destroy();
}

TEST(slice_arena, reset_returns_slices_to_pool) {
    PoolCtx pc;
    REQUIRE(pc.init());

    u32 free_before = pc.pool.available();

    SliceArena a;
    REQUIRE(a.init(&pc.pool).has_value());
    CHECK_EQ(pc.pool.available(), free_before - 1);

    u64 cap = a.current->capacity();
    a.alloc(cap);
    a.alloc(64);
    CHECK_EQ(pc.pool.available(), free_before - 2);

    a.reset();
    CHECK_EQ(pc.pool.available(), free_before - 1);
    CHECK(a.current != nullptr);
    CHECK(a.current->prev == nullptr);
    CHECK_EQ(a.current->used, 0ull);

    void* p = a.alloc(32);
    CHECK(p != nullptr);

    a.destroy();
    CHECK_EQ(pc.pool.available(), free_before);
    pc.destroy();
}

TEST(slice_arena, destroy_returns_all_slices) {
    PoolCtx pc;
    REQUIRE(pc.init());

    u32 free_before = pc.pool.available();

    SliceArena a;
    REQUIRE(a.init(&pc.pool).has_value());

    u64 cap = a.current->capacity();
    a.alloc(cap);
    a.alloc(64);

    a.destroy();
    CHECK_EQ(pc.pool.available(), free_before);
    CHECK(a.current == nullptr);

    pc.destroy();
}

TEST(slice_arena, pool_exhaustion) {
    // Pool with only 2 slices
    SlicePool pool;
    REQUIRE(pool.init(2, 2).has_value());

    SliceArena a;
    REQUIRE(a.init(&pool).has_value());

    u64 cap = a.current->capacity();
    a.alloc(cap);
    void* p = a.alloc(64);
    CHECK(p != nullptr);

    a.alloc(cap - 64);
    void* p2 = a.alloc(64);  // pool empty → nullptr
    CHECK(p2 == nullptr);

    a.destroy();
    pool.destroy();
}

TEST(slice_arena, multiple_arenas_same_pool) {
    PoolCtx pc;
    REQUIRE(pc.init());

    SliceArena a1, a2;
    REQUIRE(a1.init(&pc.pool).has_value());
    REQUIRE(a2.init(&pc.pool).has_value());

    auto* p1 = a1.alloc_t<u64>(111);
    auto* p2 = a2.alloc_t<u64>(222);
    REQUIRE(p1 != nullptr);
    REQUIRE(p2 != nullptr);
    CHECK_EQ(*p1, 111ull);
    CHECK_EQ(*p2, 222ull);

    a1.reset();
    CHECK_EQ(*p2, 222ull);  // a2's data still valid

    a1.destroy();
    a2.destroy();
    pc.destroy();
}

TEST(slice_pool, study_adaptive_bulk_cache_shrinks_only_unborrowed_idle_slots) {
    SlicePool pool;
    REQUIRE(pool.init(8, 0, 0, 128).has_value());
    pool.study_adaptive_cache = true;
    u8* loans[128];
    for (u32 i = 0; i != 128; ++i) {
        loans[i] = pool.alloc_bulk();
        REQUIRE(loans[i] != nullptr);
        __builtin_memset(loans[i], 0x6D, 4096);
    }
    CHECK_EQ(pool.study_bulk_borrowed, 128u);
    CHECK(pool.study_bulk_burst);
    for (u32 i = 0; i != 128; ++i) pool.free_written(loans[i], 4096);
    CHECK_EQ(pool.bulk_cached_count, 128u);
    u8* held = pool.alloc_bulk();
    REQUIRE(held != nullptr);
    pool.study_trim_bulk_idle_cache();
    CHECK_EQ(pool.bulk_cached_count, 127u);
    pool.free_written(held, 0);
    for (u32 i = 0; i != 8; ++i) {
        pool.study_trim_bulk_idle_cache();
        CHECK_EQ(pool.bulk_cached_count, 128u - 8u * (i + 1));
    }
    CHECK(!pool.study_bulk_burst);
    CHECK_EQ(pool.study_bulk_borrowed, 0u);
    for (u32 i = 0; i != 128; ++i) {
        loans[i] = pool.alloc_bulk();
        REQUIRE(loans[i] != nullptr);
        for (u32 j = 0; j != 4096; ++j) CHECK_EQ(loans[i][j], 0u);
        for (u32 j = 0; j != i; ++j) CHECK(loans[i] != loans[j]);
    }
    for (u32 i = 0; i != 128; ++i) pool.free_written(loans[i], 0);
    for (u32 i = 0; i != 8; ++i) pool.study_trim_bulk_idle_cache();
    CHECK_EQ(pool.bulk_cached_count, 64u);
    pool.destroy();
}

TEST(response_body_chain, study_payload_offset_and_dirty_prefix_preserve_ordinary_zero) {
    SlicePool pool;
    REQUIRE(pool.init(8, 0, 0, 2).has_value());
    ResponseBodyChain chain;
    REQUIRE(chain.reserve_tail(pool, 0));
    const u32 capacity = ResponseBodyChain::payload_capacity(pool, chain.tail);
    CHECK_EQ(capacity + ResponseBodyChain::header_size(), SlicePool::kBulkSliceSize);
    if (ResponseBodyChain::header_size() == 64)
        CHECK_EQ(reinterpret_cast<uintptr_t>(chain.write_ptr(pool)) & 63u, 0u);
    __builtin_memset(chain.write_ptr(pool), 0x6D, capacity);
    chain.commit(capacity);
    CHECK_EQ(chain.front_size(), capacity);
    chain.release();
    REQUIRE(chain.reserve_tail(pool, 0));
    __builtin_memset(chain.write_ptr(pool), 0x31, 1024);
    chain.commit(1024);
    CHECK_EQ(chain.front_size(), 1024u);
    CHECK(chain.tail->dirty_end >= capacity);
    chain.release();
    u8* ordinary = pool.alloc_bulk();
    REQUIRE(ordinary != nullptr);
    for (u32 i = 0; i != SlicePool::kBulkSliceSize; ++i) CHECK_EQ(ordinary[i], 0u);
    pool.free(ordinary);
    pool.destroy();
}

TEST(response_body_chain, response_owned_bulk_reuse_preserves_dirty_high_water) {
    SlicePool pool;
    REQUIRE(pool.init(4, 0, SlicePool::kMaxCachedSlices, 1).has_value());
    ResponseBodyChain chain;
    REQUIRE(chain.reserve_tail(pool, 0));
    u8* const raw = reinterpret_cast<u8*>(chain.tail);
    u8* const bytes = chain.write_ptr(pool);
    constexpr u32 kOld = 200 * 1024;
    __builtin_memset(bytes, 0x5a, kOld);
    chain.commit(kOld);
    chain.consume(kOld, false, true);
    CHECK_EQ(chain.size, 0u);
    CHECK_EQ(chain.head, nullptr);
    CHECK_EQ(reinterpret_cast<u8*>(chain.recycled), raw);
    CHECK_EQ(pool.bulk_available(), 0u);
    REQUIRE(chain.reserve_tail(pool, 0));
    CHECK_EQ(reinterpret_cast<u8*>(chain.tail), raw);
    CHECK_EQ(chain.front_size(), 0u);
    CHECK_EQ(chain.recycled, nullptr);
    __builtin_memset(chain.write_ptr(pool), 0x3c, 4096);
    REQUIRE(chain.record_direct_write(chain.tail, chain.write_ptr(pool), 4096, pool));
    chain.commit(128);
    chain.release();
    CHECK_EQ(pool.bulk_available(), 1u);
    u8* reused = pool.alloc_bulk();
    REQUIRE_EQ(reused, raw);
    bool zero = true;
    for (u32 i = 0; i < SlicePool::kBulkSliceSize; ++i) zero &= reused[i] == 0;
    CHECK(zero);
    pool.free(reused);
    pool.destroy();
}

TEST(response_body_chain, pinned_tail_is_not_recycled_before_recv_settles) {
    SlicePool pool;
    REQUIRE(pool.init(4, 0, SlicePool::kMaxCachedSlices, 1).has_value());
    ResponseBodyChain chain;
    REQUIRE(chain.reserve_tail(pool, 0));
    __builtin_memset(chain.write_ptr(pool), 0x5a, 128);
    chain.commit(128);
    auto* const node = chain.tail;
    chain.consume(128, true, true);
    CHECK_EQ(chain.head, node);
    CHECK_EQ(chain.recycled, nullptr);
    CHECK_EQ(chain.front_size(), 0u);
    __builtin_memset(chain.write_ptr(pool), 0x3c, 16);
    REQUIRE(chain.record_direct_write(node, chain.write_ptr(pool), 16, pool));
    chain.commit(16);
    chain.consume(16, false, true);
    CHECK_EQ(chain.recycled, node);
    CHECK_EQ(chain.head, nullptr);
    CHECK_EQ(pool.bulk_available(), 0u);
    chain.release_recycled();
    CHECK_EQ(pool.bulk_available(), 1u);
    CHECK_EQ(chain.owner, nullptr);
    chain.release();
    pool.destroy();
}

TEST(response_body_chain, body_cache_reuse_exposes_only_the_new_prefix) {
    SlicePool pool;
    REQUIRE(pool.init(4, 0, SlicePool::kMaxCachedSlices, 1).has_value());
    ResponseBodyChain first;
    REQUIRE(first.reserve_tail(pool, 0));
    u8* const raw = reinterpret_cast<u8*>(first.tail);
    constexpr u32 old_bytes = 128 * 1024;
    __builtin_memset(first.write_ptr(pool), 0xa5, old_bytes);
    first.commit(old_bytes);
    first.release();
    CHECK_EQ(pool.bulk_cached_count, 1u);

    ResponseBodyChain next;
    REQUIRE(next.reserve_tail(pool, 0));
    CHECK_EQ(reinterpret_cast<u8*>(next.tail), raw);
    CHECK_EQ(next.size, 0u);
    CHECK_EQ(next.front_size(), 0u);
    CHECK_EQ(next.tail->dirty_end, old_bytes);
    // Writable, uncommitted bytes may still contain the previous response.
    CHECK_EQ(next.write_ptr(pool)[old_bytes - 1], 0xa5);
    __builtin_memset(next.write_ptr(pool), 0x3c, 7);
    next.commit(7);
    CHECK_EQ(next.front_size(), 7u);
    for (u32 i = 0; i < next.front_size(); ++i) CHECK_EQ(next.data()[i], 0x3c);
    __builtin_memset(next.write_ptr(pool), 0x19, 11);
    REQUIRE(next.record_direct_write(next.tail, next.write_ptr(pool), 11, pool));
    next.release();

    u8* const ordinary = pool.alloc_bulk();
    REQUIRE_EQ(ordinary, raw);
    bool zero = true;
    for (u32 i = 0; i < SlicePool::kBulkSliceSize; ++i) zero &= ordinary[i] == 0;
    CHECK(zero);
    pool.free(ordinary);
    pool.destroy();
}

TEST(response_body_chain, dirty_body_append_rollback_preserves_the_full_old_high_water) {
    SlicePool pool;
    REQUIRE(pool.init(1, 0, SlicePool::kMaxCachedSlices, 1).has_value());
    ResponseBodyChain previous;
    REQUIRE(previous.reserve_tail(pool, 0));
    __builtin_memset(previous.write_ptr(pool), 0x5a, 200 * 1024);
    previous.commit(200 * 1024);
    previous.release();
    static u8 oversized[512 * 1024]{};
    ResponseBodyChain failed;
    CHECK_FALSE(failed.append(pool, oversized, sizeof(oversized), 0));
    CHECK_EQ(failed.head, nullptr);
    CHECK_EQ(failed.size, 0u);
    CHECK_EQ(pool.bulk_available(), 1u);
    u8* const ordinary = pool.alloc_bulk();
    REQUIRE(ordinary != nullptr);
    bool zero = true;
    for (u32 i = 0; i < SlicePool::kBulkSliceSize; ++i) zero &= ordinary[i] == 0;
    CHECK(zero);
    pool.free(ordinary);
    pool.destroy();
}

TEST(response_body_chain, body_cache_keeps_the_existing_idle_budget_and_index_bitmap) {
    constexpr u32 count = SlicePool::kMaxCachedBulk + 1;
    SlicePool pool;
    REQUIRE(pool.init(4, 0, SlicePool::kMaxCachedSlices, count).has_value());
    ResponseBodyChain chains[count];
    for (u32 i = 0; i < count; ++i) {
        REQUIRE(chains[i].reserve_tail(pool, 0));
        __builtin_memset(chains[i].write_ptr(pool), 0xa5, 37);
        chains[i].commit(37);
    }
    for (auto& chain : chains) chain.release();
    CHECK_EQ(pool.bulk_available(), count);
    CHECK_EQ(pool.bulk_cached_count, SlicePool::kMaxCachedBulk);
    u8* borrowed[count];
    for (u32 i = 0; i < count; ++i) {
        borrowed[i] = pool.alloc_bulk();
        REQUIRE(borrowed[i] != nullptr);
        for (u32 j = 0; j < 128; ++j) CHECK_EQ(borrowed[i][j], 0u);
    }
    CHECK_EQ(pool.bulk_available(), 0u);
    CHECK_EQ(pool.bulk_cached_count, 0u);
    for (auto* block : borrowed) pool.free(block);
    CHECK_EQ(pool.bulk_cached_count, SlicePool::kMaxCachedBulk);
    pool.destroy();
}

TEST(response_body_chain, malformed_body_cache_marker_scrubs_the_entire_ordinary_loan) {
    constexpr u32 markers[] = {0u, SlicePool::kBulkSliceSize + 1u};
    for (const u32 marker : markers) {
        SlicePool pool;
        REQUIRE(pool.init(4, 0, SlicePool::kMaxCachedSlices, 1).has_value());
        ResponseBodyChain chain;
        REQUIRE(chain.reserve_tail(pool, 0));
        u8* const raw = reinterpret_cast<u8*>(chain.tail);
        __builtin_memset(chain.write_ptr(pool), 0x5a, chain.write_avail(pool));
        chain.commit(chain.write_avail(pool));
        chain.release();
        __builtin_memcpy(raw, &marker, sizeof(marker));
        u8* const ordinary = pool.alloc_bulk();
        REQUIRE_EQ(ordinary, raw);
        bool zero = true;
        for (u32 i = 0; i < SlicePool::kBulkSliceSize; ++i) zero &= ordinary[i] == 0;
        CHECK(zero);
        pool.free(ordinary);
        pool.destroy();
    }
}

int main(int argc, char** argv) {
    return rut::test::run_all(argc, argv);
}

TEST(response_body_chain, fragmented_bytes_drain_without_copying_live_nodes) {
    SlicePool pool;
    REQUIRE(pool.init(80).has_value());
    ResponseBodyChain chain;
    u8 bytes[SlicePool::kSliceSize];
    for (u32 i = 0; i < sizeof(bytes); ++i) bytes[i] = static_cast<u8>(i * 17 + i / 251);
    for (u32 i = 0; i < 64; ++i) REQUIRE(chain.append(pool, bytes, sizeof(bytes)));
    CHECK_EQ(chain.size, ResponseBodyChain::kMaxBody);
    CHECK(!chain.append(pool, bytes, 1));
    u32 offset = 0;
    while (chain.size != 0) {
        const u8* address = chain.data();
        const u32 available = chain.front_size();
        const u32 n = available > 137 ? 137 : available;
        for (u32 i = 0; i < n; ++i) CHECK_EQ(address[i], bytes[(offset + i) % sizeof(bytes)]);
        chain.consume(n);
        if (n < available) CHECK(chain.data() == address + n);
        offset += n;
    }
    CHECK_EQ(offset, ResponseBodyChain::kMaxBody);
    CHECK_EQ(pool.in_use(), 0u);
    chain.release();
    pool.destroy();
}

TEST(response_body_chain, exhausted_reservation_is_atomic_and_reusable) {
    SlicePool pool;
    constexpr u32 kTestBulk = 4;
    REQUIRE(pool.init(2, 0, SlicePool::kMaxCachedSlices, kTestBulk).has_value());
    // Exercise slice exhaustion alone: take every bulk buffer first.
    u8* bulk[kTestBulk]{};
    for (u8*& b : bulk) REQUIRE((b = pool.alloc_bulk()) != nullptr);
    ResponseBodyChain chain;
    u8 bytes[SlicePool::kSliceSize]{};
    bytes[0] = 91;
    REQUIRE(chain.append(pool, bytes, 1));
    const u8* first = chain.data();
    // Needs two new slices; only one is available. No prefix may be appended.
    CHECK(!chain.append(pool, bytes, ResponseBodyChain::kPayload * 2));
    CHECK_EQ(chain.size, 1u);
    CHECK_EQ(pool.in_use(), 1u);
    CHECK(chain.data() == first);
    CHECK_EQ(chain.data()[0], 91);
    REQUIRE(chain.append(pool, bytes, sizeof(bytes)));
    CHECK_EQ(chain.size, 1u + sizeof(bytes));
    chain.release();
    CHECK_EQ(pool.in_use(), 0u);
    REQUIRE(chain.append(pool, bytes, 1));
    CHECK_EQ(chain.data()[0], 91);
    chain.release();
    for (u8* b : bulk) pool.free(b);
    pool.destroy();
}

TEST(response_body_chain, direct_dirty_extent_is_zeroed_without_logical_commit) {
    SlicePool pool;
    constexpr u32 kTestBulk = 1;
    REQUIRE(pool.init(2, 0, SlicePool::kMaxCachedSlices, kTestBulk).has_value());
    ResponseBodyChain chain;
    static u8 prefix[ResponseBodyChain::kPayload]{};
    REQUIRE(chain.append(pool, prefix, sizeof(prefix)));
    REQUIRE(chain.reserve_tail(pool));
    auto* node = chain.tail;
    REQUIRE(pool.is_bulk(reinterpret_cast<const u8*>(node)));
    u8* dst = chain.write_ptr(pool);
    constexpr u32 kDirty = 113;
    __builtin_memset(dst, 0xD3, kDirty);
    REQUIRE(chain.record_direct_write(node, dst, kDirty, pool));
    CHECK_EQ(chain.size, sizeof(prefix));
    CHECK_EQ(chain.tail->len, 0u);
    CHECK_EQ(chain.tail_dirty_end, kDirty);
    chain.release();

    u8* reused = pool.alloc_bulk();
    REQUIRE(reused != nullptr);
    for (u32 i = 0; i < ResponseBodyChain::kHeader + kDirty; ++i) CHECK_EQ(reused[i], 0u);
    pool.free(reused);
    pool.destroy();
}

TEST(response_body_chain, direct_dirty_extent_resets_when_tail_changes) {
    SlicePool pool;
    REQUIRE(pool.init(4).has_value());
    ResponseBodyChain chain;
    u8 prefix[ResponseBodyChain::kPayload];
    __builtin_memset(prefix, 0x31, sizeof(prefix));
    REQUIRE(chain.reserve_tail(pool));
    u8* dst = chain.write_ptr(pool);
    __builtin_memset(dst, 0xE7, 1);
    REQUIRE(chain.record_direct_write(chain.tail, dst, 1, pool));
    chain.commit(1);
    REQUIRE(chain.append(pool, prefix, sizeof(prefix) - 1u));
    REQUIRE(chain.append(pool, prefix, 1));
    REQUIRE(chain.tail != nullptr);
    CHECK_EQ(chain.tail->len, 1u);
    CHECK_EQ(chain.tail_dirty_end, 0u);
    chain.release();
    CHECK_EQ(pool.in_use(), 0u);
    pool.destroy();
}

TEST(response_body_chain, proven_large_body_moves_into_bulk_nodes) {
    SlicePool pool;
    constexpr u32 kTestBulk = 8;
    REQUIRE(pool.init(80, 0, SlicePool::kMaxCachedSlices, kTestBulk).has_value());
    ResponseBodyChain chain;
    static u8 body[ResponseBodyChain::kMaxBody];
    for (u32 i = 0; i < sizeof(body); ++i) body[i] = static_cast<u8>(i * 13 + i / 97);
    // The first receive fits one slice: it takes an ordinary slice.
    u32 stored = ResponseBodyChain::kPayload;
    REQUIRE(chain.append(pool, body, stored));
    CHECK_FALSE(pool.is_bulk(reinterpret_cast<const u8*>(chain.head)));
    CHECK_EQ(chain.front_size(), ResponseBodyChain::kPayload);
    // Once the body outgrew a slice, new nodes are bulk buffers.
    while (stored < sizeof(body)) {
        const u32 n = sizeof(body) - stored < SlicePool::kSliceSize ? sizeof(body) - stored
                                                                    : SlicePool::kSliceSize;
        REQUIRE(chain.append(pool, body + stored, n));
        stored += n;
    }
    CHECK_EQ(chain.size, ResponseBodyChain::kMaxBody);
    REQUIRE(chain.head->next != nullptr);
    CHECK(pool.is_bulk(reinterpret_cast<const u8*>(chain.head->next)));
    CHECK_LT(pool.bulk_available(), kTestBulk);
    CHECK(!chain.append(pool, body, 1));  // the body bound is unchanged
    u32 offset = 0;
    u32 largest_front = 0;
    while (chain.size != 0) {
        const u32 front = chain.front_size();
        if (front > largest_front) largest_front = front;
        CHECK_EQ(__builtin_memcmp(chain.data(), body + offset, front), 0);
        chain.consume(front);
        offset += front;
    }
    CHECK_EQ(offset, ResponseBodyChain::kMaxBody);
    CHECK_GT(largest_front, SlicePool::kSliceSize);  // sends leave in bulk steps
    CHECK_EQ(pool.in_use(), 0u);
    CHECK_EQ(pool.bulk_available(), kTestBulk);
    chain.release();
    pool.destroy();
}

TEST(response_body_chain, tls_threshold_keeps_short_bodies_in_slices) {
    SlicePool pool;
    constexpr u32 kTestBulk = 2;
    REQUIRE(pool.init(80, 0, SlicePool::kMaxCachedSlices, kTestBulk).has_value());
    ResponseBodyChain chain;
    static u8 body[ResponseBodyChain::kBulkAfterTls + ResponseBodyChain::kPayload];
    for (u32 i = 0; i < sizeof(body); ++i) body[i] = static_cast<u8>(i * 7 + i / 131);
    u32 stored = 0;
    while (stored < ResponseBodyChain::kBulkAfterTls) {
        REQUIRE(chain.append(
            pool, body + stored, ResponseBodyChain::kPayload, ResponseBodyChain::kBulkAfterTls));
        stored += ResponseBodyChain::kPayload;
    }
    CHECK_EQ(pool.bulk_available(), kTestBulk);  // still all slices
    REQUIRE(chain.append(
        pool, body + stored, ResponseBodyChain::kPayload, ResponseBodyChain::kBulkAfterTls));
    CHECK_EQ(pool.bulk_available(), kTestBulk - 1u);
    CHECK(pool.is_bulk(reinterpret_cast<const u8*>(chain.tail)));
    u32 offset = 0;
    while (chain.size != 0) {
        const u32 front = chain.front_size();
        CHECK_EQ(__builtin_memcmp(chain.data(), body + offset, front), 0);
        chain.consume(front);
        offset += front;
    }
    CHECK_EQ(offset, sizeof(body));
    CHECK_EQ(pool.bulk_available(), kTestBulk);
    chain.release();
    pool.destroy();
}
