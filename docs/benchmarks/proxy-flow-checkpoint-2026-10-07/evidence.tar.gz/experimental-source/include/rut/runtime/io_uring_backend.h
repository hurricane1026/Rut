#pragma once

#include "core/expected.h"
#include "rut/common/types.h"
#include "rut/runtime/buffered_send_vector.h"
#include "rut/runtime/connection_capacity.h"
#include "rut/runtime/error.h"
#include "rut/runtime/io_backend.h"
#include "rut/runtime/io_uring_init_failure.h"
#include "rut/runtime/mapped_array.h"
#include <atomic>

#include <errno.h>
#include <linux/io_uring.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace rut {

struct SlicePool;
struct ConnectionBase;              // forward declaration for wait() signature
using Connection = ConnectionBase;  // alias (matches connection.h)

// Direct io_uring backend — no liburing dependency.
// Uses raw syscalls for full control (~300 lines per DESIGN.md).
//
// io_uring features (Linux 6.0+). Currently enabled marked with [*]:
//   [*] IORING_ACCEPT_MULTISHOT   — one SQE continuously accepts
//   [*] IORING_RECV_MULTISHOT     — one SQE continuously receives per connection
//   [*] IOSQE_BUFFER_SELECT       — kernel picks buffer from provided ring
//   [ ] IORING_SETUP_SQPOLL       — kernel-side SQ polling (needs CAP_SYS_NICE)
//   [ ] IORING_OP_SEND_ZC         — zero-copy send (future optimization)
//   [*] IORING_SETUP_COOP_TASKRUN — cooperative task running (+ TASKRUN_FLAG)
//   [ ] IORING_SETUP_SINGLE_ISSUER — evaluated, not adopted (see below)
//   [ ] IORING_SETUP_DEFER_TASKRUN — evaluated, ~5% slower on accept-heavy
//                                    Connection: close (see below)
//
// wait() relies on IORING_SQ_TASKRUN (from TASKRUN_FLAG) so it never skips an
// enter while task work is pending.
//
// SINGLE_ISSUER / DEFER_TASKRUN evaluation (Linux 7.2.7, x86-64, 1 shard; see
// DESIGN.md §6.2). The ring is created before the shard thread exists, and
// SINGLE_ISSUER fixes the owning task before that thread exists, so adopting it
// needs IORING_SETUP_R_DISABLED plus IORING_REGISTER_ENABLE_RINGS from the shard
// thread (prototyped, works), with a fallback for kernels that reject the flags.
// Without DEFER_TASKRUN it enforces a single submitter, not exclusive access:
// submitting or registering from another thread fails with -EEXIST, so a loop
// can no longer be driven from a second thread (e.g. test helpers that settle a
// stopped shard). Throughput: SINGLE_ISSUER + COOP_TASKRUN was neutral;
// DEFER_TASKRUN was about 5% slower on accept-heavy `Connection: close` (128
// conns) and neutral on keep-alive workloads. Not adopted; revisit only with a
// workload where DEFER_TASKRUN is measured to win, and re-measure first. One
// shard = one ring = one submitting thread already holds by construction.
//
struct IoUringBackend {
    IoUringInitFailureDetail last_init_failure_detail = IoUringInitFailureDetail::None;
    SlicePool* response_pool = nullptr;
    // io_uring is async: the kernel may still access user buffers between
    // SQE submission and CQE completion. EventLoop uses this trait to
    // enable CQE-driven deferred slice reclamation (pending_ops tracking).
    static constexpr bool kAsyncIo = true;

    // Ring file descriptor
    i32 ring_fd = -1;

    // SQ ring mapped memory
    u32* sq_head = nullptr;
    u32* sq_tail = nullptr;
    u32* sq_flags = nullptr;
    u32* sq_ring_mask = nullptr;
    u32* sq_array = nullptr;
    io_uring_sqe* sq_entries = nullptr;
    u32 sq_ring_entries = 0;

    // CQ ring mapped memory
    u32* cq_head = nullptr;
    u32* cq_tail = nullptr;
    u32* cq_ring_mask = nullptr;
    io_uring_cqe* cq_entries = nullptr;
    u32 cq_ring_entries = 0;
    // Test seam (zero = flush, as the storage is mmap-zeroed): fixtures that fake a
    // full SQ by moving sq_tail and pending past what the kernel was given model a
    // flush that frees nothing; this keeps get_sqe_flushing() out of the kernel.
    bool disable_full_sq_flush = false;

    // Mapped regions (for cleanup)
    void* sq_ring_ptr = nullptr;
    u64 sq_ring_sz = 0;
    void* cq_ring_ptr = nullptr;
    u64 cq_ring_sz = 0;
    void* sqes_ptr = nullptr;
    u64 sqes_sz = 0;

    // Kernel supports IORING_NOP_INJECT_RESULT (probed at init); required to
    // complete a send that was written directly in full.
    bool nop_inject_result = false;

    // Provided buffer ring
    io_uring_buf_ring* buf_ring = nullptr;
    u8* buf_base = nullptr;  // kProvidedBufCount * kProvidedBufSize bytes

    // Dedicated ring for bounded one-shot upstream recvs (kLargeBufGroupId).
    // Optional: when registration fails those recvs use the ordinary ring.
    io_uring_buf_ring* large_buf_ring = nullptr;
    u8* large_buf_base = nullptr;  // kLargeProvidedBufCount * kLargeProvidedBufSize bytes

    // Listen socket
    i32 listen_fd = -1;

    // Timer fd for 1-second ticks (drives timer wheel, same as epoll backend)
    i32 timer_fd = -1;
    u64 timer_ticks_buf = 0;        // read target for IORING_OP_READ on timer_fd
    bool timer_read_armed = false;  // true if a timer read SQE is in-flight

    // Outstanding partial-send state per connection.
    // When IORING_OP_SEND completes partially, wait() re-submits the remainder.
    // Only emits Send completion when all bytes are sent (or error).
    static constexpr u32 kMaxSendState = kDefaultConnectionCapacity;
    struct SendState {
        const u8* src;
        i32 fd;
        u32 offset;
        u32 remaining;
        IoEventType type;
        u32 upstream_episode;
        u32 generation = 0;
        u32 msg_flags = 0;  // extra flags kept for partial-send resubmission
        // File-backed send (add_send_file): bytes come from file_fd at
        // file_base + offset via sendfile(2); src is unused. A pending
        // continuation is a POLLOUT poll whose CQE carries a poll mask, not
        // a byte count.
        i32 file_fd = -1;
        u32 file_base = 0;
        bool shutdown_when_done = false;  // end the stream once every byte is out
        BufferedSendVector* vector = nullptr;
        u32 study_zc_charge = 0;
        bool study_zc = false;
        bool study_notif_pending = false;
        i32 study_zc_result = 0;
    };
    u32 study_zc_live_bytes = 0;
    bool study_zc_disabled = false;
    u64 study_zc_fallbacks = 0;
    u64 study_zc_requests = 0;
    u64 study_zc_notifications = 0;
    u64 study_zc_copied = 0;
    MappedArray<SendState> send_state;
    MappedArray<SendState> upstream_send_state;
    u32 connection_capacity = 0;

    core::Expected<void, Error> init_send_state_storage(u32 capacity);
    void destroy_send_state_storage();

    // Pending SQE count (for submission)
    u32 pending = 0;

    // Sticky fatal error from io_uring_enter. A zero-event wait is otherwise a
    // legitimate result, so the event loop/control plane must inspect this
    // separately. The worker writes it; the control thread polls it.
    std::atomic<i32> fatal_error{0};

    // A downstream multishot recv can publish more than one positive CQE before
    // the event loop gets to dispatch the first one.  The backend must not copy
    // the later payload into the connection buffer early: doing so would let the
    // first callback observe bytes that are ordered after it.  Keep the exact
    // unadvanced CQ head here so the next wait can validate and resume it.
    struct DeferredDownstreamRecv {
        u64 user_data = 0;
        u32 head = 0;
        u32 frozen_tail = 0;
        bool active = false;
        bool prior_terminal = false;
    } deferred_downstream_recv;

    // A terminal CQE may be followed in the already-observed CQ interval by
    // stale positive selected-buffer records carrying the same generation-less
    // downstream recv target token.  Tagged cancel bookkeeping remains visible
    // to the event loop and owns an independent pending-op count.
    // Dispatching the terminal can rearm or reuse the numeric connection slot,
    // so only records strictly before the frozen tail are known to belong to
    // the old owner.
    //
    // A window stays live until head reaches its frozen tail, which can take
    // several wait() calls (each returns at most kMaxEventsPerWait events), so
    // the inventory is NOT bounded by one batch.  Expiry runs at the loop top
    // before every add, so head never steps past a live window's frozen tail.
    // cq_ring_entries is a safe bound on the live windows: every one was
    // recorded for a CQE consumed less than that far behind head.
    //
    // Structure (lookup and expiry are O(1)):
    //  - Windows are a FIFO ring over an mmap'd array of cq_ring_entries slots
    //    (a power of two): `start` is the oldest live window, `count` the live
    //    number.  Every window is appended with its wait() call's constant tail
    //    snapshot and snapshots never decrease across calls, so the ring is
    //    sorted by tail_exclusive and the expired windows are always a prefix.
    //    Expiry pops the front while front.tail_exclusive == head; only the
    //    front is distance-checked because head can never pass a later window
    //    without first passing the front.
    //  - Only an aux-0 downstream Recv CQE can match a window, and its token is
    //    a pure function of conn_id, so a side table indexed by conn_id
    //    (8 bytes per connection slot, mmap'd, demand-paged) records whether
    //    that token has a live window and its frozen tail.  At most one window
    //    is live per token: a duplicate terminal inside [head, frozen tail) is
    //    quarantined without adding one, and one at or after the frozen tail
    //    arrives only after the old window expired.  Adding a window for a
    //    token whose entry is already live is therefore a protocol failure.
    //  - A token whose conn_id is >= the side table size has no table entry;
    //    `out_of_range_windows` counts such live windows and lookups for those
    //    tokens scan the ring only while that counter is nonzero.
    struct DownstreamRecvTerminalWindow {
        u64 user_data = 0;
        u32 tail_exclusive = 0;
    }* downstream_recv_terminal_windows = nullptr;
    struct DownstreamRecvTerminalSlot {
        u32 tail_exclusive = 0;
        u32 live = 0;
    }* downstream_recv_terminal_slots = nullptr;
    u32 downstream_recv_terminal_window_capacity = 0;  // power of two
    u32 downstream_recv_terminal_window_start = 0;
    u32 downstream_recv_terminal_window_count = 0;
    u32 downstream_recv_terminal_slot_capacity = 0;
    u32 downstream_recv_terminal_out_of_range_windows = 0;
    u32 downstream_recv_progress_head = 0;
    bool downstream_recv_progress_valid = false;

    // --- Interface methods ---

    // Initialize the io_uring instance for this shard.
    core::Expected<void, Error> init(u32 shard_id,
                                     i32 listen_fd,
                                     u32 capacity = kDefaultConnectionCapacity);
    IoUringInitFailureDetail init_failure_detail() const { return last_init_failure_detail; }

    // Submit a multishot accept on the listen socket. Returns false if it could
    // not be armed (no SQE, no ring, or listener closed); the caller retries.
    // The kernel ends a multishot accept with a CQE lacking F_MORE, after which
    // the caller must re-arm.
    bool add_accept();

    // Submit a multishot recv with provided buffer selection.
    // No user buffer needed — kernel picks from provided ring.
    // Returns false if SQ is full (no SQE submitted).
    bool add_recv(i32 fd, u32 conn_id);

    // Same as add_recv but encodes UpstreamRecv in user_data so dispatch
    // can distinguish upstream vs client recv CQEs.
    bool add_recv_upstream(i32 fd, u32 conn_id, u32 upstream_episode = 1);
    // One-shot counterpart used by bounded HTTP/1 proxy profiles. It retains
    // provided-buffer selection and episode fencing but deliberately omits
    // IORING_RECV_MULTISHOT so each CQE is consumed before another upstream
    // buffer can be selected. max_len bounds the selected-buffer copy to the
    // current destination space; zero and values above upstream_once_max_len()
    // are rejected. Selects from the dedicated large ring when registered.
    bool add_recv_upstream_once(i32 fd,
                                u32 conn_id,
                                u32 upstream_episode = 1,
                                u32 max_len = kProvidedBufSize);
    // Direct one-shot recv: IORING_OP_RECV straight into a caller-owned
    // buffer region (sqe->addr/len), with no IOSQE_BUFFER_SELECT and no
    // provided-buffer ring involved — the kernel writes the bytes exactly
    // where dst points, so wait() commits them with no copy. Used only when
    // the destination is a bulk relay buffer (SlicePool::kBulkSliceSize);
    // ordinary slice-sized targets keep using the provided-buffer rings.
    //
    // Ownership contract: once this returns true, [dst, dst+len) is pinned —
    // the caller must not free or rebind that memory (e.g. trade the bulk
    // buffer back for a slice, or hand it to a different recv) until the
    // CQE for this exact recv has been consumed by wait(). wait() tracks
    // this per connection (Connection::upstream_recv_direct_armed) and
    // clears it only when that terminal CQE is processed — see the
    // rebinding guards in IoUringEventLoop (upgrade_upstream_recv_to_bulk,
    // release_upstream_relay_slice, take_relay_recv_buffer).
    //
    // Never MSG_WAITALL: the recv completes as soon as any bytes are
    // readable. Every caller needs each partial arrival as its own CQE —
    // the streaming relay/pump paths forward it, and the response-read
    // deadline refreshes its inactivity timer on it. A WAITALL recv hides
    // every intermediate arrival, so an origin that trickles steadily (each
    // gap under the timeout) but fills `len` more slowly than the timeout
    // would be expired as idle.
    bool add_recv_upstream_direct(i32 fd, u32 conn_id, u32 upstream_episode, u8* dst, u32 len);
    bool add_relay_poll(i32 fd, u32 conn_id, IoEventType type, u32 upstream_episode);
    // Dedicated single submission point for the bounded explicit
    // first-response deadline.  It intentionally does not inherit the ordinary
    // recv path's idempotent/deferred-rearm semantics.
    bool add_first_response_recv(i32 fd,
                                 u32 conn_id,
                                 u32 upstream_episode,
                                 bool separate_body_ring = false,
                                 bool one_shot = false);

    // Pause downstream recv while a send wait is pending.
    // The cancel completion is tagged so ownership is retained until it drains.
    bool pause_recv(i32 fd, u32 conn_id);
    // Cancel the multishot upstream recv by user_data (recv-only). The cancel's own
    // completion is tagged kPauseCancelAux so dispatch re-arms only once it drains.
    bool pause_upstream_recv(i32 fd, u32 conn_id, u32 upstream_episode = 1);
    // Exact-token cancel used by bounded upstream-episode retirement. The
    // cancel's own CQE retains the selected operation type and is tagged
    // separately from pause/rearm cancellation. Returns true only after the
    // cancel SQE has actually been queued.
    bool cancel_retiring_upstream(u32 conn_id, IoEventType type, u32 upstream_episode);
    bool cancel_retiring_upstream_recv(u32 conn_id, u32 upstream_episode) {
        return cancel_retiring_upstream(conn_id, IoEventType::UpstreamRecv, upstream_episode);
    }

    // Submit a send (or zero-copy send). more_follows adds MSG_MORE (also on
    // any partial-send resubmission): the caller submits more of the same
    // stream from this send's completion.
    // Returns false if SQ is full (no SQE submitted).
    bool add_send(i32 fd,
                  u32 conn_id,
                  const u8* buf,
                  u32 len,
                  u32 generation = 0,
                  bool more_follows = false,
                  BufferedSendVector* vector = nullptr);

    // Send `len` bytes of `file_fd` starting at `file_off` with sendfile(2):
    // page-cache pages go to the socket without a user-space copy. Writes
    // what the socket takes right away, then continues on POLLOUT inside
    // wait(); the Send completion reports the whole length, as add_send's
    // does. Returns false when no SQE is available or sendfile fails outright.
    // shutdown_when_done ends the write side as soon as the last byte is out
    // (a closing connection's final chunk: the FIN follows the data at once,
    // as nginx does); *wrote_all reports that sendfile took everything now.
    // When it did, shutdown_when_done is false (a keep-alive body that
    // finished in this one call), and the caller allows it
    // (allow_sync_completion — see IoUringEventLoop::submit_send_file, which
    // is the only decider: this is never inferred from nop_inject_result or
    // any other backend state), no SQE is queued at all — there is nothing to
    // complete through the ring, and the caller must account the send
    // synchronously. Otherwise (shutdown_when_done, or allow_sync_completion
    // is false because the caller is already inside a synchronous
    // completion) this always queues an SQE: an injected NOP when
    // nop_inject_result, otherwise the existing POLL_ADD path.
    bool add_send_file(i32 fd,
                       u32 conn_id,
                       i32 file_fd,
                       u32 file_off,
                       u32 len,
                       u32 generation = 0,
                       bool shutdown_when_done = false,
                       bool* wrote_all = nullptr,
                       bool allow_sync_completion = true);

    // Submit the currently staged SQ entries without waiting for a completion.
    // This is a bounded pressure-relief primitive: callers decide whether to
    // retry their failed operation, and must not loop here.  A sticky backend
    // error or an io_uring_enter failure is reported as false.
    [[nodiscard]] bool flush_pending_nonblocking();

#ifdef RUT_TESTING
    // Deterministic syscall seam for flush_pending_nonblocking().  The caller
    // supplies only the simulated io_uring_enter result; positive, in-range
    // results also advance the synthetic kernel SQ head by the consumed count.
    // All pending/error decisions remain in the production implementation.
    template <typename EnterResult>
    [[nodiscard]] bool test_flush_pending_nonblocking(EnterResult&& enter_result) {
        return flush_pending_nonblocking_impl([&](i32, u32 to_submit, u32, u32) {
            const i32 result = enter_result();
            if (result > 0 && static_cast<u32>(result) <= to_submit) {
                const u32 head = __atomic_load_n(sq_head, __ATOMIC_RELAXED);
                __atomic_store_n(sq_head, head + static_cast<u32>(result), __ATOMIC_RELEASE);
            }
            return result;
        });
    }
#endif

    // Same as add_send but encodes UpstreamSend in user_data.
    // True when get_sqe() can hand out at least one more SQE.
    bool sq_has_room() const {
        return __atomic_load_n(sq_tail, __ATOMIC_RELAXED) -
                   __atomic_load_n(sq_head, __ATOMIC_ACQUIRE) <
               sq_ring_entries;
    }

    // Complete a downstream send the caller already started with a direct
    // write of `written` bytes: a NOP injecting `len` when all bytes were
    // written, else a Send of the remainder whose completion reports `len`.
    bool add_send_after_direct_write(i32 fd,
                                     u32 conn_id,
                                     const u8* buf,
                                     u32 len,
                                     u32 written,
                                     u32 generation,
                                     BufferedSendVector* vector = nullptr,
                                     u32 extra_flags = 0);
    bool add_send_upstream(i32 fd, u32 conn_id, const u8* buf, u32 len, u32 upstream_episode = 1);

    // Submit a connect to upstream.
    // Returns false if SQ is full (no SQE submitted).
    bool add_connect(i32 fd, u32 conn_id, const void* addr, u32 addr_len, u32 upstream_episode = 1);

    // Submit IORING_OP_TIMEOUT for a JIT handler yield. ms granularity —
    // the timespec storage lives on the Connection because the kernel
    // reads it asynchronously. CQE completes with res == -ETIME under
    // normal expiry; the wait() path emits IoEvent{HandlerTimer, conn_id}
    // with IoEvent::result set to the connection's yield_timer_gen so
    // the dispatcher can reject stale timeout CQEs.
    bool add_yield_timeout(u32 conn_id, Connection& conn, u32 ms);

    // Submit/cancel the generic precise response-read timer. Ownership lives
    // entirely on Connection and is intentionally not pending_ops accounting.
    bool add_response_read_timer(u32 conn_id,
                                 Connection& conn,
                                 u32 milliseconds,
                                 u32 deadline_generation,
                                 u32 upstream_episode);
    bool cancel_response_read_timer(u32 conn_id, Connection& conn);

    // Cancel outstanding operations for a connection (by user_data match).
    // Only submits cancel SQEs for op types actually in flight.
    // Returns the number of cancel SQEs submitted (for pending_ops tracking).
    u32 cancel(i32 fd,
               u32 conn_id,
               bool recv_armed,
               bool send_armed,
               bool upstream_connect_armed,
               bool upstream_recv_armed,
               bool upstream_send_armed,
               bool has_upstream,
               u32 upstream_episode = 1,
               bool yield_armed = false,
               u32 yield_timer_gen = 0,
               u8* upstream_cancel_mask = nullptr,
               bool* send_cancel_owned = nullptr);

    bool cancel_yield_timeout(u32 conn_id, u32 yield_timer_gen);

    // Cancel the multishot accept request. Must be called before closing
    // listen_fd during drain to stop io_uring from accepting new connections.
    void cancel_accept();

    // Wait for completions. Returns number of events filled.
    // Calls io_uring_enter to submit pending SQEs and wait for CQEs.
    // conns: connection table — recv completions using provided buffers are
    // copied into conns[conn_id].recv_buf. max_conns: table size for bounds checking.
    u32 wait(IoEvent* events, u32 max_events, Connection* conns, u32 max_conns);

    i32 failure_code() const { return fatal_error.load(std::memory_order_acquire); }

    // Completions the kernel has posted that wait() has not harvested yet. Each
    // positive recv among them still holds its provided buffer, so this bounds
    // how many buffers are missing from the ring right now. CQEs parked on the
    // kernel overflow list also hold buffers and are not counted (only reachable
    // with more than cq_ring_entries outstanding CQEs).
    u32 cq_unharvested() const {
        if (cq_head == nullptr || cq_tail == nullptr) return 0;
        return __atomic_load_n(cq_tail, __ATOMIC_ACQUIRE) -
               __atomic_load_n(cq_head, __ATOMIC_ACQUIRE);
    }

    // Shutdown and unmap all resources.
    void shutdown();

    // Return a provided buffer back to the ring after processing.
    void return_buffer(u16 buf_id);

    // Provided buffer ids span the ordinary ring, then the dedicated large
    // ring — each only when it is registered. Bulk-buffer recvs never select
    // from a ring (see add_recv_upstream_direct), so there is no bulk id space.
    bool provided_buffer_id_valid(u16 buf_id) const {
        if (buf_id < kProvidedBufCount) return true;
        return large_buf_ring != nullptr && buf_id >= kLargeProvidedBufIdBase &&
               buf_id - kLargeProvidedBufIdBase < kLargeProvidedBufCount;
    }
    u32 provided_buffer_size(u16 buf_id) const {
        return buf_id < kProvidedBufCount ? kProvidedBufSize : kLargeProvidedBufSize;
    }
    const u8* provided_buffer_data(u16 buf_id) const {
        if (buf_id < kProvidedBufCount)
            return buf_base + static_cast<u64>(buf_id) * kProvidedBufSize;
        return large_buf_base +
               static_cast<u64>(buf_id - kLargeProvidedBufIdBase) * kLargeProvidedBufSize;
    }
    // Largest length a bounded one-shot *provided-buffer* upstream recv may
    // request. A bulk-sized target instead uses add_recv_upstream_direct,
    // which has no ring-size ceiling beyond the destination's own capacity.
    u32 upstream_once_max_len() const {
        return large_buf_ring != nullptr ? kLargeProvidedBufSize : kProvidedBufSize;
    }
#ifdef RUT_TESTING
public:
#else
private:
#endif
    // Encode/decode SQE user_data. Production callers should continue using the
    // typed submit/cancel helpers.
    static u64 encode_user_data(u32 conn_id, IoEventType type);
    static u64 encode_user_data(u32 conn_id, IoEventType type, u32 aux);
    static u64 encode_upstream_user_data(u32 conn_id,
                                         IoEventType type,
                                         u32 upstream_episode,
                                         u8 aux = 0);
    static void decode_user_data(u64 data, u32& conn_id, IoEventType& type);
    static void decode_user_data(u64 data, u32& conn_id, IoEventType& type, u32& aux);
    static void decode_user_data(
        u64 data, u32& conn_id, IoEventType& type, u32& aux, u32& upstream_episode);

private:
    template <typename Enter>
    [[nodiscard]] bool flush_pending_nonblocking_impl(Enter&& enter) {
        if (failure_code() != 0) return false;
        if (pending == 0) return true;

        const i32 flushed = enter(ring_fd, pending, 0, IORING_ENTER_SQ_WAKEUP);
        if (flushed < 0) {
            record_enter_error(flushed);
            return false;
        }
        if (static_cast<u32>(flushed) > pending) {
            fatal_error.store(EPROTO, std::memory_order_release);
            return false;
        }
        pending -= static_cast<u32>(flushed);
        return true;
    }

    // Submit a cancel SQE matching a specific user_data value.
    // conn_id/type/aux are encoded in the cancel CQE's user_data. Pass the real
    // conn_id for tracked close-path cancels, or kCancelConnId for fire-and-
    // forget cancels that should be consumed silently.
    bool cancel_by_user_data(
        u64 target, u32 conn_id, IoEventType type, u32 aux = 0, u32 upstream_episode = 0);

    // Get next available SQE. Returns nullptr if SQ is full.
    io_uring_sqe* get_sqe();
    // get_sqe(), flushing the queued SQEs and retrying once when the SQ is full.
    io_uring_sqe* get_sqe_flushing();

    // Setup provided buffer ring via io_uring_register.
    core::Expected<void, Error> setup_buf_ring();
    // Setup the optional dedicated large ring; failure leaves it unset.
    // Register an optional extra provided-buffer ring; on any failure the ring
    // stays absent (ring/base untouched) and callers fall back.
    void setup_extra_buf_ring(
        u32 count, u32 size, u16 group, u32 id_base, io_uring_buf_ring*& ring_out, u8*& base_out);
    // Detect IORING_NOP_INJECT_RESULT support (Linux 6.10+).
    void probe_nop_inject_result();

    // Submit IORING_OP_READ on timer_fd to receive next tick.
    void submit_timer_read();

    void record_enter_error(i32 result) {
        if (result < 0 && result != -EINTR) fatal_error.store(-result, std::memory_order_release);
    }

    // conn_id of a window's token, via the same decode the CQE path uses.
    static u32 terminal_window_conn_id(u64 user_data) {
        u32 conn_id = 0;
        IoEventType type = IoEventType::Count;
        decode_user_data(user_data, conn_id, type);
        return conn_id;
    }

    void reset_downstream_recv_wait_state() {
        deferred_downstream_recv = {};
        // Defensive: both current callers make the table clearing a no-op
        // (init() runs it with the table not yet allocated, shutdown() unmaps the
        // table right after).  It exists so a future caller that resets without
        // unmapping stays correct.  Walks only the live windows, never the table.
        if (downstream_recv_terminal_windows != nullptr) {
            const u32 ring_mask = downstream_recv_terminal_window_capacity - 1u;
            for (u32 i = 0; i < downstream_recv_terminal_window_count; i++) {
                auto& window =
                    downstream_recv_terminal_windows[(downstream_recv_terminal_window_start + i) &
                                                     ring_mask];
                const u32 conn_id = terminal_window_conn_id(window.user_data);
                if (downstream_recv_terminal_slots != nullptr &&
                    conn_id < downstream_recv_terminal_slot_capacity)
                    downstream_recv_terminal_slots[conn_id] = {};
                window = {};
            }
        }
        downstream_recv_terminal_window_start = 0;
        downstream_recv_terminal_window_count = 0;
        downstream_recv_terminal_out_of_range_windows = 0;
        downstream_recv_progress_head = 0;
        downstream_recv_progress_valid = false;
    }
};

}  // namespace rut
