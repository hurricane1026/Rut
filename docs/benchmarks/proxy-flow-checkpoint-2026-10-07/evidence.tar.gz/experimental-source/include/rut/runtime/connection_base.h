#pragma once

#include "rut/common/buffer.h"
#include "rut/common/failure_policy.h"
#include "rut/common/forward_target_transform.h"
#include "rut/common/http_header_validation.h"
#include "rut/common/request_policy.h"
#include "rut/common/types.h"
#include "rut/common/wait_limits.h"
#include "rut/jit/handler_abi.h"
#include "rut/runtime/access_log.h"
#include "rut/runtime/buffered_send_vector.h"
#include "rut/runtime/chunked_parser.h"
#include "rut/runtime/http_parser.h"
#include "rut/runtime/io_event.h"
#include "rut/runtime/listener_context.h"
#include "rut/runtime/response_body_chain.h"
#include "rut/runtime/tls_engine.h"
#include "rut/runtime/ws_terminate.h"

#ifdef __linux__
#include <linux/time_types.h>
#else
#include <time.h>
#endif
#include <openssl/base.h>

namespace rut {

#ifdef __linux__
using IoTimespec = __kernel_timespec;
#else
using IoTimespec = timespec;
#endif

struct RouteConfig;  // forward for per-request config pin below
struct Http2Conn;    // forward: per-connection HTTP/2 engine, pool-allocated

enum class BodyMode : u8 {
    None,           // No body
    ContentLength,  // Known size via Content-Length
    Chunked,        // Transfer-Encoding: chunked
    UntilClose,     // Read until EOF (HTTP/1.0)
};

// io_uring only: while a streamed request body is being forwarded upstream and
// nothing consumes recv_buf, the downstream multishot recv is paused once fewer
// than this many bytes of room remain (two provided buffers, see kProvidedBufSize
// in io_backend.h), leaving slack for CQEs already in flight. Resumed when the
// upstream send completes and the sent prefix is dropped.
inline constexpr u32 kRequestBodyRecvHeadroom = 8192;

// True when the loop's backend completes recvs asynchronously into provided buffers
// (io_uring: kAsyncIo). Gates the request-body pause / 413 logic, which only exists
// there; a sync mock loop that merely defines pause_recv must not run it.
template <typename Loop>
constexpr bool loop_backend_async_io() {
    if constexpr (requires { decltype(Loop::backend)::kAsyncIo; }) {
        return decltype(Loop::backend)::kAsyncIo;
    } else {
        return false;
    }
}

// Active wire protocol on a connection, fixed after the TLS handshake from the
// ALPN result (plaintext connections stay Http11). Drives parse/serialize path.
enum class ConnProtocol : u8 {
    Http11,
    Http2,
};

enum class ConnState : u8 {
    Idle,
    ReadingHeader,
    ReadingBody,
    ExecHandler,
    Proxying,
    Sending,
    Count,
};

enum class ResponseReadDeadlineState : u8 {
    None,
    Preflight,
    Validated,
    Armed,
    ExpiryPending,
    BatchPending,
    RefreshPending,
    BodyComplete,
};

enum class ResponseReadDeadlinePostCommitPhase : u8 {
    None,
    // The strict response header is pinned, but no downstream byte has been
    // published.  Positive Content-Length bytes remain behind the header in
    // upstream_recv_buf until a terminal buffering disposition is selected.
    Buffering,
    HeaderSend,
    BodySend,
    WaitingBody,
    OriginComplete,
    CombinedSend,
};

enum class CompleteContentLengthResponseClass : u8 {
    Unsupported,
    BoundedPositiveBody,
    CoherentSingleRange206,
};

enum class ResponseReadDeadlineSendKind : u8 {
    None,
    Header,
    Body,
    Combined,
};

// Kernel ownership for the generic precise response-read timer. CancelPending
// retains the immutable identity until both the timeout target and the cancel
// SQE completions have been harvested, in either order.
enum class ResponseReadTimerPhase : u8 {
    None,
    Armed,
    CancelPending,
};

// Immutable request/response contract selected before the JIT handler runs.
// The profile is part of every explicit-deadline ownership proof; method tests
// outside the centralized classifier must never widen this domain.
enum class ResponseReadDeadlineProfile : u8 {
    None,
    HeaderOnlyHead,
    BodylessNonHeadContentLengthZero,
    FixedContentLengthUploadNonHeadContentLengthZero,
    FixedContentLengthUploadHeaderOnlyHead,
};

static_assert(sizeof(ResponseReadDeadlineProfile) == sizeof(u8));

[[nodiscard]] constexpr bool response_read_deadline_profile_is_fixed_upload(
    ResponseReadDeadlineProfile profile) {
    switch (profile) {
        case ResponseReadDeadlineProfile::FixedContentLengthUploadNonHeadContentLengthZero:
        case ResponseReadDeadlineProfile::FixedContentLengthUploadHeaderOnlyHead:
            return true;
        case ResponseReadDeadlineProfile::None:
        case ResponseReadDeadlineProfile::HeaderOnlyHead:
        case ResponseReadDeadlineProfile::BodylessNonHeadContentLengthZero:
            return false;
    }
    return false;
}

[[nodiscard]] constexpr bool response_read_deadline_profile_suppresses_head(
    ResponseReadDeadlineProfile profile) {
    switch (profile) {
        case ResponseReadDeadlineProfile::HeaderOnlyHead:
        case ResponseReadDeadlineProfile::FixedContentLengthUploadHeaderOnlyHead:
            return true;
        case ResponseReadDeadlineProfile::None:
        case ResponseReadDeadlineProfile::BodylessNonHeadContentLengthZero:
        case ResponseReadDeadlineProfile::FixedContentLengthUploadNonHeadContentLengthZero:
            return false;
    }
    return false;
}

// Immutable request-upload identity for the bounded fixed-Content-Length
// explicit-deadline profile. The active, first-response-batch, and D1/D2
// copies are compared byte-for-byte by field so no transition can manufacture
// a body/upload proof after the original request bytes have been released.
struct ResponseReadDeadlineUploadProof {
    u32 handler_generation = 0;
    u32 raw_header_end = 0;
    u32 raw_content_length = 0;
    u32 raw_total_length = 0;
    u32 rewritten_header_end = 0;
    u32 rewritten_total_length = 0;
    u32 upload_episode = 0;
    u32 expected_upload_length = 0;
    u16 route_index = 0xffffu;
    u16 upstream_id = 0xffffu;
    u16 request_policy_id = 0;
    jit::HandlerFn route_fn = nullptr;
    // Parser-proven downstream persistence intent. This is admitted only for
    // the complete-Content-Length bodyless non-HEAD profile and remains part
    // of the same immutable request-policy identity across every phase.
    bool downstream_close = false;

    template <typename Self, typename Visitor>
    static void visit_owner_fields(Self& proof, Visitor&& visit) {
        visit(proof.handler_generation, u32{0});
        visit(proof.raw_header_end, u32{0});
        visit(proof.raw_content_length, u32{0});
        visit(proof.raw_total_length, u32{0});
        visit(proof.rewritten_header_end, u32{0});
        visit(proof.rewritten_total_length, u32{0});
        visit(proof.upload_episode, u32{0});
        visit(proof.expected_upload_length, u32{0});
        visit(proof.route_index, u16{0xffffu});
        visit(proof.upstream_id, u16{0xffffu});
        visit(proof.request_policy_id, u16{0});
        visit(proof.route_fn, static_cast<jit::HandlerFn>(nullptr));
        visit(proof.downstream_close, false);
    }

    [[nodiscard]] bool owner_is_neutral() const {
        bool neutral = true;
        visit_owner_fields(*this, [&](const auto& value, const auto& reset_value) {
            neutral = neutral && value == reset_value;
        });
        return neutral;
    }

    void clear_owner() {
        visit_owner_fields(*this,
                           [](auto& value, const auto& reset_value) { value = reset_value; });
    }
};

enum class Http1PrebuiltResponseLayout : u8 {
    None,
    HeaderOnlyHead,
    HeaderOnlyNoBodyStatus,
    FullContentLengthNonHead,
};

enum class Http1PrebuiltResponsePurpose : u8 {
    None,
    StrictHeadHeaderOnly,
    StrictNoBodyMetadataSuccess,
    StrictNonHeadCl0Success,
    ResponseReadTimeout,
    ConfiguredForwardFailure,
};

// Request-buffer ownership captured by the internal HTTP/1 prebuilt-response
// rendezvous.  The value describes where request 1 still lives while an old
// upstream episode and the downstream header send drain independently.
enum class Http1RequestBufferDisposition : u8 {
    None,
    PrefixInRecv,
    RetrySendBuf,
    ExistingPipeline,
};

static constexpr u8 kHttp1WaitHeaderSend = 1u << 0;
static constexpr u8 kHttp1WaitUpstreamRetirement = 1u << 1;

enum class RawRequestTargetWitnessState : u8 {
    Neutral,
    Invalid,
    Valid,
};

struct RawRequestTargetWitnessResult {
    RawRequestTargetWitnessState state;
    Str target;
};

static_assert(static_cast<u8>(ConnState::Count) == 6u,
              "ConnState count is part of the static network state contract");

// Transport ownership for a direct upstream recv targeting a complete-buffered
// response chain. The CQE uses this immutable snapshot even after connection
// teardown resets the logical response-deadline state.
struct ChainDirectRecvOwner {
    ResponseBodyChain::Node* node = nullptr;
    u8* ptr = nullptr;
    u32 len = 0;
    u32 episode = 0;
    bool active = false;
};

enum class RelayPhase : u8 { Idle, Reading, Writing, Closing };

// One serialized upstream->pipe->downstream response segment.  The owner is
// deliberately independent from UpstreamRecv/SendState: a splice completion
// must never commit bytes to an upstream buffer or advance the ordinary send
// proactor.
struct RelayOwner {
    i32 pipe_read = -1;
    i32 pipe_write = -1;
    RelayPhase phase = RelayPhase::Idle;
    u32 upstream_episode = 0;
    i32 source_fd = -1;
    i32 destination_fd = -1;
    u32 segment_len = 0;
    u32 segment_sent = 0;
    u32 body_bytes = 0;
    bool read_armed = false;
    bool write_armed = false;
    bool close_pending = false;
    bool read_cancel_retry = false;
    bool write_cancel_retry = false;
    bool read_cancel_owned = false;
    bool write_cancel_owned = false;
    bool admit_after_prefix = false;
    // Set only when the first relay poll could not be admitted.  The caller
    // may then decline to the ordinary copy path; once a byte was pulled the
    // same failure is terminal and never sets this marker.
    bool initial_declined = false;
    bool active() const { return phase != RelayPhase::Idle; }
};

struct ConnectionBase {
    static constexpr u32 kMaxReqPathLen = 64;
    static constexpr u32 kMaxUpstreamNameLen = 24;
    static constexpr u16 kMaxPipelineDepth = 16;
    // Keep persistent wait fields coupled to the shared route wait limit:
    // every wait stores kind/result in two i64 slots.
    static constexpr u32 kMaxJitHandlerSlots = rut::kMaxJitHandlerSlots;
    static_assert(kMaxJitHandlerSlots >= 2u, "JIT wait frame must hold at least one wait result");
    // Event callback type — void* loop to avoid circular dependency.
    using Callback = void (*)(void* loop, ConnectionBase& conn, IoEvent ev);

    // Per-event-type callback slots (Seastar-inspired).
    // Each slot receives ONLY its designated event type. The dispatch
    // layer routes events to the correct slot and handles null slots
    // centrally (drain/ignore/close). No event-type guard code needed
    // inside callbacks.
    Callback on_recv;           // IoEventType::Recv only
    Callback on_send;           // IoEventType::Send only
    Callback on_upstream_recv;  // IoEventType::UpstreamRecv only
    Callback on_upstream_send;  // IoEventType::UpstreamSend + UpstreamConnect

    // Set all 4 slots atomically. Full state transitions MUST use this
    // to prevent stale callbacks in slots that aren't explicitly changed.
    void set_slots(Callback recv, Callback send, Callback up_recv, Callback up_send) {
        if (uses_iouring_tls()) {
            tls_pending_on_recv = recv;
        } else {
            on_recv = recv;
        }
        on_send = send;
        on_upstream_recv = up_recv;
        on_upstream_send = up_send;
    }

    void clear_slots() { set_slots(nullptr, nullptr, nullptr, nullptr); }

    void transition_to_reading_header(Callback recv) {
        state = ConnState::ReadingHeader;
        set_slots(recv, nullptr, nullptr, nullptr);
    }

    void transition_to_reading_body(Callback recv) {
        state = ConnState::ReadingBody;
        set_slots(recv, nullptr, nullptr, nullptr);
    }

    void transition_to_sending(Callback send) {
        state = ConnState::Sending;
        set_slots(nullptr, send, nullptr, nullptr);
    }

    void transition_to_exec_handler_wait() {
        state = ConnState::ExecHandler;
        clear_slots();
    }

    bool uses_iouring_tls() const { return tls_active && tls_engine.ssl != nullptr; }

    // Check if any slot is active (for dispatch guard).
    bool has_active_slot() const {
        return on_recv || on_send || on_upstream_recv || on_upstream_send;
    }

    i32 fd;
    u32 id;
    ConnState state;  // for debugging/metrics only
    u8 shard_id;
    u16 flags;
    u16 timer_slot;
    // Idle-buffer trim mark (io_uring sweep only; see IoUringEventLoop::
    // sweep_idle_trim): this connection's timer node has been examined since it
    // was last armed. Cleared by TimerWheel::add (every arm and re-arm goes
    // through it), set only by the 1 Hz sweep. Kept beside timer_node so the clear
    // lands on the cache line the arm already dirties (static_assert in
    // timer_wheel.cc).
    bool idle_trim_examined;
    ListNode timer_node;
    ListNode idle_node;

    // Upstream (only when proxying)
    i32 upstream_fd;
    u16 upstream_idx;
    u8 upstream_attempts;     // connect attempts so far (initial + retries) this request
    u8 upstream_backend_idx;  // which backend endpoint the current connect targets
    bool proxy_resp_started;  // true once upstream response bytes were sent to the client
    bool upstream_abandoned;  // gave up on the upstream (timeout); ignore late upstream CQEs
    // io_uring: a request-body CQE overflowed recv_buf and the client was refused with
    // 413 (respond_request_body_overflow); later recv errors must not cut that response.
    bool req_body_overflow_rejected;
    // A lossy downstream CQE discarded bytes after the complete current body.
    // Only this provenance permits dropping a pipelined successor on completion.
    bool req_body_lossy_successor;
    // An early upstream response ended the upload: the rest of the request body is
    // read and dropped, never forwarded (prepare_early_response_state).
    bool req_body_abandoned;
    // HTTP/1 idle upstream reuse: `upstream_keep_alive` is set when the upstream
    // response is parsed iff its connection may be reused (keep-alive, not
    // close-delimited) — the completion path then returns the fd to the per-shard
    // idle pool instead of closing it. `upstream_reused` marks a request whose
    // upstream socket came from that pool, so a send/recv failure before any
    // response byte can fall back to a fresh connect (idempotent methods only).
    bool upstream_keep_alive;
    bool upstream_reused;
    // Set when a request-body write to the upstream FAILS (initial forward or a
    // streamed chunk) so the upload was not fully delivered. The body counters
    // (req_body_remaining / req_chunk_parser) are advanced before the send is
    // submitted, so they can read "complete" even though those bytes never landed;
    // this flag is the authoritative "upload finished cleanly" signal that
    // proxy_upstream_reusable consults before pooling — a socket whose upload
    // desynced must never be reused (the next request would be parsed as leftover
    // body). Reset at the per-request boundary like the other reuse flags.
    bool upstream_request_incomplete;
    // io_uring-only deferred idle-pool return: an upstream fd to park in the pool
    // once its cancelled multishot recv terminal drains (handing the fd out while a
    // recv is still draining on it would let two recvs race the same socket). -1 =
    // none. epoll detaches synchronously and never uses this. See
    // IoUringEventLoop::return_idle_upstream / try_deferred_upstream_rearm.
    i32 idle_return_fd;
    u16 idle_return_uid;
    u8 idle_return_bidx;
    // Active RouteConfig pinned when idle_return_fd was parked (return_idle_upstream).
    // A hot reload can land while the cancelled recv is still draining; poll_command
    // only drains sockets ALREADY in the pool, so the deferred fd would escape that
    // drain and later be put_idle'd into the freshly-drained pool under a now-stale
    // (upstream_id, backend_idx). try_deferred_upstream_rearm compares this against the
    // live config and CLOSES instead of pooling on mismatch. request_config can't be
    // reused: the keep-alive client repoints it on its next request while this drains.
    // Pointer-identity token only (never dereferenced, no epoch held); cleared together
    // with idle_return_fd at every site that resolves the parked fd. (The clear in
    // close_conn_impl's already-drained branch is defensive: the slot's reset() clears it
    // anyway when the slot is reused.)
    const RouteConfig* idle_return_config;
    // io_uring-only deferred close: close_conn was called on a conn whose deferred
    // idle-pool return (idle_return_fd) had not yet drained its cancelled recv. Rather
    // than discard the still-reusable upstream fd (and free the slot), the conn is kept
    // allocated with this set; once the recv drains, try_deferred_upstream_rearm parks
    // the fd in the pool AND performs the slot-free close_conn deferred. See
    // IoUringEventLoop::close_conn_impl / try_deferred_upstream_rearm.
    bool close_after_idle_return;
    // Active health-check probe (slice 2, epoll only): this Connection is not a
    // real client request but a built-in periodic HTTP probe to one upstream
    // backend (fd == -1, no downstream; upstream_fd is the probe socket). Gates
    // close_conn to the minimal probe teardown (no metrics/epoch/access-log).
    bool is_health_probe;
    // io_uring h2-proxy reuse guards (epoll is synchronous → both stay false there).
    // h2_proxy_recv_draining: a multishot upstream recv from a torn-down h2 proxy
    // episode may still deliver a terminal CQE; the next episode must not arm its
    // own recv (which shares the conn_id/type user_data) until that terminal drains,
    // or the stale CQE would be misrouted to the new stream. Cleared when the
    // terminal is accounted in dispatch.
    bool h2_proxy_recv_draining;
    // h2_proxy_synth_quarantined: an upstream request send was still in flight when
    // an h2 proxy episode was torn down (timeout). The send SQE still sources
    // pending_synth, so a subsequent request must not overwrite it until that send
    // CQE drains. Cleared when the stale UpstreamSend terminal is accounted.
    bool h2_proxy_synth_quarantined;
    // forward(set_path:) request mutation: a JIT handler may rewrite the request
    // path before proxying. The runtime helper records the new path (a view into
    // stable JIT constant memory); on_upstream_connected rewrites the request
    // line in recv_buf before forwarding. Reset per request.
    bool req_path_overridden;
    Str req_path_override;
    // Foundation-only target-transform effect. The recorded flag distinguishes
    // no effect from a forged zero/sentinel ID; every recorded effect is rejected
    // before upstream selection until target materialization exists.
    u16 target_transform_id;
    bool target_transform_recorded;
    // forward(set_header:) request mutation: rut_helper_req_set_header records
    // (name, value) overrides (views into stable JIT constant memory);
    // on_upstream_connected injects/replaces those header lines in recv_buf before
    // forwarding. Bounded; reset per request. No default member initializers, so
    // the struct stays trivially constructible for the SlabPool.
    static constexpr u32 kMaxReqHeaderOverrides = 16;
    struct ReqHeaderOverride {
        Str name;
        Str value;
    };
    ReqHeaderOverride req_header_overrides[kMaxReqHeaderOverrides];
    u8 req_header_override_count;
    // Bit i selects append semantics (`req.add`) for override slot i; clear
    // means replace/dedupe (`req.set`).
    u16 req_header_append_mask;
    // Set when rut_helper_req_set_header is called past kMaxReqHeaderOverrides
    // (reachable only via direct RIR — the DSL caps + dedupes entries). The apply
    // path fails the request closed so a dropped override can't be forwarded as a
    // silent no-op. Reset per request alongside the count.
    bool req_header_override_overflow;
    // Ordered response-header mutations recorded by compiled Response builders.
    // Forward paths re-anchor request-backed values into a stable request snapshot
    // before recv_buf is released.
    static constexpr u32 kMaxRespHeaderMutations = 16;
    enum class RespHeaderMutationMode : u8 { Set, Add, Remove };
    struct RespHeaderMutation {
        Str name;
        Str value;
        RespHeaderMutationMode mode;
    };
    RespHeaderMutation resp_header_mutations[kMaxRespHeaderMutations];
    // Helpers append to the pending builder-local prefix so resp.header() can
    // observe source order. Only return of that builder publishes it.
    u8 resp_header_mutation_pending_count;
    bool resp_header_mutation_pending_overflow;
    u8 resp_header_mutation_count;
    bool resp_header_mutation_overflow;
    // Lazy slice used to serialize mutated forwarded response headers separately
    // from upstream_recv_buf. Keeping the header block independent lets a full
    // upstream body buffer stream normally even when mutations grow the headers.
    u8* response_header_slice;
    Buffer response_header_buf;

    void reanchor_request_overrides(const u8* old_base, u32 old_len, const u8* new_base) {
        auto reanchor = [&](Str& value) {
            if (value.ptr == nullptr) return;
            const auto* ptr = reinterpret_cast<const u8*>(value.ptr);
            if (ptr < old_base || ptr + value.len > old_base + old_len) return;
            value.ptr = reinterpret_cast<const char*>(new_base + (ptr - old_base));
        };
        reanchor(req_path_override);
        for (u32 i = 0; i < req_header_override_count; i++) {
            reanchor(req_header_overrides[i].name);
            reanchor(req_header_overrides[i].value);
        }
    }

    void reanchor_response_mutations(const u8* old_base, u32 old_len, const u8* new_base) {
        for (u32 i = 0; i < resp_header_mutation_count; i++) {
            auto& value = resp_header_mutations[i].value;
            if (value.ptr == nullptr) continue;
            const auto* ptr = reinterpret_cast<const u8*>(value.ptr);
            if (ptr < old_base || ptr + value.len > old_base + old_len) continue;
            value.ptr = reinterpret_cast<const char*>(new_base + (ptr - old_base));
        }
    }

    // Copy request-backed mutation values out of a synthesized request before
    // HTTP/2 reuses its request scratch for the encoded response. Literal values
    // already live in JIT-owned storage and do not need copying.
    bool stabilize_response_mutations(const u8* source, u32 source_len) {
        auto survives_folding = [&](u32 index) {
            const auto& current = resp_header_mutations[index];
            if (current.mode == RespHeaderMutationMode::Remove) return false;
            for (u32 later_index = index + 1; later_index < resp_header_mutation_count;
                 later_index++) {
                const auto& later = resp_header_mutations[later_index];
                if (later.mode != RespHeaderMutationMode::Add &&
                    http_header_name_eq_ci(
                        current.name.ptr, current.name.len, later.name.ptr, later.name.len))
                    return false;
            }
            return true;
        };
        u32 needed = 0;
        for (u32 i = 0; i < resp_header_mutation_count; i++) {
            if (!survives_folding(i)) continue;
            const auto& value = resp_header_mutations[i].value;
            if (value.ptr == nullptr) continue;
            const auto* ptr = reinterpret_cast<const u8*>(value.ptr);
            if (ptr >= source && ptr + value.len <= source + source_len) needed += value.len;
        }
        if (needed > response_header_buf.capacity()) return false;
        response_header_buf.reset();
        for (u32 i = 0; i < resp_header_mutation_count; i++) {
            if (!survives_folding(i)) continue;
            auto& value = resp_header_mutations[i].value;
            if (value.ptr == nullptr) continue;
            const auto* ptr = reinterpret_cast<const u8*>(value.ptr);
            if (ptr < source || ptr + value.len > source + source_len) continue;
            const u32 offset = response_header_buf.len();
            if (response_header_buf.write(ptr, value.len) != value.len) return false;
            value.ptr = reinterpret_cast<const char*>(response_header_buf.data() + offset);
        }
        return true;
    }
    // Upstream concurrency slot: set true between try_acquire and release so the
    // slot is freed exactly once, on whatever exit path runs (completion, failure,
    // or close). `upstream_slot_uid` records which backend's gauge to decrement.
    bool upstream_slot_held;
    u16 upstream_slot_uid;

    // @throttle downstream pacing — per-connection token bucket (virtual-time /
    // GCRA) for sends to the client. Set per request from the matched route. The
    // proxy body pump advances `throttle_tat_ns` by sent_bytes × 1e9 / bps (full
    // precision; see client_send); when it runs ahead of real time the pump parks
    // for the exact deficit on the
    // per-shard precise timer, resumed by throttle_resume (see callbacks_impl.h).
    u32 throttle_down_bps;     // bytes/sec cap (0 = unthrottled); also the "enabled" flag
    u64 throttle_tat_ns;       // GCRA theoretical arrival time (monotonic ns)
    bool throttle_paused;      // pump parked waiting for byte-budget to recover
    u32 throttle_pending_len;  // buffered upstream bytes to replay on resume
    // After a 101 Switching Protocols response the connection becomes a
    // transparent full-duplex byte tunnel (WebSocket passthrough): the 4 slots
    // splice client↔upstream and the keepalive timeout no longer closes it.
    bool is_ws_tunnel;
    // WebSocket tunnel send state tracks the submitted prefix in each direction
    // so raced recv completions can leave later bytes buffered for the next send.
    bool ws_client_send_pending;
    bool ws_upstream_send_pending;
    // Bytes submitted for the current tunnel send. A best-effort recv pause can
    // still race with already-harvested CQEs, so completion must consume only
    // the submitted prefix and preserve later buffered bytes.
    u32 ws_client_send_len;
    u32 ws_upstream_send_len;
    // Bytes in the upstream's original 101 header block. This is the prefix
    // consumed from upstream_recv_buf after the (possibly rewritten) response
    // reaches the client.
    u32 ws_upgrade_response_len;
    // Bytes actually sent for the 101 header block after response mutations.
    // Access logging and capture account this length, not the upstream prefix.
    u32 ws_upgrade_sent_len;
    // Upstream closed during pre-tunnel 101 handling and should be closed once
    // tunnel mode is fully entered (after preserving buffered early bytes).
    bool ws_pre_tunnel_upstream_closed;
    // A tunnel peer half-closed (FIN/EOF) while its paired send was still
    // draining. Tear down only after the in-flight frame finishes flushing so
    // the last frame is not truncated: ws_client_eof gates the client→upstream
    // drain (on_ws_client_to_upstream_sent), ws_upstream_eof the upstream→client
    // drain (on_ws_upstream_to_client_sent).
    bool ws_client_eof;
    bool ws_upstream_eof;

    // WebSocket TERMINATE mode (vs the passthrough tunnel above). Set from the matched
    // route at request time; `is_ws_terminate` is armed at the 101 transition once the
    // per-direction inspection buffers are acquired. In terminate mode the data phase is
    // parsed/inspected/re-framed per message (ws_inspect) instead of spliced raw.
    bool is_ws_terminate_route;     // matched route requested terminate (vs passthrough)
    bool is_ws_terminate;           // active: 101 seen + inspection buffers acquired
    WsMessageHandlerFn ws_handler;  // per-message decision callback (route-supplied)
    u32 ws_max_message_size;        // reassembly cap; bounded to one slice (<=16KB-14)
    u16 ws_close_code;              // route's frame.close(code) status (seeds both inspectors)
    u16 ws_echo_close_code;         // code for the echo Close (set from the inspector on close)
    WsInspector ws_c2u;             // client->upstream inspection state (masked)
    WsInspector ws_u2c;             // upstream->client inspection state (unmasked)
    // Reassembly scratch, one per direction (pure CPU — never kernel-referenced, so freed
    // immediately on close). The re-framed output is written IN PLACE over the recv buffer
    // (ws_inspect's output is always <= its consumed input), so no separate output slice is
    // needed. ws_*_consumed remembers the unconsumed-tail start across an in-flight send so
    // the sent callback can compact the partial trailing frame to the front.
    u8* ws_c2u_msg = nullptr;  // client->upstream reassembly slice
    u8* ws_u2c_msg = nullptr;  // upstream->client reassembly slice
    u32 ws_c2u_consumed;       // recv_buf bytes consumed by the in-flight c->u send
    u32 ws_u2c_consumed;       // upstream_recv_buf bytes consumed by the in-flight u->c send
    // Bidirectional Close handshake (RFC 6455 §5.5.1). When a Close is determined (a peer
    // sent Close, or the handler returned Close), terminate sends a Close frame to BOTH
    // peers and tears the connection down only once both Close sends have drained — so a
    // policy/peer close is graceful (the initiating client sees a Close, not EOF/1006). Per
    // send slot: `_need` = a Close still to submit on this slot, `_inflight` = a Close is
    // draining on it. close_conn fires when ws_closing and neither need nor inflight is set
    // on either slot. The forward Close (emitted by ws_inspect) starts its slot _inflight;
    // the echo Close (built into ws_close_frame_*) is submitted on the opposite slot.
    bool ws_closing;
    bool ws_close_client_need;        // Close still to send on the client slot (u->c)
    bool ws_close_client_inflight;    // a Close is draining on the client slot
    bool ws_close_upstream_need;      // Close still to send on the upstream slot (c->u)
    bool ws_close_upstream_inflight;  // a Close is draining on the upstream slot
    u8 ws_close_frame_client[12];     // echo Close frame to the client (unmasked, persists during
                                      // send)
    u8 ws_close_frame_upstream[12];   // echo Close frame to the upstream (masked)

    // JIT handler state.
    //   handler_state: current state-machine index; handler reads this at
    //     entry and dispatches. On yield the runtime stores next_state here.
    //   handler_ctx:   points at handler_ctx_storage while a JIT handler is
    //     running. The first slots store wait result kind/result pairs across
    //     resume boundaries.
    //   pending_handler_fn: non-null while the handler has yielded and is
    //     waiting for its timer/io completion. The tick callback uses this
    //     to distinguish "resume JIT handler" from "keepalive expired,
    //     close connection". Reset to null on terminal outcome.
    u16 handler_state;
    jit::YieldKind pending_yield_kind;
    jit::YieldKind resume_event_kind;
    i32 resume_event_result;
    void* handler_ctx;
    jit::HandlerFn pending_handler_fn;
    alignas(alignof(u64)) u8 handler_ctx_storage[sizeof(jit::HandlerCtx) +
                                                 static_cast<size_t>(kMaxJitHandlerSlots) * 8]{};

    jit::HandlerCtx* reset_jit_ctx() {
        __builtin_memset(handler_ctx_storage, 0, sizeof(handler_ctx_storage));
        auto* ctx = reinterpret_cast<jit::HandlerCtx*>(handler_ctx_storage);
        ctx->slot_count = kMaxJitHandlerSlots;
        handler_ctx = ctx;
        return ctx;
    }

    jit::HandlerCtx* jit_ctx() {
        if (handler_ctx == nullptr) return reset_jit_ctx();
        return reinterpret_cast<jit::HandlerCtx*>(handler_ctx);
    }

    // Per-request generation counter. Incremented on every new request
    // (in on_header_received) so the epoll YieldHeap can filter out
    // stale entries left behind by a close+reuse that lands in the same
    // microsecond as the new request — req_start_us alone is not
    // strictly unique at μs granularity under close-during-yield churn.
    //
    // Default-initialized and deliberately NOT reset in reset(): the
    // counter must persist across slot reuse so every generation on a
    // given slot is distinct (first use: 0 → 1; reuse: N → N+1; …).
    u32 handler_gen = 0;

    // Reserved for upstream I/O episode fencing. Deliberately preserved by
    // reset()/slot reuse; the transport slices will advance it before each
    // upstream episode so stale completions cannot match a later episode.
    u32 upstream_episode = 1;

    // Fail-closed terminal state for an exhausted io_uring episode token. Like
    // upstream_episode, this deliberately survives reset(): a quarantined slot
    // must never return to the allocator or wrap back to an old kernel token.
    bool upstream_episode_quarantined = false;

    // Persistent generation plus current-owner metadata for the bounded
    // explicit first-response deadline.  The generation deliberately survives
    // reset()/slot reuse; active ownership does not.
    u32 response_read_deadline_generation = 0;
    u32 response_read_deadline_owner_generation;
    u32 response_read_deadline_upstream_episode;
    u16 response_read_deadline_bundle_id;
    u8 response_read_deadline_seconds;
    ForwardResponseBufferingMode response_read_deadline_buffering;
    ResponseReadDeadlineProfile response_read_deadline_profile;
    u8 response_read_deadline_method;
    u8 response_read_deadline_route_method;
    ResponseReadDeadlineState response_read_deadline_state;
    bool response_read_deadline_first_batch;
    ResponseReadDeadlineProfile response_read_deadline_first_batch_profile;
    u8 response_read_deadline_first_batch_method;
    u8 response_read_deadline_first_batch_route_method;
    u32 response_read_deadline_first_batch_generation;
    u16 response_read_deadline_first_batch_bundle_id;
    ForwardResponseBufferingMode response_read_deadline_first_batch_buffering;
    ResponseReadDeadlineUploadProof response_read_deadline_upload;
    ResponseReadDeadlineUploadProof response_read_deadline_first_batch_upload;
    // Exact cumulative positive-copy proof for the current deadline owner.
    // Set only after whole-batch witness validation and preserved across
    // incomplete-header re-arms; cleared with active deadline ownership.
    u32 response_read_deadline_progress_generation;
    u32 response_read_deadline_progress_episode;
    u32 response_read_deadline_progress_bytes;
    // Bounded positive-Content-Length response owner.  This is selected only
    // after the strict GET response header is fully validated.  The counters
    // are monotonic across recv-buffer compaction and downstream send gaps.
    ResponseReadDeadlinePostCommitPhase response_read_deadline_post_commit_phase;
    u32 response_read_deadline_post_commit_generation;
    u32 response_read_deadline_post_commit_episode;
    u32 response_read_deadline_post_commit_raw_header_end;
    u32 response_read_deadline_post_commit_declared_body;
    CompleteContentLengthResponseClass response_read_deadline_post_commit_response_class;
    u64 response_read_deadline_post_commit_range_first;
    u64 response_read_deadline_post_commit_range_last;
    u64 response_read_deadline_post_commit_range_total;
    u32 response_read_deadline_post_commit_origin_received;
    u32 response_read_deadline_post_commit_downstream_submitted;
    u32 response_read_deadline_post_commit_downstream_completed;
    u32 response_read_deadline_post_commit_inflight_body;
    // Monotonic body prefix permitted downstream by bounded raw-upstream
    // buffer releases. CompleteContentLength leaves this zero.
    u32 response_read_deadline_post_commit_release_target;
    // For the complete-Content-Length barrier this is the exact body prefix
    // selected for publication.  It equals declared_body on success, zero on
    // inactivity, and origin_received on a clean premature EOF.
    u32 response_read_deadline_post_commit_send_body;
    bool response_read_deadline_post_commit_close_after_drain;
    bool response_read_deadline_post_commit_terminal_pending;
    bool response_read_deadline_post_commit_pump_pending;
    // Exact downstream Send CQE ownership for the post-commit stream.  The
    // monotonically increasing token is encoded in io_uring user_data; the
    // tombstone survives retirement/request-boundary handoff so late CQEs
    // cannot steal a successor request's accounting.
    u32 response_read_deadline_send_generation = 0;
    u32 response_read_deadline_send_owner_generation;
    u32 response_read_deadline_send_tombstone_generation = 0;
    u32 response_read_deadline_send_deadline_generation;
    u32 response_read_deadline_send_upstream_episode;
    const u8* response_read_deadline_send_src;
    u32 response_read_deadline_send_len;
    i32 response_read_deadline_send_fd;
    ResponseReadDeadlineSendKind response_read_deadline_send_kind;
    bool response_read_deadline_send_owner_active;
    u32 response_read_deadline_send_close_generation = 0;
    bool response_read_deadline_send_close_target_owned = false;
    bool response_read_deadline_send_close_cancel_owned = false;

    // Logical single-shot TLS application-send identity. It is separate from
    // the per-SQE ciphertext identity and lives until the plaintext
    // continuation is delivered or the connection closes.
    u32 tls_send_owner_generation = 0;
    i32 tls_send_owner_fd = -1;
    u32 tls_send_owner_handler_generation = 0;

    // Generic precise response-read transport timer. The timespec and active
    // identity are kernel-owned storage: reset() must not mutate them before
    // every owned CQE has been harvested. The generation counter survives
    // ordinary reset/slot reuse and never wraps through the cancel-marker bit.
    IoTimespec response_read_timer_timespec{};
    u32 response_read_timer_generation = 0;
    u32 response_read_timer_owner_generation = 0;
    u32 response_read_timer_deadline_generation = 0;
    u32 response_read_timer_upstream_episode = 0;
    // Monotonic deadline origin for the narrow precise owner. Accepted progress
    // is proved separately; a profile may retain this pinned origin without
    // cancel/rearm churn.
    u64 response_read_timer_last_progress_ns = 0;
    ResponseReadTimerPhase response_read_timer_phase = ResponseReadTimerPhase::None;
    bool response_read_timer_target_owned = false;
    bool response_read_timer_cancel_owned = false;

    template <typename Self, typename Visitor>
    static void visit_response_read_timer_owner_fields(Self& c, Visitor&& visit) {
        visit(c.response_read_timer_timespec.tv_sec,
              static_cast<decltype(c.response_read_timer_timespec.tv_sec)>(0));
        visit(c.response_read_timer_timespec.tv_nsec,
              static_cast<decltype(c.response_read_timer_timespec.tv_nsec)>(0));
        visit(c.response_read_timer_owner_generation, u32{0});
        visit(c.response_read_timer_deadline_generation, u32{0});
        visit(c.response_read_timer_upstream_episode, u32{0});
        visit(c.response_read_timer_phase, ResponseReadTimerPhase::None);
        visit(c.response_read_timer_target_owned, false);
        visit(c.response_read_timer_cancel_owned, false);
    }

    [[nodiscard]] bool response_read_timer_owner_is_neutral() const {
        bool neutral = true;
        visit_response_read_timer_owner_fields(*this,
                                               [&](const auto& value, const auto& reset_value) {
                                                   neutral = neutral && value == reset_value;
                                               });
        return neutral;
    }

    [[nodiscard]] bool response_read_timer_owner_is_valid() const {
        const bool keys_valid =
            response_read_timer_owner_generation != 0 &&
            response_read_timer_owner_generation <= kResponseReadTimerGenerationMask &&
            response_read_timer_owner_generation == response_read_timer_generation &&
            response_read_timer_deadline_generation != 0 &&
            valid_upstream_episode(response_read_timer_upstream_episode);
        const bool timespec_valid =
            response_read_timer_timespec.tv_sec >= 0 && response_read_timer_timespec.tv_nsec >= 0 &&
            response_read_timer_timespec.tv_nsec < 1'000'000'000LL &&
            (response_read_timer_timespec.tv_sec != 0 || response_read_timer_timespec.tv_nsec != 0);
        switch (response_read_timer_phase) {
            case ResponseReadTimerPhase::None:
                return response_read_timer_owner_is_neutral();
            case ResponseReadTimerPhase::Armed:
                return keys_valid && timespec_valid && response_read_timer_target_owned &&
                       !response_read_timer_cancel_owned;
            case ResponseReadTimerPhase::CancelPending:
                return keys_valid && timespec_valid &&
                       (response_read_timer_target_owned || response_read_timer_cancel_owned);
        }
        return false;
    }

    // Clear is legal only after every kernel owner has drained. This protects
    // response_read_timer_timespec from reset/reuse while IORING_OP_TIMEOUT can
    // still dereference it.
    bool clear_response_read_timer_owner() {
        if (response_read_timer_target_owned || response_read_timer_cancel_owned) return false;
        visit_response_read_timer_owner_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
        return true;
    }

    bool next_response_read_timer_generation() {
        if (!response_read_timer_owner_is_neutral() ||
            response_read_timer_generation >= kResponseReadTimerGenerationMask)
            return false;
        ++response_read_timer_generation;
        response_read_timer_owner_generation = response_read_timer_generation;
        return true;
    }

    // Consume one exact target/cancel CQE. CancelPending owners drain
    // independently; their keys remain unchanged until the second CQE arrives.
    bool consume_response_read_timer_completion(u32 tagged_generation) {
        if (!response_read_timer_owner_is_valid()) return false;
        const bool cancel = (tagged_generation & kResponseReadTimerCancelBit) != 0;
        const u32 generation = tagged_generation & kResponseReadTimerGenerationMask;
        if (generation == 0 || generation != response_read_timer_owner_generation) return false;
        if (response_read_timer_phase == ResponseReadTimerPhase::Armed) {
            if (cancel || !response_read_timer_target_owned || response_read_timer_cancel_owned)
                return false;
            response_read_timer_target_owned = false;
        } else if (response_read_timer_phase == ResponseReadTimerPhase::CancelPending) {
            bool& owned =
                cancel ? response_read_timer_cancel_owned : response_read_timer_target_owned;
            if (!owned) return false;
            owned = false;
        } else {
            return false;
        }
        if (!response_read_timer_target_owned && !response_read_timer_cancel_owned) {
            const bool cleared = clear_response_read_timer_owner();
            if (cleared && response_read_deadline_state == ResponseReadDeadlineState::None)
                response_read_timer_last_progress_ns = 0;
            return cleared;
        }
        return true;
    }

    bool next_response_read_deadline_send_generation() {
        return next_non_upstream_send_generation(response_read_deadline_send_owner_generation);
    }

    // One monotonically increasing token namespace covers strict plaintext and
    // raw TLS sends. Allocating a raw/logical TLS token must not overwrite the
    // active strict plaintext owner's generation.
    bool next_non_upstream_send_generation(u32& generation) {
        if (response_read_deadline_send_generation == kNonUpstreamSendGenerationMask) return false;
        generation = ++response_read_deadline_send_generation;
        return true;
    }

    template <typename Self, typename Visitor>
    static void visit_tls_single_shot_send_owner_fields(Self& c, Visitor&& visit) {
        visit(c.tls_send_owner_generation, u32{0});
        visit(c.tls_send_owner_fd, i32{-1});
        visit(c.tls_send_owner_handler_generation, u32{0});
        visit(c.tls_send_src, static_cast<const u8*>(nullptr));
        visit(c.tls_send_len, u32{0});
        visit(c.tls_send_off, u32{0});
        visit(c.tls_pending_on_send, static_cast<Callback>(nullptr));
    }

    template <typename Self, typename Visitor>
    static void visit_tls_raw_send_owner_fields(Self& c, Visitor&& visit) {
        visit(c.tls_out_inflight, false);
        visit(c.tls_out_inflight_len, u32{0});
        visit(c.tls_out_inflight_generation, u32{0});
        visit(c.tls_out_inflight_fd, i32{-1});
        visit(c.tls_out_inflight_src, static_cast<const u8*>(nullptr));
    }

    [[nodiscard]] bool tls_single_shot_send_owner_is_neutral() const {
        return tls_send_owner_generation == 0 && tls_send_owner_fd == -1 &&
               tls_send_owner_handler_generation == 0 && tls_send_src == nullptr &&
               tls_send_len == 0 && tls_send_off == 0 && tls_pending_on_send == nullptr;
    }

    // Whether a downstream send is followed, straight from its own completion
    // and without waiting on any other I/O or computation, by more bytes of the
    // same response. Such sends carry MSG_MORE: the kernel then coalesces a
    // short head (e.g. the header slice of a large local body) with the next
    // chunk instead of pushing it alone. A lone sub-MSS head can leave a small
    // receive window below one MSS with the rest queued, and the stream then
    // waits for a delayed ACK or the persist timer. Anything that waits on
    // upstream I/O must push.
    [[nodiscard]] bool plaintext_send_has_follow_up(u32 len = 0) const {
        if (local_body_remaining != 0) return true;
        if (response_read_deadline_post_commit_phase ==
            ResponseReadDeadlinePostCommitPhase::HeaderSend) {
            // The rewritten header has an exact send owner, and the body
            // pump can submit this published prefix after its completion.
            return !tls_active && len != 0 &&
                   response_read_deadline_buffering == ForwardResponseBufferingMode::Bounded &&
                   !response_read_deadline_post_commit_terminal_pending &&
                   response_read_deadline_send_owner_active &&
                   response_read_deadline_send_kind == ResponseReadDeadlineSendKind::Header &&
                   response_read_deadline_send_src == response_header_buf.data() &&
                   response_read_deadline_send_len == len && response_header_buf.len() == len &&
                   response_read_deadline_send_fd == fd && fd >= 0 &&
                   response_read_deadline_post_commit_inflight_body == 0 &&
                   response_read_deadline_post_commit_downstream_submitted == 0 &&
                   response_read_deadline_post_commit_downstream_completed == 0 &&
                   response_read_deadline_post_commit_release_target != 0 &&
                   response_read_deadline_post_commit_release_target <=
                       response_read_deadline_post_commit_origin_received;
        }
        // A bounded proxy may cork only bytes already received behind this
        // exact body send. Future origin arrivals must never hold a push.
        if (tls_active || len == 0 ||
            response_read_deadline_buffering != ForwardResponseBufferingMode::Bounded ||
            response_read_deadline_post_commit_phase !=
                ResponseReadDeadlinePostCommitPhase::BodySend ||
            response_read_deadline_post_commit_terminal_pending ||
            response_read_deadline_post_commit_inflight_body != len ||
            response_read_deadline_post_commit_downstream_submitted <
                response_read_deadline_post_commit_downstream_completed ||
            response_read_deadline_post_commit_downstream_submitted -
                    response_read_deadline_post_commit_downstream_completed !=
                len ||
            response_read_deadline_post_commit_origin_received <=
                response_read_deadline_post_commit_downstream_completed)
            return false;
        // Received bytes below the publication boundary still await origin
        // progress. Cork only a follow-up the body pump can send immediately.
        return response_read_deadline_post_commit_release_target <=
                   response_read_deadline_post_commit_origin_received &&
               response_read_deadline_post_commit_release_target >
                   response_read_deadline_post_commit_downstream_submitted;
    }

    // TLS variant for a raw ciphertext send of `len` bytes from tls_out_buf:
    // only ciphertext already queued behind it counts. Plaintext still to be
    // encrypted (or a local body chunk still to be fed) would hold the corked
    // record for a whole encryption pass, which costs latency at low
    // concurrency more than the coalescing gains.
    [[nodiscard]] bool tls_ciphertext_send_has_follow_up(u32 len) const {
        return len < tls_out_buf.len();
    }

    [[nodiscard]] bool tls_raw_send_owner_is_neutral() const {
        return !tls_out_inflight && tls_out_inflight_len == 0 && tls_out_inflight_generation == 0 &&
               tls_out_inflight_fd == -1 && tls_out_inflight_src == nullptr;
    }

    void clear_response_read_deadline_send_owner() {
        visit_response_read_deadline_send_owner_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
    }

    bool next_response_read_deadline_generation() {
        if (response_read_deadline_generation == 0xFFFFFFFFu) return false;
        ++response_read_deadline_generation;
        response_read_deadline_owner_generation = response_read_deadline_generation;
        return true;
    }

    // Canonical inventories of active response-read-deadline ownership and
    // their neutral values. Reset, mode selection, and exhaustive tests consume
    // these same inventories so a new owner cannot drift between those paths.
    template <typename Self, typename Visitor>
    static void visit_response_read_deadline_owner_fields(Self& c, Visitor&& visit) {
        visit(c.response_read_deadline_owner_generation, u32{0});
        visit(c.response_read_deadline_upstream_episode, u32{0});
        visit(c.response_read_deadline_bundle_id, u16{0});
        visit(c.response_read_deadline_seconds, u8{0});
        visit(c.response_read_deadline_buffering, ForwardResponseBufferingMode::None);
        visit(c.response_read_deadline_profile, ResponseReadDeadlineProfile::None);
        visit(c.response_read_deadline_method, u8{0xffu});
        visit(c.response_read_deadline_route_method, u8{0xffu});
        visit(c.response_read_deadline_state, ResponseReadDeadlineState::None);
        visit(c.response_read_deadline_progress_generation, u32{0});
        visit(c.response_read_deadline_progress_episode, u32{0});
        visit(c.response_read_deadline_progress_bytes, u32{0});
        visit(c.response_read_deadline_post_commit_phase,
              ResponseReadDeadlinePostCommitPhase::None);
        visit(c.response_read_deadline_post_commit_generation, u32{0});
        visit(c.response_read_deadline_post_commit_episode, u32{0});
        visit(c.response_read_deadline_post_commit_raw_header_end, u32{0});
        visit(c.response_read_deadline_post_commit_declared_body, u32{0});
        visit(c.response_read_deadline_post_commit_response_class,
              CompleteContentLengthResponseClass::Unsupported);
        visit(c.response_read_deadline_post_commit_range_first, u64{0});
        visit(c.response_read_deadline_post_commit_range_last, u64{0});
        visit(c.response_read_deadline_post_commit_range_total, u64{0});
        visit(c.response_read_deadline_post_commit_origin_received, u32{0});
        visit(c.response_read_deadline_post_commit_downstream_submitted, u32{0});
        visit(c.response_read_deadline_post_commit_downstream_completed, u32{0});
        visit(c.response_read_deadline_post_commit_inflight_body, u32{0});
        visit(c.response_read_deadline_post_commit_release_target, u32{0});
        visit(c.response_read_deadline_post_commit_send_body, u32{0});
        visit(c.response_read_deadline_post_commit_close_after_drain, false);
        visit(c.response_read_deadline_post_commit_terminal_pending, false);
        visit(c.response_read_deadline_post_commit_pump_pending, false);
        visit(c.response_read_deadline_first_batch, false);
        visit(c.response_read_deadline_first_batch_profile, ResponseReadDeadlineProfile::None);
        visit(c.response_read_deadline_first_batch_method, u8{0xffu});
        visit(c.response_read_deadline_first_batch_route_method, u8{0xffu});
        visit(c.response_read_deadline_first_batch_generation, u32{0});
        visit(c.response_read_deadline_first_batch_bundle_id, u16{0});
        visit(c.response_read_deadline_first_batch_buffering, ForwardResponseBufferingMode::None);
    }

    template <typename Self, typename Visitor>
    static void visit_response_read_deadline_send_owner_fields(Self& c, Visitor&& visit) {
        visit(c.response_read_deadline_send_owner_generation, u32{0});
        visit(c.response_read_deadline_send_deadline_generation, u32{0});
        visit(c.response_read_deadline_send_upstream_episode, u32{0});
        visit(c.response_read_deadline_send_src, static_cast<const u8*>(nullptr));
        visit(c.response_read_deadline_send_len, u32{0});
        visit(c.response_read_deadline_send_fd, i32{-1});
        visit(c.response_read_deadline_send_kind, ResponseReadDeadlineSendKind::None);
        visit(c.response_read_deadline_send_owner_active, false);
    }

    template <typename Self, typename Visitor>
    static void visit_response_read_deadline_send_close_owner_fields(Self& c, Visitor&& visit) {
        visit(c.response_read_deadline_send_close_generation, u32{0});
        visit(c.response_read_deadline_send_close_target_owned, false);
        visit(c.response_read_deadline_send_close_cancel_owned, false);
    }

    [[nodiscard]] bool response_read_deadline_owner_is_neutral() const {
        bool neutral = response_read_deadline_upload.owner_is_neutral() &&
                       response_read_deadline_first_batch_upload.owner_is_neutral();
        const auto check = [&](const auto& value, const auto& reset_value) {
            neutral = neutral && value == reset_value;
        };
        visit_response_read_deadline_owner_fields(*this, check);
        visit_response_read_deadline_send_owner_fields(*this, check);
        visit_response_read_deadline_send_close_owner_fields(*this, check);
        return neutral;
    }

    [[nodiscard]] bool response_read_deadline_connected_auxiliary_owners_are_neutral() const {
        bool neutral = response_read_deadline_first_batch_upload.owner_is_neutral();
        const auto check = [&](const auto& value, const auto& reset_value) {
            neutral = neutral && value == reset_value;
        };
        check(response_read_deadline_progress_generation, u32{0});
        check(response_read_deadline_progress_episode, u32{0});
        check(response_read_deadline_progress_bytes, u32{0});
        check(response_read_deadline_post_commit_phase, ResponseReadDeadlinePostCommitPhase::None);
        check(response_read_deadline_post_commit_generation, u32{0});
        check(response_read_deadline_post_commit_episode, u32{0});
        check(response_read_deadline_post_commit_raw_header_end, u32{0});
        check(response_read_deadline_post_commit_declared_body, u32{0});
        check(response_read_deadline_post_commit_response_class,
              CompleteContentLengthResponseClass::Unsupported);
        check(response_read_deadline_post_commit_range_first, u64{0});
        check(response_read_deadline_post_commit_range_last, u64{0});
        check(response_read_deadline_post_commit_range_total, u64{0});
        check(response_read_deadline_post_commit_origin_received, u32{0});
        check(response_read_deadline_post_commit_downstream_submitted, u32{0});
        check(response_read_deadline_post_commit_downstream_completed, u32{0});
        check(response_read_deadline_post_commit_inflight_body, u32{0});
        check(response_read_deadline_post_commit_release_target, u32{0});
        check(response_read_deadline_post_commit_send_body, u32{0});
        check(response_read_deadline_post_commit_close_after_drain, false);
        check(response_read_deadline_post_commit_terminal_pending, false);
        check(response_read_deadline_post_commit_pump_pending, false);
        check(response_read_deadline_first_batch, false);
        check(response_read_deadline_first_batch_profile, ResponseReadDeadlineProfile::None);
        check(response_read_deadline_first_batch_method, u8{0xffu});
        check(response_read_deadline_first_batch_route_method, u8{0xffu});
        check(response_read_deadline_first_batch_generation, u32{0});
        check(response_read_deadline_first_batch_bundle_id, u16{0});
        check(response_read_deadline_first_batch_buffering, ForwardResponseBufferingMode::None);
        visit_response_read_deadline_send_owner_fields(*this, check);
        visit_response_read_deadline_send_close_owner_fields(*this, check);
        return neutral;
    }

    void clear_response_read_deadline() {
        visit_response_read_deadline_owner_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
        clear_response_read_deadline_send_owner();
        response_read_deadline_upload.clear_owner();
        response_read_deadline_first_batch_upload.clear_owner();
        if (response_read_timer_owner_is_neutral()) response_read_timer_last_progress_ns = 0;
    }

    template <typename Self, typename Visitor>
    static void visit_http1_prebuilt_response_proof_fields(Self& c, Visitor&& visit) {
        visit(c.http1_prebuilt_response_layout, Http1PrebuiltResponseLayout::None);
        visit(c.http1_prebuilt_response_purpose, Http1PrebuiltResponsePurpose::None);
        visit(c.http1_prebuilt_deadline_profile, ResponseReadDeadlineProfile::None);
        visit(c.http1_prebuilt_deadline_method, u8{0xffu});
        visit(c.http1_prebuilt_deadline_route_method, u8{0xffu});
        visit(c.http1_prebuilt_deadline_generation, u32{0});
        visit(c.http1_prebuilt_deadline_bundle_id, u16{0});
        visit(c.http1_prebuilt_deadline_config, static_cast<const RouteConfig*>(nullptr));
        visit(c.http1_prebuilt_header_end, u32{0});
        visit(c.http1_prebuilt_total_len, u32{0});
        visit(c.http1_prebuilt_body_len, u32{0});
        visit(c.http1_prebuilt_status, u16{0});
    }

    [[nodiscard]] bool http1_prebuilt_response_proof_is_neutral() const {
        bool neutral = http1_prebuilt_deadline_upload.owner_is_neutral();
        const auto check = [&](const auto& value, const auto& reset_value) {
            neutral = neutral && value == reset_value;
        };
        visit_http1_prebuilt_response_proof_fields(*this, check);
        return neutral;
    }

    void clear_http1_prebuilt_response_proof() {
        visit_http1_prebuilt_response_proof_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
        http1_prebuilt_deadline_upload = ResponseReadDeadlineUploadProof{};
    }

    // Advance the token without wrapping. Zero is the invalid sentinel and
    // max is the final representable token; callers must quarantine the
    // episode owner when this returns false rather than reusing an old token.
    bool next_upstream_episode() {
        if (!valid_upstream_episode(upstream_episode) ||
            upstream_episode == kIoUserDataMaxUpstreamEpisode)
            return false;
        ++upstream_episode;
        return true;
    }

    // Route config pinned for the lifetime of the current request. Set
    // in on_header_received from the loop's config pointer; referenced
    // by handle_jit_outcome (e.g., Forward upstream resolution) so a
    // config hot-swap during wait(ms) can't resolve an upstream_id
    // against the post-swap config. Cleared by reset().
    const RouteConfig* request_config;

    // Immutable process/listener identity copied at accept-time. Unlike
    // request_config this survives keep-alive request boundaries and is
    // cleared only when the connection slot is reset.
    ListenerContext listener_context;

    // Per-connection timespec storage for IORING_OP_TIMEOUT yields. The
    // kernel reads this asynchronously after SQE submission, so it must
    // outlive the submit call — on-connection storage is the simplest
    // stable lifetime. Unused by the epoll backend (which uses a shared
    // yield_timer_fd + min-heap).
    IoTimespec yield_timespec;
    u32 yield_timer_gen = 0;

    bool keep_alive;
    bool tls_active;
    bool tls_handshake_complete;
    // Active wire protocol. Defaults to Http11; set from the ALPN result once
    // the TLS handshake completes, or on detecting the cleartext h2c preface.
    ConnProtocol protocol;
    // Number of successfully completed requests on the currently accepted
    // downstream transport. This is transport identity, not request metadata:
    // reset() clears it on slot allocation/reuse, while keep-alive request
    // boundaries deliberately preserve it. Saturates instead of wrapping.
    u32 downstream_completed_request_count;

    void record_downstream_request_completion() {
        if (downstream_completed_request_count != ~u32{0}) downstream_completed_request_count++;
    }

    void copy_downstream_transport_state_from(const ConnectionBase& source) {
        downstream_completed_request_count = source.downstream_completed_request_count;
    }

    // Per-connection HTTP/2 engine, lazily allocated from a per-shard pool when
    // the connection switches to Http2; returned to the pool on close. Null for
    // HTTP/1 connections (they pay nothing).
    Http2Conn* h2;
    SSL* tls;

    // --- io_uring TLS termination (event-loop-layer) ---
    // The epoll backend terminates TLS with a socket BIO inside the backend
    // (SSL does its own recv/send on readiness). io_uring can't — SSL must never
    // touch the fd — so it drives a TlsEngine over the custom zero-copy BIO from
    // the event-loop layer. These fields are unused by the epoll path (it uses
    // `tls` above); io_uring leaves `tls` null and uses `tls_engine`.
    TlsEngine tls_engine;
    u8* tls_in_slice;  // ciphertext arriving from the network (recv lands here)
    Buffer tls_in_buf;
    u8* tls_out_slice;  // ciphertext to send: handshake flights + encrypted app data
    Buffer tls_out_buf;
    // A tls_out_buf send is in flight; the buffer cannot be reused until its CQE.
    bool tls_out_inflight;
    // Bytes the in-flight raw send covers. Read-ahead may append more ciphertext
    // to tls_out_buf after the SQE captured its length, so the drain handler must
    // consume against this, not the (possibly grown) tls_out_buf.len(). See
    // docs/iouring-tls-output-buffer.md §3.1.
    u32 tls_out_inflight_len;
    // Immutable source/fd/token snapshot for the current raw TLS target.
    // Read-ahead can append output but cannot change the submitted prefix.
    u32 tls_out_inflight_generation = 0;
    i32 tls_out_inflight_fd = -1;
    const u8* tls_out_inflight_src = nullptr;
    // Proxy-over-TLS streaming backpressure state (io_uring). Per-response, not
    // per-connection — cleared at the keep-alive request boundary, not only reset().
    bool tls_recv_paused_hw;   // upstream recv paused at the high watermark
    bool resp_fully_buffered;  // whole proxy body read+encrypted into tls_out_buf
    bool tls_proxy_stream;     // mid proxy-over-TLS body (vs single-shot / handshake)
    // Plaintext awaiting encryption for an app-data send. Encryption may need
    // several rounds when the ciphertext doesn't fit tls_out_buf in one shot; the
    // send-completion handler resumes from tls_send_off and only fires the real
    // continuation (tls_pending_on_send) once all plaintext is encrypted+sent.
    const u8* tls_send_src;
    u32 tls_send_len;
    u32 tls_send_off;
    Callback tls_pending_on_recv;
    Callback tls_pending_on_send;

    // HTTP pipelining state
    u16 pipeline_depth;      // pipelined requests processed on this connection
    u16 pipeline_stash_len;  // bytes of next request stashed in send_buf (proxy)
    // Non-zero only for one completely admitted depth-1 HTTP/1 successor.  The
    // token is bound to handler_gen so later strict-owner predicates can reject
    // stale or forged pipeline state without repurposing pipeline_depth (which
    // remains the chain/reassembly counter).  Foundation only: existing runtime
    // guards deliberately do not consume this token yet.
    u32 http1_pipeline_request_generation;
    // Snapshot taken at the synthetic request boundary before
    // transition_to_reading_header replaces the previous callback slots. It is
    // retained across fragmented depth-one reparses and consumed only by the
    // bounded exact local-response successor predicate.
    bool http1_pipeline_boundary_owners_settled;

    void copy_http1_pipeline_state_from(const ConnectionBase& source) {
        pipeline_depth = source.pipeline_depth;
        pipeline_stash_len = source.pipeline_stash_len;
        http1_pipeline_request_generation = source.http1_pipeline_request_generation;
        http1_pipeline_boundary_owners_settled = source.http1_pipeline_boundary_owners_settled;
        req_target_has_fragment = source.req_target_has_fragment;
        req_target_form_unsupported = source.req_target_form_unsupported;
        req_target_form_reject_before_pre_route = source.req_target_form_reject_before_pre_route;
        // Unlike the admission facts above, raw-target offsets are owned by one
        // concrete recv_buf episode.  A metadata-only state copy cannot prove
        // that ownership, so it deliberately leaves the destination neutral.
        req_metadata_episode = 0;
        clear_raw_request_target_witness();
    }

    // Body streaming state (proxy large body support)
    u32 req_header_end;        // offset past request headers (\r\n\r\n)
    u32 req_content_length;    // original Content-Length value (for send capping)
    u32 req_initial_send_len;  // max bytes to send in initial upstream forward
    // Idle-reuse retry snapshot length. When a request is forwarded to a REUSED
    // pooled upstream socket, recv_buf is reset at request-sent (so pipelined
    // downstream bytes read during the wait flow through pipeline_recover, and the
    // just-sent request can't leak into the next request). To still allow the rare
    // post-send dead-socket fallback (origin FIN landing just after take_idle's
    // MSG_PEEK probe), the exact request bytes are snapshotted into the front of
    // send_buf. If the same client read also carried pipelined surplus, pipeline_stash
    // appends that suffix after this snapshot; pipeline_stash_len describes the suffix.
    // >0 means "a replayable copy lives in send_buf" and on_upstream_connected replays
    // [0, retry_req_send_len) instead of recv_buf. Reset at the per-request boundary
    // like the reuse flags.
    u32 retry_req_send_len;
    // A response mutation may pin the pre-override request in send_buf. Such a
    // snapshot still reserves the retry prefix for pipeline_stash layout, but it
    // is not replayable when the upstream received rewritten request bytes.
    bool retry_req_snapshot_replayable;
    bool response_mutations_snapshotted;
    bool req_malformed;  // true if request body is malformed (reject)
    // Non-zero when the explicit source request policy has rewritten recv_buf.
    // This is reset at the request boundary and is deliberately separate from
    // the route/config lifetime: the bytes are owned by this connection slice.
    u16 request_policy_id;
    // A policy Forward whose fixed Content-Length body has not arrived yet.
    // The JIT handler is invoked once; these compact fields retain its immutable
    // Forward outcome while the pinned request_config/epoch waits for the body.
    bool request_policy_body_pending;
    u16 pending_forward_upstream_id;
    u16 pending_forward_request_policy_id;
    u16 pending_forward_response_policy_id;
    u16 pending_forward_failure_policy_id;
    u16 pending_forward_timeout_failure_policy_id;
    // Semantic request facts kept separate from the transport's counters:
    // buffered means the complete fixed-CL request is staged, while upload
    // complete is published only after the upstream send finishes.
    bool request_body_fully_buffered;
    bool request_upload_complete;
    // Non-zero selects the strict H1 response serializer for this request.
    u16 response_policy_id;
    // Strict HEAD responses preserve the upstream representation length in the
    // downstream headers but never forward representation bytes.
    bool response_policy_suppress_body;
    // Non-zero selects the bounded H1 failure serializer for connect failures.
    u16 failure_policy_id;
    // Optional cause-specific timeout response selected with this request.
    // Foundation metadata only until #267 runtime wiring consumes it.
    u16 timeout_failure_policy_id;
    // Pinned per-request failure disposition.  This is deliberately separate
    // from the policy table so later request rewrites or config swaps cannot
    // change how an already selected connect failure is serialized.
    bool failure_policy_suppress_body;
    // Exact parsed request HTTP version (HttpVersion underlying value).
    u8 req_http_version;  // HttpVersion::Http10/Http11, 255 when unknown.
    // True only for the current request after the strict parser completed an
    // HTTP/1.0 or HTTP/1.1 header block. Fallback method/path recovery never
    // publishes it.
    bool req_strict_h1_complete;
    // A checked, connection-owned witness for the complete request-target.  The
    // target itself remains in recv_buf; these fields never borrow a pointer and
    // are neutral unless capture_request_metadata completed a strict origin-form
    // parse for the current metadata episode.  The witness includes the query
    // spelling and is independent of the bounded req_path logging copy.
    u32 req_metadata_episode;
    u32 req_raw_target_episode;
    u32 req_raw_target_offset;
    u32 req_raw_target_length;
    // Full raw request-target fragment witness for the current request. This is
    // deliberately independent of the bounded req_path copy and canonical view.
    bool req_target_has_fragment;
    // Raw H1 target-form admission, independent of strict method parsing.
    bool req_target_form_unsupported;
    bool req_target_form_reject_before_pre_route;
    // Access-log-only owned copy of the original strict-H1 target. It is
    // populated only when access logging is enabled and remains valid after the
    // borrowed recv_buf witness is cleared by rewrite/consume/reset paths.
    AccessLogTargetSnapshot access_log_target_snapshot;

    void clear_access_log_target_snapshot() {
        access_log_target_snapshot.episode = 0;
        access_log_target_snapshot.target_length = 0;
        access_log_target_snapshot.target_state = AccessLogTargetState::LegacyNullTerminated;
        access_log_target_snapshot.path[0] = '\0';
    }

    void clear_raw_request_target_witness() {
        req_raw_target_episode = 0;
        req_raw_target_offset = 0;
        req_raw_target_length = 0;
    }

    void begin_request_metadata_episode() {
        req_metadata_episode++;
        if (req_metadata_episode == 0) req_metadata_episode = 1;
        clear_raw_request_target_witness();
        clear_access_log_target_snapshot();
    }

    // Reset/compaction paths must use this instead of resetting recv_buf
    // directly.  It makes a previous request's offsets neutral before the
    // backing storage can be repopulated with a successor request.
    void reset_request_receive_buffer() {
        clear_raw_request_target_witness();
        recv_buf.reset();
    }

    void consume_request_receive_buffer(u32 count) {
        clear_raw_request_target_witness();
        recv_buf.consume(count);
    }

    // True while the downstream request body still has bytes to come and they are
    // being forwarded upstream. Anything the downstream recv appends to recv_buf
    // behind the chunk already handed upstream is then request-stream body, not a
    // pipelined successor.
    bool request_body_incomplete() const {
        return !req_body_abandoned &&
               ((req_body_mode == BodyMode::ContentLength && req_body_remaining > 0) ||
                (req_body_mode == BodyMode::Chunked &&
                 req_chunk_parser.state != ChunkedParser::State::Complete));
    }

    RawRequestTargetWitnessResult checked_raw_request_target() const {
        const RawRequestTargetWitnessResult neutral{RawRequestTargetWitnessState::Neutral,
                                                    {nullptr, 0}};
        const RawRequestTargetWitnessResult invalid{RawRequestTargetWitnessState::Invalid,
                                                    {nullptr, 0}};
        if (req_raw_target_episode == 0 && req_raw_target_offset == 0 && req_raw_target_length == 0)
            return neutral;
        if (req_raw_target_episode == 0 || req_raw_target_offset == 0 ||
            req_raw_target_length == 0 || req_metadata_episode == 0 ||
            req_raw_target_episode != req_metadata_episode || !req_strict_h1_complete ||
            req_malformed || req_header_end == 0 || req_initial_send_len == 0 ||
            req_header_end > req_initial_send_len || !recv_buf.valid() || recv_buf.is_released())
            return invalid;

        const u32 capacity = recv_buf.capacity();
        const u32 count = recv_buf.len();
        if (recv_slice == nullptr || recv_slice_capacity == 0 || capacity != recv_slice_capacity ||
            count > capacity || req_header_end > count || req_initial_send_len > count ||
            req_raw_target_offset >= req_header_end)
            return invalid;
        const u64 target_end64 = static_cast<u64>(req_raw_target_offset) + req_raw_target_length;
        if (target_end64 >= req_header_end || target_end64 > count || target_end64 > capacity)
            return invalid;

        const u8* base = recv_buf.data();
        const uintptr_t address = reinterpret_cast<uintptr_t>(base);
        if (base != recv_slice || address < 4096 || capacity > UINTPTR_MAX - address)
            return invalid;

        const char* method = nullptr;
        u32 method_length = 0;
        switch (static_cast<LogHttpMethod>(req_method)) {
            case LogHttpMethod::Get:
                method = "GET";
                method_length = 3;
                break;
            case LogHttpMethod::Post:
                method = "POST";
                method_length = 4;
                break;
            case LogHttpMethod::Put:
                method = "PUT";
                method_length = 3;
                break;
            case LogHttpMethod::Delete:
                method = "DELETE";
                method_length = 6;
                break;
            case LogHttpMethod::Patch:
                method = "PATCH";
                method_length = 5;
                break;
            case LogHttpMethod::Head:
                method = "HEAD";
                method_length = 4;
                break;
            case LogHttpMethod::Options:
                method = "OPTIONS";
                method_length = 7;
                break;
            case LogHttpMethod::Connect:
                method = "CONNECT";
                method_length = 7;
                break;
            case LogHttpMethod::Trace:
                method = "TRACE";
                method_length = 5;
                break;
            case LogHttpMethod::Other:
                return invalid;
        }
        if (method == nullptr || req_raw_target_offset != method_length + 1u ||
            method_length >= req_header_end || base[method_length] != ' ')
            return invalid;
        for (u32 i = 0; i < method_length; i++) {
            if (base[i] != static_cast<u8>(method[i])) return invalid;
        }

        const u32 target_end = static_cast<u32>(target_end64);
        // Bind the offsets to the strictly parsed request line, not merely an
        // arbitrary slash-delimited substring elsewhere in the header block.
        // Bounds above are proven before these bytes are examined.
        const bool h10 = req_http_version == static_cast<u8>(HttpVersion::Http10);
        const bool h11 = req_http_version == static_cast<u8>(HttpVersion::Http11);
        if ((!h10 && !h11) || base[req_raw_target_offset - 1] != ' ' ||
            base[req_raw_target_offset] != '/' || base[target_end] != ' ' ||
            target_end64 + 11u > req_header_end || base[target_end + 1] != 'H' ||
            base[target_end + 2] != 'T' || base[target_end + 3] != 'T' ||
            base[target_end + 4] != 'P' || base[target_end + 5] != '/' ||
            base[target_end + 6] != '1' || base[target_end + 7] != '.' ||
            base[target_end + 8] != static_cast<u8>(h11 ? '1' : '0') ||
            base[target_end + 9] != '\r' || base[target_end + 10] != '\n')
            return invalid;
        return {
            RawRequestTargetWitnessState::Valid,
            {reinterpret_cast<const char*>(base + req_raw_target_offset), req_raw_target_length}};
    }

    // Called exactly once at request start when the owning loop has access
    // logging enabled. checked_raw_request_target() performs every provenance
    // and range gate before any target byte is copied here.
    void capture_access_log_target_snapshot() {
        clear_access_log_target_snapshot();
        const u32 episode = req_metadata_episode;
        const RawRequestTargetWitnessResult witness = checked_raw_request_target();
        if (witness.state == RawRequestTargetWitnessState::Valid) {
            if (witness.target.len == 0 ||
                witness.target.len > kAccessLogObservedStrictH1TargetMax) {
                access_log_target_snapshot.target_state = AccessLogTargetState::Invalid;
            } else if (witness.target.len > kAccessLogCompleteTargetMax) {
                access_log_target_snapshot.target_length = static_cast<u16>(witness.target.len);
                access_log_target_snapshot.target_state = AccessLogTargetState::OverLimit;
            } else {
                for (u32 i = 0; i < witness.target.len; i++)
                    access_log_target_snapshot.path[i] = witness.target.ptr[i];
                access_log_target_snapshot.target_length = static_cast<u16>(witness.target.len);
                access_log_target_snapshot.target_state = AccessLogTargetState::Complete;
            }
        } else if (witness.state == RawRequestTargetWitnessState::Neutral) {
            access_log_target_snapshot.target_state = AccessLogTargetState::Unavailable;
        } else {
            access_log_target_snapshot.target_state = AccessLogTargetState::Invalid;
        }
        // Publish the owner last. A zero episode can never be consumed as the
        // current request and therefore remains fail-closed at completion.
        access_log_target_snapshot.episode = episode;
    }
    // Request-side keep-alive intent of the CURRENT request, as parsed from its
    // request line + Connection header (HTTP/1.1 default true, HTTP/1.0 default
    // false, "Connection: close" → false). The proxy forwards the client's
    // request bytes (incl. its Connection header / version) verbatim upstream, so
    // this is what told the origin whether it may close after responding. Gate
    // upstream idle-pooling on THIS, not on conn.keep_alive (which is derived from
    // drain state, not the request). Recorded by capture_request_metadata.
    bool req_keep_alive;
    // Parsed downstream intent preserved across request-policy materialisation,
    // which rewrites req_keep_alive for the upstream request.
    bool req_client_keep_alive;
    bool req_client_connection_close;
    bool req_client_connection_close_exact;
    // Exactly one Connection field whose whole value is `keep-alive`.
    bool req_client_connection_keep_alive_exact;
    bool req_client_has_content_length;
    u8 req_client_content_length_count;
    RequestTransferEncoding req_client_transfer_encoding;
    // Original request framing/upgrade facts captured before any request-policy
    // rewrite. SuppressBody HEAD admission must not lose these when rewritten
    // requests strip hop-by-hop fields.
    bool req_client_has_transfer_encoding;
    bool req_client_has_te;
    bool req_client_has_expect;
    bool req_client_has_upgrade_header;
    u8 req_client_connection_count;
    bool req_wants_upgrade;          // client sent Connection: upgrade (gates 101 tunnel)
    bool req_upgrade_is_websocket;   // the request Upgrade list offered "websocket"
    bool resp_upgrade_is_websocket;  // the backend 101 selected "websocket" (gates terminate)
    BodyMode req_body_mode;
    u32 req_body_remaining;          // bytes left for request body (Content-Length)
    ChunkedParser req_chunk_parser;  // for chunked request body end detection
    // True once any request-body byte has started streaming upstream (recv_buf is
    // reset + refilled with body chunks, so the original headers+body are gone).
    // Once set, the request can no longer be replayed from recv_buf, so the
    // reused-socket retry predicate refuses it. Reset at the per-request boundary.
    bool req_body_streamed;
    BodyMode resp_body_mode;
    u32 resp_body_remaining;          // bytes left for Content-Length mode
    ChunkedParser resp_chunk_parser;  // for chunked mode end detection
    u32 resp_body_sent;               // total response body bytes sent (for access log)
    u32 upstream_send_len;            // bytes from upstream_recv_buf in current client send

    // io_uring multishot recv tracking: true while the multishot SQE is
    // armed in the kernel (set on submit, cleared on final CQE without
    // IORING_CQE_F_MORE). Separate flags for client and upstream to avoid
    // an upstream recv CQE clearing the client's armed state.
    bool recv_armed;
    bool send_armed;
    bool upstream_connect_armed;
    bool upstream_recv_armed;
    bool upstream_send_armed;
    bool recv_paused_for_send;
    bool recv_pause_cancel_pending;
    // Independent ownership for the recv target while its pause cancel drains.
    // The cancel CQE and the target terminal may arrive in either order.
    bool recv_pause_target_inflight;
    // True when code asked to recv during a send-wait pause window and the
    // read should be re-armed after the cancel CQE drains.
    bool recv_pause_rearm_pending;
    bool upstream_recv_paused_for_send;
    bool upstream_recv_pause_cancel_pending;
    bool upstream_recv_pause_rearm_pending;
    // True from when a pause cancel is issued until the CANCELLED recv's own terminal
    // CQE (-ECANCELED, or a normal completion that beat the cancel) has drained. Unlike
    // upstream_recv_armed — which proxy_stream_complete clears at the keep-alive
    // boundary while the old recv is still in flight — this is cleared ONLY by that
    // terminal CQE, so it is the reliable "the cancelled recv has not yet drained"
    // signal that gates re-arm (alongside upstream_recv_pause_cancel_pending).
    bool upstream_recv_cancel_inflight;
    // Captures resp_fully_buffered AT PAUSE TIME: true if the pause fired at the keep-
    // alive boundary (body already complete) rather than mid-stream backpressure. The
    // cancelled recv's terminal CQE is then stale post-body data and must be suppressed,
    // not delivered to the next pipelined request's slots. Captured here because
    // proxy_stream_complete clears resp_fully_buffered before that terminal drains, so
    // the live flag is unreliable. Cleared with upstream_recv_cancel_inflight.
    bool upstream_recv_terminal_stale;
    // Bounded io_uring strict-abandonment retirement state. The latest retiring
    // token remains as a tombstone after both owned finals drain and across
    // ordinary reset()/slot reuse, so an old final cannot fall into generic
    // stale-CQE accounting. A later proven retirement atomically replaces it
    // with the then-current token; it is initialized exactly once
    // here rather than being cleared by reset(). Active ownership/retry fields
    // are still reset normally and preserved explicitly by io_uring's deferred-
    // free path while kernel work pins the connection storage.
    u32 upstream_retiring_episode = 0;
    bool upstream_retirement_active;
    u8 upstream_retirement_target_owned;
    u8 upstream_retirement_cancel_owned;
    u8 upstream_retirement_cancel_retry;
    // A close may land after C2 admitted the successor episode while its
    // connect/send/recv is still in flight. Preserve exact target/cancel
    // ownership through reset so only matching successor CQEs drain accounting.
    // The episode remains as a tombstone after the masks reach zero.
    u32 upstream_close_episode;
    u8 upstream_close_target_owned;
    u8 upstream_close_cancel_owned;
    bool upstream_close_pause_cancel_owned;
    // Generic HTTP/1 request-boundary rendezvous used by io_uring while the
    // strict upstream recv episode above drains. Request-completion bookkeeping
    // has already run when deferred is set; buffered downstream bytes must not
    // enter the next request until the loop consumes ready at batch end. The
    // successor episode binds the marker to this exact live slot generation.
    bool http1_boundary_deferred;
    bool http1_boundary_ready;
    u32 http1_boundary_successor_episode;
    // Internal, policy-agnostic prebuilt-header rendezvous. HeaderSend and
    // UpstreamRetirement are independently owned wait bits; request 2 is
    // admitted only after both clear and the batch-end scan consumes readiness.
    // A non-None disposition is the active marker even after the wait mask is
    // zero. The exact prefix remains pinned until retirement and header send no
    // longer reference recv/send slices.
    u8 http1_prebuilt_wait;
    Http1RequestBufferDisposition http1_prebuilt_disposition;
    u32 http1_prebuilt_request_prefix_len;
    Http1PrebuiltResponseLayout http1_prebuilt_response_layout;
    Http1PrebuiltResponsePurpose http1_prebuilt_response_purpose;
    ResponseReadDeadlineProfile http1_prebuilt_deadline_profile;
    u8 http1_prebuilt_deadline_method;
    u8 http1_prebuilt_deadline_route_method;
    u32 http1_prebuilt_deadline_generation;
    u16 http1_prebuilt_deadline_bundle_id;
    const RouteConfig* http1_prebuilt_deadline_config;
    ResponseReadDeadlineUploadProof http1_prebuilt_deadline_upload;
    u32 http1_prebuilt_header_end;
    u32 http1_prebuilt_total_len;
    u32 http1_prebuilt_body_len;
    u16 http1_prebuilt_status;
    // True when an idle-return stale upstream recv CQE carried bytes. The stale branch
    // rolls those bytes back out of upstream_recv_buf, so the deferred pool-return path
    // needs this separate marker to close rather than reuse a desynced fd.
    bool upstream_recv_idle_stale_bytes;
    // True while a released, closed (non-pooled) upstream's recv is still draining
    // under a pause cancel. Everything in upstream_recv_buf is then stale (the
    // successor's recv is deferred until the drain), including a lossy -ENOBUFS
    // prefix the stale branch cannot roll back, so the drain resets the buffer.
    bool upstream_recv_close_quarantine;
    // True while a handler yield timer is logically armed. For io_uring,
    // the timer may be backed either by an IORING_OP_TIMEOUT SQE or by the
    // coarse timer wheel fallback.
    bool yield_armed;
    // True only when an IORING_OP_TIMEOUT SQE is in flight for the yield.
    // Used to avoid cancel SQEs for wheel-backed yields.
    bool yield_timeout_armed;

    // Response status (set by handler/proxy, used by access log)
    u16 resp_status;

    // Access-log metadata captured from the request/peer.
    u8 req_method;
    // Raw HTTP/1 request bytes received downstream and assigned to this request boundary.
    u32 downstream_req_size;
    // Internal request/upstream-policy length bookkeeping; not the preserved downstream access
    // size or actual partial-send telemetry.
    u32 req_size;
    u32 peer_addr;
    u16 peer_port;
    char req_path[kMaxReqPathLen];
    // View into req_path covering the canonical-for-routing path slice
    // (leading '/' stripped, trailing '/' run trimmed, bytes after first
    // '?' or '#' excluded). Populated by capture_request_metadata as a
    // free byproduct of the URI SIMD scan; read by dispatch via
    // RouteConfig::match_canonical to avoid a redundant canon pass on
    // the hot path. Valid only for the current request — reset() clears.
    Str req_path_canon;

    // Proxy timing/name for access log.
    u32 upstream_us;
    char upstream_name[kMaxUpstreamNameLen];
    u64 upstream_start_us;

    // Traffic capture: raw headers staged at on_header_received,
    // written to CaptureRing at on_request_complete. Null when capture disabled.
    u8* capture_buf;
    u16 capture_header_len;

    // Request timing (for access log)
    u64 req_start_us;

    // Ownership transferred from request timing after completion bookkeeping
    // but before a deferred continuation releases the RCU config epoch. HTTP/2
    // async streams use it while parked without h1-style request metrics; the
    // internal HTTP/1 prebuilt-response rendezvous uses it after req_start_us is
    // cleared and before batch-end request-boundary admission.
    bool epoch_held;

    // A closing io_uring slot may still have a downstream Send CQE whose
    // source is the current config's borrowed local response body.  Keep the
    // config epoch pinned across free_conn::reset() until that CQE (or its
    // cancel) has drained.
    bool epoch_leave_deferred;

    // Outstanding I/O ops submitted to the backend. Incremented on
    // submit_recv/submit_send/etc., decremented when the final CQE
    // arrives in dispatch() (multishot CQEs with IORING_CQE_F_MORE
    // don't decrement). Used to drive CQE-based slice reclamation:
    // a closed connection's pooled slices are only returned to the pool
    // after all in-flight ops have completed (pending_ops reaches 0).
    //
    // u32: multishot recv stays armed across keep-alive cycles, but
    // on_response_sent re-submits submit_recv each cycle, growing the
    // counter by ~1 per request. u32 avoids wraparound (~4B requests).
    // The proper fix is to not re-arm multishot recv on keep-alive.
    u32 pending_ops;

    // Recv/send buffers — backed by SlicePool slices (16KB each).
    // Slices are allocated in EventLoop::alloc_conn_impl() and freed in free_conn_impl().
    // Free connections hold nullptr; a live idle connection keeps its slices bound
    // (the io_uring loop trims their dirty pages once idle for a few seconds).
    u8* recv_slice;
    // Capacity declared when recv_slice was installed by the owning loop.  Keep
    // this independent of Buffer's mutable binding so checked request metadata
    // can reject a rebound/shifted/recapped Buffer before reading through it.
    u32 recv_slice_capacity;
    u8* send_slice;
    Buffer recv_buf;
    Buffer send_buf;
    u32 send_progress;
    const u8* local_body_cursor = nullptr;
    u32 local_body_remaining = 0;
    u32 local_body_send_len = 0;
    // The local body's sealed memfd (fd, or -1) and its first byte, so a
    // chunk at local_body_cursor is file offset cursor - base.
    i32 local_body_file_fd = -1;
    const u8* local_body_base = nullptr;
    u32 local_response_size = 0;

    // Upstream recv buffer — separate from client recv_buf to prevent:
    // 1. Client pipelined data being parsed as upstream response
    // 2. Stale UpstreamRecv CQEs corrupting client request parsing
    // 3. Client Recv during response streaming polluting upstream body data
    // Lazy-allocated: only proxy connections pay the cost.
    u8* upstream_recv_slice;
    Buffer upstream_recv_buf;
    ResponseBodyChain response_body_tail{};
    ChainDirectRecvOwner chain_direct_recv_owner{};
    RelayOwner relay_owner{};

    // io_uring only: true while a *direct* one-shot upstream recv (straight
    // into either upstream_recv_buf's bulk-sized destination, or — for a
    // response_read_deadline connection buffering a complete body
    // (response_read_deadline_post_commit_phase == Buffering) —
    // response_body_tail's tail node; see IoUringBackend::add_recv_upstream_direct)
    // is armed in the kernel. Set on successful submit, cleared only by the
    // backend when that recv's terminal CQE is consumed. While true,
    // upstream_recv_slice / upstream_recv_buf (or the chain tail node) must
    // not be freed or rebound: the kernel may still be writing into that
    // exact memory. epoll never sets this.
    bool upstream_recv_direct_armed = false;

    // A validated large plaintext Content-Length body can start its overflow
    // chain with a bulk node. Unknown/small responses and TLS retain the
    // measured ordinary-slice threshold, and allocation still falls back.
    u32 buffered_response_bulk_after() const {
        if (!tls_active &&
            response_read_deadline_post_commit_phase ==
                ResponseReadDeadlinePostCommitPhase::Buffering &&
            response_read_deadline_post_commit_declared_body > SlicePool::kBulkSliceSize)
            return 0;
        return tls_active ? ResponseBodyChain::kBulkAfterTls
                          : ResponseBodyChain::kBulkAfterPlaintext;
    }
    BufferedSendVector response_send_vector{};
    // Only chain-owned committed bytes may cross a node boundary in one send.
    u32 buffered_response_send_span_size() const {
        const u32 first = buffered_response_front_size();
        if (tls_active || upstream_recv_buf.len() != 0 ||
            response_read_deadline_buffering != ForwardResponseBufferingMode::Bounded ||
            response_body_tail.head == nullptr || response_body_tail.head->next == nullptr)
            return first;
        const auto* next = response_body_tail.head->next;
        const u32 second = next->len - next->offset;
        return first + second;
    }
    bool buffered_response_send_range_is_valid(u32 len) const {
        const u32 first = buffered_response_front_size();
        if (len <= first) return true;
        if (len > buffered_response_send_span_size() || response_body_tail.head == nullptr ||
            response_body_tail.head->next == nullptr || upstream_recv_buf.len() != 0)
            return false;
        const auto* next = response_body_tail.head->next;
        return response_send_vector.first_source == buffered_response_data() &&
               response_send_vector.second_source ==
                   ResponseBodyChain::payload(next) + next->offset &&
               response_send_vector.first_size == first && response_send_vector.total_size == len;
    }
    u32 buffered_response_len() const { return upstream_recv_buf.len() + response_body_tail.size; }
    const u8* buffered_response_data() const {
        return upstream_recv_buf.len() ? upstream_recv_buf.data() : response_body_tail.data();
    }
    u32 buffered_response_front_size() const {
        return upstream_recv_buf.len() ? upstream_recv_buf.len() : response_body_tail.front_size();
    }

    // io_uring: the final response was written directly and its Send
    // completion (which accounts the request) is still pending.
    bool direct_write_completion_pending;
    // io_uring plaintext body relay: the second upstream receive slice. While
    // a client send reads one slice, the next upstream recv fills the other.
    // Owned like the other slices: freed only once no kernel op references it.
    u8* upstream_relay_slice;
    u32 upstream_relay_send_len;  // bytes of upstream_relay_slice in flight; 0 = none
    // Nonzero while TLS overflow classification is deferred; also records the
    // copied prefix length. The high bit marks deferred classification.
    u32 tls_recv_overflow_prefix_len;
    static constexpr u32 kTlsOverflowResumeBit = 1u << 31;
    bool tls_recv_overflow_resume_pending() const {
        return (tls_recv_overflow_prefix_len & kTlsOverflowResumeBit) != 0;
    }
    u32 tls_recv_overflow_prefix_size() const {
        return tls_recv_overflow_prefix_len & ~kTlsOverflowResumeBit;
    }
    void set_tls_recv_overflow_prefix_size(u32 size) {
        tls_recv_overflow_prefix_len =
            size | (tls_recv_overflow_prefix_len & kTlsOverflowResumeBit);
    }
    void set_tls_recv_overflow_resume_pending(bool pending) {
        if (pending)
            tls_recv_overflow_prefix_len |= kTlsOverflowResumeBit;
        else
            tls_recv_overflow_prefix_len &= ~kTlsOverflowResumeBit;
    }
    bool recv_pause_must_survive_send() const {
        return req_body_lossy_successor || req_body_abandoned || req_body_overflow_rejected ||
               tls_recv_overflow_prefix_len != 0;
    }
    void clear_recv_pause_for_send() {
        if (!recv_pause_must_survive_send()) recv_paused_for_send = false;
    }

    void bind_request_receive_buffer(u8* slice, u32 capacity) {
        clear_raw_request_target_witness();
        recv_slice = slice;
        recv_slice_capacity = capacity;
        recv_buf.bind(slice, capacity);
    }

    void clear_response_accounting() {
        resp_status = 0;
        resp_body_mode = BodyMode::None;
        resp_body_remaining = 0;
        resp_chunk_parser.reset();
        resp_body_sent = 0;
        upstream_send_len = 0;
    }

    void reset() {
        response_body_tail = {};
        chain_direct_recv_owner = {};
        relay_owner = {};
        on_recv = nullptr;
        on_send = nullptr;
        on_upstream_recv = nullptr;
        on_upstream_send = nullptr;
        fd = -1;
        id = 0;
        state = ConnState::Idle;
        shard_id = 0;
        flags = 0;
        timer_slot = 0;
        timer_node.init();
        idle_node.init();
        upstream_fd = -1;
        upstream_idx = 0;
        upstream_attempts = 0;
        upstream_backend_idx = 0;
        proxy_resp_started = false;
        upstream_abandoned = false;
        req_body_overflow_rejected = false;
        tls_recv_overflow_prefix_len = 0;
        req_body_lossy_successor = false;
        req_body_abandoned = false;
        upstream_keep_alive = false;
        upstream_reused = false;
        upstream_request_incomplete = false;
        idle_return_fd = -1;
        idle_return_uid = 0;
        idle_return_bidx = 0;
        idle_return_config = nullptr;
        close_after_idle_return = false;
        is_health_probe = false;
        h2_proxy_recv_draining = false;
        h2_proxy_synth_quarantined = false;
        req_path_overridden = false;
        req_path_override = {nullptr, 0};
        target_transform_id = 0;
        target_transform_recorded = false;
        req_header_override_count = 0;
        req_header_append_mask = 0;
        req_header_override_overflow = false;
        resp_header_mutation_pending_count = 0;
        resp_header_mutation_pending_overflow = false;
        resp_header_mutation_count = 0;
        resp_header_mutation_overflow = false;
        response_header_slice = nullptr;
        response_header_buf.bind(nullptr, 0);
        upstream_slot_held = false;
        upstream_slot_uid = 0;
        throttle_down_bps = 0;
        throttle_tat_ns = 0;
        throttle_paused = false;
        throttle_pending_len = 0;
        is_ws_tunnel = false;
        ws_client_send_pending = false;
        ws_upstream_send_pending = false;
        ws_client_send_len = 0;
        ws_upstream_send_len = 0;
        ws_upgrade_response_len = 0;
        ws_upgrade_sent_len = 0;
        ws_pre_tunnel_upstream_closed = false;
        ws_client_eof = false;
        ws_upstream_eof = false;
        is_ws_terminate_route = false;
        is_ws_terminate = false;
        ws_handler = nullptr;
        ws_max_message_size = 0;
        ws_close_code = 1000;
        ws_echo_close_code = 1000;
        ws_c2u.reset();
        ws_u2c.reset();
        ws_c2u.message_len = 0;
        ws_u2c.message_len = 0;
        ws_c2u_msg = nullptr;
        ws_u2c_msg = nullptr;
        ws_c2u_consumed = 0;
        ws_u2c_consumed = 0;
        ws_closing = false;
        ws_close_client_need = false;
        ws_close_client_inflight = false;
        ws_close_upstream_need = false;
        ws_close_upstream_inflight = false;
        idle_trim_examined = false;
        handler_state = 0;
        pending_yield_kind = jit::YieldKind::Timer;
        resume_event_kind = jit::YieldKind::Timer;
        resume_event_result = 0;
        handler_ctx = nullptr;
        // Deliberately NOT reset here: handler_gen persists across
        // reset() so a stale YieldHeap entry whose target slot was
        // recycled reliably fails the generation match. It's
        // initialized at accept-time via EventLoop::alloc_conn_impl.
        // upstream_episode follows the same persistence rule for the future
        // upstream-event token contract and is intentionally not reset here.
        // response_read_deadline_generation follows that persistence rule too;
        // only the live owner is cleared.
        clear_response_read_deadline();
        visit_response_read_deadline_send_close_owner_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
        // The precise response-read timer owns its on-connection timespec until
        // both target/cancel CQEs drain. Preserve active ownership across reset;
        // neutral storage may be hygienically cleared without touching its
        // persistent generation counter.
        if (response_read_timer_owner_is_neutral()) clear_response_read_timer_owner();
        request_config = nullptr;
        listener_context = {};
        pending_handler_fn = nullptr;
        yield_timespec.tv_sec = 0;
        yield_timespec.tv_nsec = 0;
        yield_timer_gen = 0;
        keep_alive = false;
        tls_active = false;
        tls_handshake_complete = false;
        protocol = ConnProtocol::Http11;
        downstream_completed_request_count = 0;
        h2 = nullptr;  // pool slot is released by free_conn_impl, not reset()
        tls = nullptr;
        // tls_engine.ssl is SSL_free'd by close_conn_impl before reset(); null
        // here purely for hygiene on slot reuse (no double-free).
        tls_engine.ssl = nullptr;
        tls_engine.handshake_done = false;
        tls_in_slice = nullptr;
        tls_in_buf.bind(nullptr, 0);
        tls_out_slice = nullptr;
        tls_out_buf.bind(nullptr, 0);
        visit_tls_raw_send_owner_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
        tls_recv_paused_hw = false;
        resp_fully_buffered = false;
        tls_proxy_stream = false;
        tls_pending_on_recv = nullptr;
        visit_tls_single_shot_send_owner_fields(
            *this, [](auto& value, const auto& reset_value) { value = reset_value; });
        pipeline_depth = 0;
        pipeline_stash_len = 0;
        http1_pipeline_request_generation = 0;
        http1_pipeline_boundary_owners_settled = false;
        req_header_end = 0;
        req_content_length = 0;
        req_initial_send_len = 0;
        retry_req_send_len = 0;
        retry_req_snapshot_replayable = true;
        response_mutations_snapshotted = false;
        req_malformed = false;
        request_policy_id = 0;
        request_policy_body_pending = false;
        pending_forward_upstream_id = 0;
        pending_forward_request_policy_id = 0;
        pending_forward_response_policy_id = 0;
        pending_forward_failure_policy_id = 0;
        pending_forward_timeout_failure_policy_id = 0;
        request_body_fully_buffered = false;
        request_upload_complete = false;
        response_policy_id = 0;
        response_policy_suppress_body = false;
        failure_policy_id = 0;
        timeout_failure_policy_id = 0;
        failure_policy_suppress_body = false;
        req_http_version = 255;
        req_strict_h1_complete = false;
        req_metadata_episode = 0;
        req_raw_target_episode = 0;
        req_raw_target_offset = 0;
        req_raw_target_length = 0;
        req_target_has_fragment = false;
        req_target_form_unsupported = false;
        req_target_form_reject_before_pre_route = false;
        clear_access_log_target_snapshot();
        req_keep_alive = false;
        req_client_keep_alive = false;
        req_client_connection_close = false;
        req_client_connection_close_exact = false;
        req_client_connection_keep_alive_exact = false;
        req_client_has_content_length = false;
        req_client_content_length_count = 0;
        req_client_transfer_encoding = RequestTransferEncoding::Unparsed;
        req_client_has_transfer_encoding = false;
        req_client_has_te = false;
        req_client_has_expect = false;
        req_client_has_upgrade_header = false;
        req_client_connection_count = 0;
        req_wants_upgrade = false;
        req_upgrade_is_websocket = false;
        resp_upgrade_is_websocket = false;
        req_body_mode = BodyMode::None;
        req_body_remaining = 0;
        req_chunk_parser.reset();
        req_body_streamed = false;
        clear_response_accounting();
        recv_armed = false;
        send_armed = false;
        upstream_connect_armed = false;
        upstream_recv_armed = false;
        upstream_recv_direct_armed = false;
        upstream_send_armed = false;
        recv_paused_for_send = false;
        recv_pause_cancel_pending = false;
        recv_pause_target_inflight = false;
        recv_pause_rearm_pending = false;
        upstream_recv_paused_for_send = false;
        upstream_recv_pause_cancel_pending = false;
        upstream_recv_pause_rearm_pending = false;
        upstream_recv_cancel_inflight = false;
        upstream_recv_terminal_stale = false;
        // upstream_retiring_episode deliberately persists across reset()/reuse;
        // see its declaration. Active ownership never does.
        upstream_retirement_active = false;
        upstream_retirement_target_owned = 0;
        upstream_retirement_cancel_owned = 0;
        upstream_retirement_cancel_retry = 0;
        upstream_close_episode = 0;
        upstream_close_target_owned = 0;
        upstream_close_cancel_owned = 0;
        upstream_close_pause_cancel_owned = false;
        http1_boundary_deferred = false;
        http1_boundary_ready = false;
        http1_boundary_successor_episode = 0;
        http1_prebuilt_wait = 0;
        http1_prebuilt_disposition = Http1RequestBufferDisposition::None;
        http1_prebuilt_request_prefix_len = 0;
        clear_http1_prebuilt_response_proof();
        upstream_recv_idle_stale_bytes = false;
        upstream_recv_close_quarantine = false;
        yield_armed = false;
        yield_timeout_armed = false;
        req_method = 0;
        downstream_req_size = 0;
        req_size = 0;
        peer_addr = 0;
        peer_port = 0;
        req_path[0] = '\0';
        req_path_canon = {nullptr, 0};
        upstream_us = 0;
        upstream_name[0] = '\0';
        upstream_start_us = 0;
        capture_buf = nullptr;
        capture_header_len = 0;
        req_start_us = 0;
        epoch_held = false;
        epoch_leave_deferred = false;
        pending_ops = 0;
        recv_slice = nullptr;
        recv_slice_capacity = 0;
        send_slice = nullptr;
        recv_buf.bind(nullptr, 0);
        send_buf.bind(nullptr, 0);
        send_progress = 0;
        local_body_cursor = nullptr;
        local_body_remaining = 0;
        local_body_send_len = 0;
        local_body_file_fd = -1;
        local_body_base = nullptr;
        local_response_size = 0;
        upstream_recv_slice = nullptr;
        upstream_recv_buf.bind(nullptr, 0);
        direct_write_completion_pending = false;
        upstream_relay_slice = nullptr;
        upstream_relay_send_len = 0;
    }
};

}  // namespace rut
