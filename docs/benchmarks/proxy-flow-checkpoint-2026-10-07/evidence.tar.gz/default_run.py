import json,os,subprocess,shlex,sys
from pathlib import Path
root=Path(__file__).resolve().parent
name,window,duration,concurrency=sys.argv[1:5]
out=root/name;out.mkdir(exist_ok=False);subprocess.run(['chcon','-t','container_file_t',str(out)],check=True)
args=['python3',str(root/'harness.py'),'--rut',str(Path(sys.argv[5]) if len(sys.argv)>5 else root/'build/src/rut'),'--converter','/home/hurricane/private/code/rut-perf-runtime-next-build/src/rut-nginx-convert','--wrk','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/wrk-boringssl-src2','--output',str(out),'--server-cpu','2','--origin-cpu','3','--client-cpus','5,7','--body-size','1048576','--proxy-profile','converter-bounded','--bounded-origin-reuse','on','--keepalive-header','implicit','--scenarios','proxy-close','proxy-keepalive','--concurrency',*concurrency.split(','),'--warmup','5','--duration',duration,'--repeats','1','--first-engine','rut','--front-port','8428','--origin-port','8528']
env=os.environ.copy();env.pop('RUT_STUDY_BODY_WINDOW_KIB',None);env['TMPDIR']=str(root/'tmp')
(root/(name+'-command.json')).write_text(json.dumps(dict(args=args,byte_window_kib=0,physical_block_pressure=bool(env.get("RUT_STUDY_PHYSICAL_BLOCK_LIMIT"))),indent=2))
with (root/(name+'.log')).open('w') as f:r=subprocess.run(['sg','docker','-c',shlex.join(args)],env=env,stdout=f,stderr=subprocess.STDOUT)
print(name,r.returncode,flush=True);raise SystemExit(r.returncode)
