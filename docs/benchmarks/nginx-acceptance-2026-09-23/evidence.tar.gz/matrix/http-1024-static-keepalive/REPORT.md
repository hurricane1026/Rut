# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| static | keepalive | 1 | 48,401 | 50,573 | 1.04× | 34 | 31 |
| static | keepalive | 32 | 124,021 | 180,991 | 1.46× | 336 | 241 |
| static | keepalive | 128 | 125,583 | 184,414 | 1.47× | 1,331 | 810 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
