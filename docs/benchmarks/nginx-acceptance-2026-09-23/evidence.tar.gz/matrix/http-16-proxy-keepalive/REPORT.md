# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| proxy | keepalive | 1 | 9,937 | 11,098 | 1.12× | 125 | 122 |
| proxy | keepalive | 32 | 15,284 | 17,773 | 1.16× | 2,415 | 2,519 |
| proxy | keepalive | 128 | 15,215 | 19,347 | 1.27× | 9,039 | 8,464 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
