# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| proxy | keepalive | 1 | 8,586 | 10,400 | 1.21× | 147 | 130 |
| proxy | keepalive | 32 | 12,795 | 16,530 | 1.29× | 3,035 | 2,345 |
| proxy | keepalive | 128 | 12,669 | 18,339 | 1.45× | 15,875 | 7,907 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
