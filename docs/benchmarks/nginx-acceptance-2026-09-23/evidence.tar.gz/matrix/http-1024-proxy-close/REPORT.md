# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| proxy | close | 1 | 6,830 | 8,058 | 1.18× | 142 | 125 |
| proxy | close | 32 | 12,484 | 13,896 | 1.11× | 2,760 | 2,455 |
| proxy | close | 128 | 12,472 | 13,827 | 1.11× | 10,781 | 12,811 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
