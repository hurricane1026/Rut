# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| static | keepalive | 1 | 29,864 | 35,610 | 1.19× | 49 | 42 |
| static | keepalive | 32 | 63,552 | 146,172 | 2.30× | 1,282 | 383 |
| static | keepalive | 128 | 62,246 | 142,677 | 2.29× | 4,795 | 1,524 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
