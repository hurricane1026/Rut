# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| static | keepalive | 1 | 48,952 | 51,268 | 1.05× | 35 | 34 |
| static | keepalive | 32 | 127,253 | 190,618 | 1.50× | 309 | 2,242 |
| static | keepalive | 128 | 126,549 | 196,355 | 1.55× | 1,260 | 738 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
