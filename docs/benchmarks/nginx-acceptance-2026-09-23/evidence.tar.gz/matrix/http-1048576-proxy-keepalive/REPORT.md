# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| proxy | keepalive | 1 | INVALID / INCOMPLETE | INVALID / INCOMPLETE | — | INVALID / INCOMPLETE | INVALID / INCOMPLETE |
| proxy | keepalive | 32 | INVALID / INCOMPLETE | INVALID / INCOMPLETE | — | INVALID / INCOMPLETE | INVALID / INCOMPLETE |
| proxy | keepalive | 128 | INVALID / INCOMPLETE | INVALID / INCOMPLETE | — | INVALID / INCOMPLETE | INVALID / INCOMPLETE |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
