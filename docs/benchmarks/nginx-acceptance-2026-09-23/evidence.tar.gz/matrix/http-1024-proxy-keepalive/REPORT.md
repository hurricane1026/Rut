# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| proxy | keepalive | 1 | 9,844 | 10,980 | 1.12× | 139 | 128 |
| proxy | keepalive | 32 | 15,186 | 17,318 | 1.14× | 2,343 | 2,651 |
| proxy | keepalive | 128 | 15,108 | 19,264 | 1.28× | 8,923 | 8,827 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
