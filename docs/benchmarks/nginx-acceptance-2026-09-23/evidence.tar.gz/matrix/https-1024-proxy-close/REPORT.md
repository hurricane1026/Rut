# Local nginx / RUT benchmark

Medians of per-run metrics; p99 values are not merged histograms. Errored, zero-throughput, missing-repeat or incomplete groups have no capacity ratio.

| Workload | Connection | Concurrency | nginx req/s | RUT req/s | RUT/nginx | nginx p99 µs | RUT p99 µs |
|---|---|---:|---:|---:|---:|---:|---:|
| proxy | close | 1 | 856 | 990 | 1.16× | 302 | 221 |
| proxy | close | 32 | 1,095 | 1,455 | 1.33× | 4,573 | 17,560 |
| proxy | close | 128 | 1,083 | 1,426 | 1.32× | 4,675 | 73,460 |

Raw values, warmup/measurement errors, repeat counts, CPU and RSS are in summary.csv. Raw values from invalid groups are diagnostic only. Socket errors are not a request failure rate. Each frontend process persists across concurrency levels within a repeat. See environment.json for conditions and status.json for completion/cleanup status.
