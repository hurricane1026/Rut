import json, socket, struct, subprocess, sys, time, hashlib, os
from pathlib import Path
root=Path(__file__).resolve().parent
variant=sys.argv[1]
suffix=sys.argv[2] if len(sys.argv)>2 else 'wire'
out=root/(variant+'-'+suffix);out.mkdir(exist_ok=False)
pattern='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_.'
small=(pattern*((65536//len(pattern))+1))[:65536].encode()
big=(pattern*((1048576//len(pattern))+1))[:1048576].encode()
program='listen 127.0.0.1:8419\n'
for name,body in [('small',small),('big',big)]:
    program+='route GET "/'+name+'" { return response(200, body: "'+body.decode()+'") }\n'
program+='route GET "/next" { return response(204) }\n'
(out/'wire.rut').write_text(program)
argv=['taskset','-c','2',str(root/(variant+'-bin')/'rut'),str(out/'wire.rut'),'--shards','1','--no-pin','--drain','1','--opt','2']
(out/'command.json').write_text(json.dumps(argv,indent=2)+'\n')
log=(out/'server.log').open('w');p=subprocess.Popen(argv,stdout=log,stderr=log,env={**os.environ,'RUT_BENCH_FILE_SPLICE_STATS':'1'})
checks=[]
def connect(slow=False):
    s=socket.socket();s.settimeout(20)
    if slow:s.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,8192)
    s.connect(('127.0.0.1',8419));return s
class Reader:
    def __init__(self,s):self.s=s;self.buf=b''
    def response(self,expected,slow=False):
        while b'\r\n\r\n' not in self.buf:
            part=self.s.recv(4096);assert part,'EOF in header';self.buf+=part
        head,self.buf=self.buf.split(b'\r\n\r\n',1)
        status=int(head.split(b' ')[1]);assert status==(204 if expected==b'' else 200),head
        h={line.split(b':',1)[0].lower():line.split(b':',1)[1].strip() for line in head.split(b'\r\n')[1:]}
        n=int(h.get(b'content-length',b'0'));assert n==len(expected),(n,len(expected))
        while len(self.buf)<n:
            part=self.s.recv(min(65536,n-len(self.buf)) if not slow else min(8192,n-len(self.buf)))
            assert part,'EOF in body';self.buf+=part
            if slow:time.sleep(.001)
        body,self.buf=self.buf[:n],self.buf[n:];assert body==expected,'body mismatch'
        return hashlib.sha256(body).hexdigest()
def request(path,close=False):return ('GET /'+path+' HTTP/1.1\r\nHost: localhost\r\nConnection: '+('close' if close else 'keep-alive')+'\r\n\r\n').encode()
try:
    for i in range(200):
        if p.poll() is not None:raise RuntimeError('server exit '+(out/'server.log').read_text())
        try:
            with connect():pass
            break
        except OSError:time.sleep(.05)
    else:raise RuntimeError('not ready')
    with connect() as s:
        r=Reader(s)
        for name,body in [('small',small),('big',big),('small',small)]:
            s.sendall(request(name));checks.append({'case':'keepalive-'+name,'sha256':r.response(body)})
        s.sendall(request('small')+request('big')+request('next'))
        for name,body in [('small',small),('big',big),('next',b'')]:checks.append({'case':'pipeline-'+name,'sha256':r.response(body)})
    with connect() as s:
        s.sendall(request('big',True));r=Reader(s);checks.append({'case':'closing-big','sha256':r.response(big)});assert not r.buf and s.recv(1)==b''
    with connect(True) as s:
        s.sendall(request('big'));time.sleep(.15);r=Reader(s);checks.append({'case':'slow-big','sha256':r.response(big,True)})
        s.sendall(request('small'));checks.append({'case':'slow-successor','sha256':r.response(small)})
    with connect(True) as s:
        s.sendall(request('big')*8);time.sleep(.25);r=Reader(s)
        for i in range(8):checks.append({'case':'backpressure-pipeline-'+str(i),'sha256':r.response(big,True)})
    time.sleep(.2)
    before=len(list((Path('/proc')/str(p.pid)/'fd').iterdir()))
    for i in range(12):
        s=connect(True);s.sendall(request('big'));time.sleep(.01);s.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0));s.close()
    time.sleep(.5)
    with connect() as s:
        s.sendall(request('big'));r=Reader(s);checks.append({'case':'after-aborts','sha256':r.response(big)})
    time.sleep(.2)
    after=len(list((Path('/proc')/str(p.pid)/'fd').iterdir()));assert after<=before+2,(before,after)
    checks.append({'case':'abort-fd-accounting','before':before,'after':after,'aborts':12})
    task_root=Path('/proc')/str(p.pid)/'task'
    tasks=[]
    for task in task_root.iterdir():
        try:tasks.append({'tid':int(task.name),'stat':(task/'stat').read_text(),'status':(task/'status').read_text()})
        except FileNotFoundError:pass
    (out/'tasks.json').write_text(json.dumps(tasks,indent=2)+'\n')
    (out/'results.json').write_text(json.dumps({'ok':True,'variant':variant,'checks':checks},indent=2)+'\n')
    print(variant,'wire PASS',len(checks),flush=True)
finally:
    p.terminate()
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:p.kill();p.wait()
    log.close()
