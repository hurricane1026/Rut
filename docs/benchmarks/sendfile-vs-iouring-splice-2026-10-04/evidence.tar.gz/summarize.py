import json,statistics,re,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
rows=[]; coordinates=[]; stats=[]
for size,prefix in [(65536,'small2'),(1048576,'big2')]:
 groups=[f'{prefix}-{i}-{v}' for i,v in enumerate(['control','candidate','candidate','control'])]
 subset=[]
 for g in groups:
  for row in json.loads((root/g/'results.json').read_text()):
   row.update(group=g,variant='candidate' if 'candidate' in g else 'control',body_size=size)
   row['cpu_us']=row['server_cpu_pct']/100/row['rps']*1e6
   assert row['valid'] and not any(row['errors'].values()) and not any(row['warmup_errors'].values()),row
   subset.append(row); rows.append(row)
  for log in sorted((root/g).glob('*-rut-*-server.log')):
   for line in log.read_text().splitlines():
    if line.startswith('RUT_FILE_SPLICE_STATS'):
     stats.append(dict(group=g,file=str(log.relative_to(root)),**{k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}))
 for c in [1,128]:
  values={}
  for variant in ['control','candidate']:
   rs=[s for s in subset if s['concurrency']==c and s['variant']==variant and s['engine']=='rut']
   assert len(rs)==6
   values[variant]={'n':len(rs)}
   for metric in ['rps','cpu_us','p99_us']:
    values[variant][metric]=statistics.median(s[metric] for s in rs)
    ratios=[]
    for s in rs:
     match=next(x for x in subset if x['group']==s['group'] and x['rep']==s['rep'] and x['concurrency']==c and x['engine']=='nginx')
     ratios.append(s[metric]/match[metric])
    values[variant][metric+'_nginx_ratio']=statistics.median(ratios)
  changes={k:100*(values['candidate'][k]/values['control'][k]-1) for k in ['rps','cpu_us','p99_us','rps_nginx_ratio','cpu_us_nginx_ratio','p99_us_nginx_ratio']}
  directional=[]
  for ci,ti in [(0,1),(3,2)]:
   d={}
   for metric in ['rps','cpu_us','p99_us']:
    ms=[]
    for i in [ci,ti]:
     rs=[s for s in subset if s['concurrency']==c and s['group']==groups[i] and s['engine']=='rut']
     ms.append(statistics.median(s[metric] for s in rs))
    d[metric+'_pct']=100*(ms[1]/ms[0]-1)
   directional.append(d)
  coordinates.append(dict(body_size=size,concurrency=c,values=values,changes_pct=changes,directional_changes=directional))
result=dict(sample_count=len(rows),all_valid=True,coordinates=coordinates,splice_stats=stats,rows=rows)
assert len(rows)==96
assert len(stats)==24,(len(stats),stats)
assert all(s['setup_failures']==0 and s['pre_pull_fallbacks']==0 for s in stats)
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['rows','splice_stats']},indent=2))
