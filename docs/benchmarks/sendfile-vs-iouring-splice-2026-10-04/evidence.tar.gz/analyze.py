import json, statistics, sys
from pathlib import Path
root=Path(__file__).resolve().parent
groups=sys.argv[1:]
rows=[]
for group in groups:
    for s in json.load(open(root/group/'results.json')):
        s['variant']='candidate' if 'candidate' in group else 'baseline'
        s['group']=group
        s['cpu_us']=s['server_cpu_pct']/100/s['rps']*1e6
        rows.append(s)
assert all(s['valid'] and not any(s['errors'].values()) and not any(s['warmup_errors'].values()) for s in rows)
for c in sorted({s['concurrency'] for s in rows}):
    for variant in ['baseline','candidate']:
        ss=[s for s in rows if s['concurrency']==c and s['variant']==variant and s['engine']=='rut']
        if not ss: continue
        result={'c':c,'variant':variant,'n':len(ss)}
        for metric in ['rps','p99_us','cpu_us']:
            result[metric]=statistics.median(s[metric] for s in ss)
            ratios=[]
            for s in ss:
                match=next(x for x in rows if x['group']==s['group'] and x['rep']==s['rep'] and x['concurrency']==c and x['engine']=='nginx')
                ratios.append(s[metric]/match[metric])
            result[metric+'_nginx_ratio']=statistics.median(ratios)
        print(json.dumps(result))
