#include "rut/runtime/iouring_event_loop.h"
#include <stdio.h>
#include <time.h>
using namespace rut;
static unsigned long long ns() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1000000000ull + t.tv_nsec; }
[[gnu::noinline]] static unsigned long long run(IoUringEventLoop& loop, unsigned iterations) {
 unsigned long long sum = 0;
 for (unsigned i=0;i<iterations;++i) sum += loop.find_response_read_batch_owner((i * 17u) % (loop.response_read_batch_owner_count + 1u));
 return sum;
}
int main() {
 IoUringEventLoop loop;
 for (unsigned count : {1u,32u,128u,256u}) {
  loop.response_read_batch_owner_count=0; loop.response_read_batch_owner_index_active=true;
  __builtin_memset(loop.response_read_batch_owner_index,0,sizeof(loop.response_read_batch_owner_index));
  for(unsigned i=0;i<count;++i) {loop.response_read_batch_owners[i]={};loop.response_read_batch_owners[i].conn_id=i;loop.publish_response_read_batch_owner();}
  for(unsigned repeat=0;repeat<4;++repeat) {
   for(unsigned j=0;j<2;++j) {
    const bool indexed=((j+repeat)&1u)!=0;loop.response_read_batch_owner_index_active=indexed;
    const auto begin=ns();const auto sum=run(loop,1000000u);const auto elapsed=ns()-begin;
    printf("owners=%u indexed=%u ns_per_lookup=%.3f checksum=%llu\n",count,indexed,(double)elapsed/1000000u,sum);
   }
  }
 }
}
