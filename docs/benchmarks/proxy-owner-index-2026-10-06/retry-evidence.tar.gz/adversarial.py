import socket,threading,subprocess,time,json,re
from pathlib import Path
root=Path(__file__).resolve().parent
binary='/tmp/rut-perf-next-build/src/rut'
source=(root/'proxy.rut').read_text()
payload=b''.join(i.to_bytes(4,'big')+bytes((i*17+j*29)&255 for j in range(4092)) for i in range(256))
results=[]
for case in ['keepalive','fin','truncated','timeout','surplus','metadata304','empty200']:
 stop=threading.Event(); failures=[]; connections=[]; sockets=[]
 listener=socket.socket();listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);listener.bind(('127.0.0.1',8727));listener.listen();listener.settimeout(.2)
 count=[0]
 def worker(sock,cid):
  sockets.append(sock);sock.settimeout(.2);buf=b'';requests=0
  try:
   while not stop.is_set():
    try:chunk=sock.recv(8192)
    except socket.timeout:continue
    if not chunk:break
    buf+=chunk
    while b'\r\n\r\n' in buf:
     _,buf=buf.split(b'\r\n\r\n',1);requests+=1;count[0]+=1;n=count[0];connections.append([n,cid,requests])
     if n==2 and case=='timeout':stop.wait(6);return
     body=payload
     if n==2 and case in ('truncated','surplus'):body=payload[:4096] if case=='truncated' else payload[:5000]+b'JUNK'
     if n==2 and case=='empty200':body=b''
     size=0 if n==2 and case=='empty200' else 5000 if n==2 and case in ('truncated','surplus') else len(payload)
     header=f'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: {size}\r\n\r\n'.encode()
     if n==2 and case=='metadata304':header=header.replace(b'200 OK',b'304 Not Modified');body=b''
     sock.sendall(header+body)
     if case=='fin' or (case=='truncated' and n==2):sock.shutdown(socket.SHUT_WR);return
  except (BrokenPipeError,ConnectionResetError):pass
  except Exception as e:failures.append(repr(e))
  finally:sock.close()
 def accept():
  cid=0
  while not stop.is_set():
   try:sock,_=listener.accept()
   except socket.timeout:continue
   except OSError:return
   cid+=1;threading.Thread(target=worker,args=(sock,cid),daemon=True).start()
 thread=threading.Thread(target=accept,daemon=True);thread.start()
 config=root/f'origin-reuse-{case}.rut';config.write_text(source.replace('8427','8627').replace('8527','8727').replace('response_read_timeout: 60s','response_read_timeout: 2s'))
 log=(root/f'origin-reuse-{case}-runtime.log').open('w');proc=subprocess.Popen([binary,str(config),'--shards','1','--no-pin','--drain','1','--opt','2'],stdout=log,stderr=log)
 client=None
 def connect():
  c=socket.create_connection(('127.0.0.1',8627),timeout=5);c.settimeout(5);return c
 def response(c,complete=True):
  c.sendall(b'GET /proxy HTTP/1.1\r\nHost: client.example\r\n\r\n');raw=b''
  while b'\r\n\r\n' not in raw:
   chunk=c.recv(65536)
   if not chunk:return raw,b'',None
   raw+=chunk
  head,body=raw.split(b'\r\n\r\n',1);length=int(re.search(br'Content-Length:\s*(\d+)',head,re.I)[1])
  if head.startswith(b'HTTP/1.1 304'):return head,body,length
  while len(body)<length:
   chunk=c.recv(65536)
   if not chunk:break
   body+=chunk
  return head,body,length
 try:
  until=time.monotonic()+15
  while True:
   try:client=connect();break
   except OSError:
    if proc.poll() is not None or time.monotonic()>until:raise
    time.sleep(.05)
  head,body,length=response(client);assert body==payload and length==len(payload)
  if case=='fin':client.close();client=connect()
  start=time.monotonic();head,body,length=response(client)
  if case=='timeout':assert head.startswith(b'HTTP/1.1 504'),head;assert time.monotonic()-start<4;assert connections[-1][1]==connections[0][1]
  elif case in ('metadata304','empty200'):
   assert body==b'' and length==(len(payload) if case=='metadata304' else 0);assert connections[-1][1]==connections[0][1]
  elif case=='truncated':assert length==5000 and 0<len(body)<5000 and body==payload[:len(body)];assert connections[-1][1]==connections[0][1]
  elif case=='surplus':
   assert body==payload[:len(body)];client.close();client=connect();head,body,length=response(client);assert body==payload;assert connections[-1][1]!=connections[0][1]
  else:
   assert body==payload
   assert (connections[-1][1]==connections[0][1])==(case=='keepalive')
  assert not failures,failures
  results.append(dict(case=case,status='PASS',requests=connections,second_or_final_body_bytes=len(body)))
 except Exception as e:
  results.append(dict(case=case,status='FAIL',error=repr(e),requests=connections));raise
 finally:
  if client:client.close()
  stop.set();listener.close();proc.terminate()
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
  log.close();thread.join(timeout=1)
  (root/'origin-reuse-adversarial-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
