import subprocess,sys,json
from pathlib import Path
root=Path(__file__).resolve().parent
series=[]
for i,mode in enumerate(['baseline','index','index','baseline'],1):
 binary='/home/hurricane/private/code/rut-perf-runtime-next-build/src/rut' if mode=='baseline' else '/tmp/rut-perf-next-build/src/rut'
 group=f'retry-paired-{i}-{mode}'
 r=subprocess.run([sys.executable,str(root/'run.py'),group,'converter-bounded','rut' if i%2 else 'nginx','1','10','on',binary])
 series.append(dict(group=group,mode=mode,binary=binary,returncode=r.returncode))
 (root/'retry-series.json').write_text(json.dumps(series,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
