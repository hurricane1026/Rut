#include "rut/runtime/response_body_chain.h"
#include <stdio.h>
using namespace rut;
int main() {
    SlicePool pool;
    if (!pool.init(4, 0, SlicePool::kMaxCachedSlices, 2).has_value()) return 1;
    u8* guard = pool.alloc_bulk();
    if (!guard) return 2;
    __builtin_memset(guard, 0xa5, SlicePool::kBulkSliceSize);
    for (u32 turn = 0; turn < 100; ++turn) {
        ResponseBodyChain chain;
        if (!chain.reserve_tail(pool, 0)) return 3;
        u8* raw = reinterpret_cast<u8*>(chain.tail);
        __builtin_memset(chain.write_ptr(pool), 0x5a, 200000);
        chain.commit(200000);
        chain.consume(200000, false, true);
        if (!chain.reserve_tail(pool, 0) || raw != reinterpret_cast<u8*>(chain.tail)) return 4;
        __builtin_memset(chain.write_ptr(pool), 0x3c, 4097);
        if (!chain.record_direct_write(chain.tail, chain.write_ptr(pool), 4097, pool)) return 5;
        chain.commit(129);
        chain.release();
        u8* reused = pool.alloc_bulk();
        if (reused != raw) return 6;
        for (u32 i = 0; i < SlicePool::kBulkSliceSize; ++i)
            if (reused[i] != 0 || guard[i] != 0xa5) return 7;
        pool.free(reused);
    }
    pool.free(guard);
    pool.destroy();
    printf("PASS: 100 bulk recycle/dirty high-water/neighbor guard cycles\n");
}
