import subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for i,variant in enumerate(['base','candidate','candidate','base'],1):
 binary='/tmp/rut-bulk-zero-base-bin/rut' if variant=='base' else '/tmp/rut-perf-next-build/src/rut'
 group=f'recycle-{i}-{variant}'
 rc=subprocess.run(['python3',str(root/'bulk_zero_run.py'),group,'converter-bounded','rut','1','10','on',binary]).returncode
 results.append(dict(group=group,variant=variant,rc=rc));(root/'recycle-series.json').write_text(json.dumps(results,indent=2))
 if rc:raise SystemExit(rc)
