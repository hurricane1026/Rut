import ctypes,os,struct,mmap,fcntl,threading,time,json,collections,pathlib
class Sampler:
 def __init__(self,pid,out):
  self.pid=pid;self.out=pathlib.Path(out);self.stop=threading.Event();self.events=[];self.ips=collections.Counter();self.lost=0;self.callers=collections.Counter()
  self.maps=pathlib.Path(f'/proc/{pid}/maps').read_text()
  libc=ctypes.CDLL(None,use_errno=True)
  for tid in pathlib.Path(f'/proc/{pid}/task').iterdir():
   a=ctypes.create_string_buffer(128)
   struct.pack_into('IIQQQQQ',a,0,1,128,0,1000000,1|(1<<13),0,1|(1<<5)|(1<<6))
   struct.pack_into('I',a,88,64)
   fd=libc.syscall(298,ctypes.byref(a),int(tid.name),-1,-1,8)
   if fd<0:raise OSError(ctypes.get_errno(),f'perf_event_open tid {tid.name}')
   mm=mmap.mmap(fd,257*4096,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE)
   self.events.append((fd,mm));fcntl.ioctl(fd,0x2400,0)
  self.thread=threading.Thread(target=self.poll,daemon=True);self.thread.start()
 def poll(self):
  while not self.stop.wait(.01):self.drain()
 def drain(self):
  for fd,mm in self.events:
   head,tail,off,size=struct.unpack_from('QQQQ',mm,1024)
   def read(pos,n):
    at=pos%size;first=min(n,size-at);return mm[off+at:off+at+first]+mm[off:off+n-first]
   while tail<head:
    typ,misc,n=struct.unpack('IHH',read(tail,8))
    if n<8:raise RuntimeError('invalid perf ring record')
    data=read(tail,n)
    if typ==9:
     ip=struct.unpack_from('Q',data,8)[0];self.ips[ip]+=1
     stack_size=struct.unpack_from('Q',data,16)[0]
     if stack_size>=8:self.callers[(ip,struct.unpack_from('Q',data,24)[0])]+=1
    elif typ==2:self.lost+=struct.unpack_from('Q',data,16)[0]
    tail+=n
   struct.pack_into('Q',mm,1032,tail)
 def close(self):
  self.stop.set();self.thread.join()
  for fd,mm in self.events:fcntl.ioctl(fd,0x2401,0)
  self.drain()
  for fd,mm in self.events:mm.close();os.close(fd)
  self.out.write_text(json.dumps(dict(pid=self.pid,maps=self.maps,lost=self.lost,samples=sum(self.ips.values()),ips={hex(k):v for k,v in self.ips.items()},leaf_return_samples=[dict(ip=hex(ip),return_ip=hex(ret),count=n) for (ip,ret),n in self.callers.items()]),indent=2))
