import json,pathlib,collections,struct,subprocess,sys
root=pathlib.Path(sys.argv[1]);c=collections.Counter()
for p in root.glob('*rut*-perf.json'):
 j=json.loads(p.read_text());maps=[]
 for line in j['maps'].splitlines():
  f=line.split(maxsplit=5)
  if len(f)<6:continue
  begin,end=map(lambda x:int(x,16),f[0].split('-'));maps.append((begin,end,int(f[2],16),f[5]))
 def resolve(ip):
  entry=next((m for m in maps if m[0]<=ip<m[1]),None)
  if not entry:return None
  b,e,off,name=entry;path=pathlib.Path(name)
  if not path.is_file():return None
  with path.open('rb') as fp:h=fp.read(18)
  addr=ip-b+off if struct.unpack_from('H',h,16)[0]==3 else ip
  return name,addr
 entries=j.get('leaf_return_samples',[]);symbols={}
 grouped=collections.defaultdict(set)
 for x in entries:
  for key in ['ip','return_ip']:
   value=resolve(int(x[key],16))
   if value:grouped[value[0]].add(value[1])
 for name,addresses in grouped.items():
  addresses=sorted(addresses);r=subprocess.run(['addr2line','-f','-C','-e',name],input=''.join(hex(a)+'\n' for a in addresses),capture_output=True,text=True);lines=r.stdout.splitlines()
  for i,a in enumerate(addresses):symbols[(name,a)]=lines[2*i] if 2*i<len(lines) else '?'
 for x in entries:
  leaf=resolve(int(x['ip'],16));ret=resolve(int(x['return_ip'],16))
  if leaf and 'memset' in symbols.get(leaf,''):
   c[(symbols.get(ret,'?'),hex(ret[1]) if ret else 'unmapped')]+=x['count']
print('memset leaf return attribution',sum(c.values()))
for (name,addr),n in c.most_common(20):print(n,addr,name)
(root/'memset-returns.json').write_text(json.dumps([dict(name=k[0],return_address=k[1],samples=v) for k,v in c.most_common()],indent=2))
