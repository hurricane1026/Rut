import json,pathlib,collections,struct,subprocess,sys
root=pathlib.Path(sys.argv[1]);aggregate=collections.Counter();total=0;lost=0
for p in root.glob('*-perf.json'):
 if 'rut' not in p.name:continue
 j=json.loads(p.read_text());lost+=j['lost'];total+=j['samples'];maps=[]
 for line in j['maps'].splitlines():
  fields=line.split(maxsplit=5)
  if len(fields)<6:continue
  begin,end=[int(x,16) for x in fields[0].split('-')]
  maps.append((begin,end,int(fields[2],16),fields[5]))
 grouped=collections.defaultdict(collections.Counter)
 for ip,count in j['ips'].items():
  ip=int(ip,16);entry=next((m for m in maps if m[0]<=ip<m[1]),None)
  if not entry:aggregate['[unmapped]']+=count;continue
  begin,end,offset,name=entry
  path=pathlib.Path(name)
  if not path.is_file():aggregate[name]+=count;continue
  with path.open('rb') as f:header=f.read(18)
  dyn=struct.unpack_from('H',header,16)[0]==3
  addr=ip-begin+offset if dyn else ip
  grouped[name][addr]+=count
 for name,counts in grouped.items():
  args=['addr2line','-f','-C','-e',name]
  r=subprocess.run(args,input=''.join(hex(a)+'\n' for a in counts),text=True,capture_output=True)
  lines=r.stdout.splitlines()
  for i,(addr,count) in enumerate(counts.items()):
   fn=lines[i*2] if i*2<len(lines) else '?'
   aggregate[pathlib.Path(name).name+': '+fn]+=count
out=dict(samples=total,lost=lost,functions=[dict(name=k,samples=v,pct=100*v/total if total else 0) for k,v in aggregate.most_common()])
(root/'profile-summary.json').write_text(json.dumps(out,indent=2))
print('samples',total,'lost',lost)
for x in out['functions'][:22]:print(round(x['pct'],2),x['samples'],x['name'])
