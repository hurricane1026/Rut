import json,os,shlex,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
group,profile,first,repeats,duration,reuse,binary=sys.argv[1:8]
out=root/group;out.mkdir(exist_ok=False)
subprocess.run(['chcon','-t','container_file_t',str(out)],check=True)
argv=['python3',str(root/'rut_only_harness.py'),'--rut',binary,'--converter','/home/hurricane/private/code/rut-perf-runtime-next-build/src/rut-nginx-convert','--wrk','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/wrk-boringssl-src2','--output',str(out),'--server-cpu','0','--origin-cpu','1','--client-cpus','4,6','--body-size','1048576','--proxy-profile',profile,'--keepalive-header','implicit','--scenarios','proxy-close','proxy-keepalive','--concurrency','1','128','--warmup','2','--duration',duration,'--repeats',repeats,'--first-engine',first,'--front-port','8427','--origin-port','8527']
if profile=='converter-bounded':argv+=['--bounded-origin-reuse',reuse]
if profile=='native-streaming':argv+=['--native-origin-reuse','off','--native-nginx-buffering','on']
(root/(group+'-command.json')).write_text(json.dumps(argv,indent=2)+'\n')
env=os.environ.copy();env['TMPDIR']=str(root/'tmp')
with (root/(group+'.log')).open('w') as log:
 result=subprocess.run(['sg','docker','-c',shlex.join(argv)],stdout=log,stderr=subprocess.STDOUT,env=env)
print(group,result.returncode,flush=True)
sys.exit(result.returncode)
