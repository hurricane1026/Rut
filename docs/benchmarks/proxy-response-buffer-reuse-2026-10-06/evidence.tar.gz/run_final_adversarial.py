from pathlib import Path
root=Path('/tmp/rut-proxy-profile-evidence/adversarial-final');root.mkdir(exist_ok=True)
source=Path('/tmp/rut-owner-index-evidence/adversarial.py').read_text()
(root/'adversarial.py').write_text(source)
(root/'proxy.rut').write_text(Path('/tmp/rut-owner-index-evidence/proxy.rut').read_text())
import subprocess
raise SystemExit(subprocess.run(['python3',str(root/'adversarial.py')]).returncode)
