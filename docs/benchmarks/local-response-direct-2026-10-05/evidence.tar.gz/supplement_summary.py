import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
sections={}
for label,groups in [('diagnostic_contended',['diagnostic-small-baseline','diagnostic-small-candidate']),('tail_confirmation',[f'tail-{i}-{v}' for i,v in enumerate(['baseline','candidate','candidate','baseline'])])]:
 rows=[]
 for g in groups:
  for row in json.loads((root/g/'results.json').read_text()):
   assert row['valid'] and not any(row['errors'].values()) and not any(row['warmup_errors'].values())
   row.update(group=g,variant='candidate' if 'candidate' in g else 'baseline')
   row['cpu_us']=row['server_cpu_pct']/100/row['rps']*1e6
   rows.append(row)
 sections[label]={'sample_count':len(rows),'rows':rows}
(root/'supplement-summary.json').write_text(json.dumps(sections,indent=2)+'\n')
for label,s in sections.items():
 print(label)
 for r in s['rows']:
  print(r['group'],r['engine'],r['concurrency'],round(r['rps'],1),r['p50_us'],r['p95_us'],r['p99_us'],round(r['cpu_us'],4))
