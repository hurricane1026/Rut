import json,socket,ssl,subprocess,sys,time,hashlib,struct
from pathlib import Path
root=Path(__file__).resolve().parent
variant=sys.argv[1]; tls=len(sys.argv)>2 and sys.argv[2]=='tls'
out=root/(variant+('-wire-tls' if tls else '-wire-http'));out.mkdir(exist_ok=False)
pattern='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_.'
bodies={name:(pattern*((size//len(pattern))+1))[:size].encode() for name,size in [('small',16),('big',4093)]}
conf='server { listen 127.0.0.1:8419; '
for name,body in [('big',bodies['big'])]: conf+='location = /'+name+' { return 200 "'+body.decode()+'"; } '
conf+='location / { proxy_pass http://127.0.0.1:8519; } }\n'
(out/'wire.conf').write_text(conf)
converted=subprocess.run([str(root/(variant+'-bin')/'rut-nginx-convert'),'--format','server',str(out/'wire.conf')],capture_output=True,text=True,check=True)
program=converted.stdout
if tls:
 assert program.startswith('listen 127.0.0.1:8419\n');program=program[len('listen 127.0.0.1:8419\n'):]
(out/'wire.rut').write_text(program);(out/'converter.log').write_text(converted.stderr)
argv=['taskset','-c','2',str(root/(variant+'-bin')/'rut'),str(out/'wire.rut'),'--shards','1','--no-pin','--drain','1','--opt','2']
if tls:argv+=['8419','--tls-cert','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/private-tls/localhost_cert.pem','--tls-key','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/private-tls/localhost_key.pem']
(out/'command.json').write_text(json.dumps(argv,indent=2)+'\n')
log=(out/'server.log').open('w');p=subprocess.Popen(argv,stdout=log,stderr=log); checks=[]
ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
ctx.minimum_version=ssl.TLSVersion.TLSv1_3
ctx.maximum_version=ssl.TLSVersion.TLSv1_3

def connect(slow=False):
 s=socket.socket();s.settimeout(20)
 if slow:s.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,8192)
 s.connect(('127.0.0.1',8419))
 return ctx.wrap_socket(s,server_hostname='localhost') if tls else s
class Reader:
 def __init__(self,s):self.s=s;self.buf=b''
 def response(self,name,head=False,slow=False):
  expected=b'' if name=='next' or head else bodies[name]
  while b'\r\n\r\n' not in self.buf:
   part=self.s.recv(4096);assert part,'EOF header';self.buf+=part
  hdr,self.buf=self.buf.split(b'\r\n\r\n',1)
  assert int(hdr.split(b' ')[1])==(204 if name=='next' else 200)
  h={x.split(b':',1)[0].lower():x.split(b':',1)[1].strip() for x in hdr.split(b'\r\n')[1:]}
  n=int(h.get(b'content-length',b'0'));assert n==(0 if name=='next' else len(bodies[name]))
  want=len(expected)
  while len(self.buf)<want:
   part=self.s.recv(min(257 if slow else 65536,want-len(self.buf)));assert part,'EOF body';self.buf+=part
   if slow:time.sleep(.0005)
  body,self.buf=self.buf[:want],self.buf[want:];assert body==expected
  checks.append({'case':('head-' if head else '')+name,'sha256':hashlib.sha256(body).hexdigest()})
def request(name,head=False,close=False):return (('HEAD' if head else 'GET')+' /'+name+' HTTP/1.1\r\nHost: localhost\r\nConnection: '+('close' if close else 'keep-alive')+'\r\n\r\n').encode()
try:
 for i in range(200):
  if p.poll() is not None:raise RuntimeError((out/'server.log').read_text())
  try:
   with connect():pass
   break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('not ready')
 with connect() as s:
  rd=Reader(s)
  for name in ['big','big','big']:
   s.sendall(request(name));rd.response(name)
  s.sendall(request('big',head=True));rd.response('big',head=True)
  s.sendall(request('big'));rd.response('big')
  s.sendall(request('big'));rd.response('big')
 with connect() as s:
  s.sendall(request('big',close=True));rd=Reader(s);rd.response('big');assert not rd.buf and s.recv(1)==b''
 with connect(True) as s:
  rd=Reader(s)
  for _ in range(4):
   for _ in range(2):
    s.sendall(request('big'));time.sleep(.03);rd.response('big',slow=True)
 with connect() as s:
  s.sendall(request('big')*2);assert s.recv(1)==b'', 'unsupported pipeline must fail closed'
  checks.append({'case':'existing-unsupported-pipeline-fails-closed','received_bytes':0})
 time.sleep(.2); before=len(list((Path('/proc')/str(p.pid)/'fd').iterdir()))
 for _ in range(12):
  s=connect();s.sendall(request('big'));s.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0));s.close()
 time.sleep(.3)
 with connect() as s:s.sendall(request('big'));Reader(s).response('big')
 time.sleep(.2);after=len(list((Path('/proc')/str(p.pid)/'fd').iterdir()));assert after<=before+2
 checks.append({'case':'abort-fd-accounting','before':before,'after':after,'aborts':12})
 (out/'results.json').write_text(json.dumps({'ok':True,'variant':variant,'tls':tls,'checks':checks},indent=2)+'\n')
 print(variant,'TLS' if tls else 'HTTP','wire PASS',len(checks),flush=True)
finally:
 p.terminate()
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 log.close()
