import json,hashlib,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=Path('/home/hurricane/private/code/rut-perf-runtime-next/docs/benchmarks/local-response-direct-2026-10-05')
out.mkdir(parents=True,exist_ok=True)
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file(): continue
 rel=p.relative_to(root)
 if any(x in ['tmp','baseline-bin','candidate-bin','payloads'] for x in rel.parts): continue
 if p.suffix in ['.pem','.key','.crt','.rut']: continue
 if p.name.endswith('-response.txt'): continue
 if p.name in ['wire.conf','static-nginx.conf','static.conf','payload.bin','body.txt']: continue
 files.append(p)
manifest={'root':str(root),'excluded':'Frozen binaries, tmp, payloads, generated Rut/static-nginx/wire configurations, certificate/key and full response files; drivers, hashes and all measurements retained.','files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files: t.add(p,arcname=str(p.relative_to(root)),recursive=False)
(out/'evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
for n in ['summary.json','supplement-summary.json']:
 (out/n).write_bytes((root/n).read_bytes())
print(len(files),archive.stat().st_size)
