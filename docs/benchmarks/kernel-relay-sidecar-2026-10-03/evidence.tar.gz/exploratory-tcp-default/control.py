from pathlib import Path
import subprocess,json
root=Path('/home/hurricane/private/code/rut-kernel-relay-20261003')
repo=Path('/home/hurricane/private/code/Rut')
plans=[]
for body,first,warm,duration in [(1048576,'copy',2,8),(1048576,'splice',2,8),(65536,'copy',1,5)]:
 name=f'{body}-{first}-first'
 cmd=['python3',str(repo/'scripts/kernel_relay_benchmark.py'),'--relay',str(root/'bench_kernel_relay'),'--wrk','/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk','--loader',str(root/'loader'),'--libc',str(root/'libc.so.6'),'--output',str(root/name),'--body-size',str(body),'--first-engine',first,'--server-cpu','2','--origin-cpu','3','--client-cpus','4,5','--warmup',str(warm),'--duration',str(duration),'--repeats','3','--concurrency','1','32']
 plans.append(dict(name=name,command=cmd))
(root/'plan.json').write_text(json.dumps(plans,indent=2)+'\n')
status=[]
for p in plans:
 print('start',p['name'],flush=True)
 with (root/(p['name']+'.log')).open('w') as log:r=subprocess.run(p['command'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 status.append(dict(name=p['name'],exit=r.returncode))
 (root/'control-status.json').write_text(json.dumps(status,indent=2)+'\n')
 print('done',status[-1],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
