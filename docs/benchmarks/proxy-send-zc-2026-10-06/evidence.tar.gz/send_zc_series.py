import subprocess,sys,json,os
from pathlib import Path
root=Path(__file__).resolve().parent
series=[]
for i,mode in enumerate(['send','zc','zc','send'],1):
 env=os.environ.copy();env['RUT_EXPERIMENTAL_SEND_ZC']='1' if mode=='zc' else '0'
 group=f'send-zc-paired-{i}-{mode}'
 r=subprocess.run([sys.executable,str(root/'run.py'),group,'converter-bounded','rut' if i%2 else 'nginx','1','10','on','/tmp/rut-perf-next-build/src/rut'],env=env)
 series.append(dict(group=group,mode=mode,returncode=r.returncode))
 (root/'send-zc-series.json').write_text(json.dumps(series,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
