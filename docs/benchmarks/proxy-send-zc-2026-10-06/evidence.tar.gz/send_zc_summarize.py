import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
rows=[]
for d in sorted(root.glob('send-zc-paired-*')):
 if not d.is_dir() or not (d/'results.json').exists():continue
 for r in json.loads((d/'results.json').read_text()):rows.append(dict(group=d.name,mode=d.name.rsplit('-',1)[1],**r))
summary=[]
for conn in ['close','keepalive']:
 for c in [1,128]:
  cell=dict(connection=conn,concurrency=c)
  for mode in ['send','zc']:
   for engine in ['rut','nginx']:
    rs=[r for r in rows if r['connection']==conn and r['concurrency']==c and r['mode']==mode and r['engine']==engine]
    if rs:cell[mode+'_'+engine]=dict(samples=len(rs),valid=all(r['valid'] for r in rs),rps=statistics.median(r['rps'] for r in rs),p99_ms=statistics.median(r['p99_us']/1000 for r in rs),errors=[r['errors'] for r in rs])
  summary.append(cell)
(root/'send-zc-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
