#!/usr/bin/env python3
"""Local pinned-nginx / Rut benchmark; no performance CI gate."""

import argparse
import asyncio
import collections
import contextlib
import hashlib
import json
import os
import re
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCENARIOS = ("static-close", "static-keepalive", "proxy-close", "proxy-keepalive")
ERROR_NAMES = ("connect", "read", "write", "status", "timeout")
# Keep aligned with the converter's safe quoted return-body profile.
STATIC_BODY_LIMIT = 4093
NATIVE_BODY_SIZE = 256 * 1024


def engine_order(first_engine, repeat):
    other_engine = "rut" if first_engine == "nginx" else "nginx"
    return (first_engine, other_engine) if repeat % 2 else (other_engine, first_engine)


def add_first_engine_argument(parser):
    parser.add_argument(
        "--first-engine",
        choices=("nginx", "rut"),
        default="nginx",
        help="first engine in odd-numbered repeats; even repeats alternate",
    )


def save_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def response_head(head, max_body=2048, native_streaming=False):
    if not head.startswith(b"HTTP/1.1 200 OK\r\n"):
        raise ValueError(f"unexpected status: {head[:100]!r}")
    headers = {}
    for line in head.split(b"\r\n")[1:]:
        if not line:
            continue
        key, value = line.split(b":", 1)
        key = key.lower()
        if key in headers:
            raise ValueError(f"duplicate header: {key!r}")
        headers[key] = value.strip()
    length = headers.get(b"content-length", b"")
    if not length.isdigit() or int(length) > max_body or b"transfer-encoding" in headers:
        raise ValueError("expected bounded Content-Length response")
    if native_streaming:
        if headers.get(b"content-type") != b"application/octet-stream":
            raise ValueError("native-streaming requires one application/octet-stream Content-Type")
        connection = headers.get(b"connection", b"").lower()
        if connection not in (b"", b"keep-alive"):
            raise ValueError("native-streaming response must preserve keepalive semantics")
    return int(length), headers.get(b"connection", b"").lower() == b"close"


def connection_header(close, keepalive_header="explicit"):
    return "close" if close else ("keep-alive" if keepalive_header == "explicit" else None)


def request_bytes(work, close, keepalive_header="explicit", preflight_id=None):
    mode = connection_header(close, keepalive_header)
    header = f"Connection: {mode}\r\n" if mode else ""
    marker = f"X-Rut-Benchmark-Preflight: {preflight_id}\r\n" if preflight_id else ""
    return f"GET /{work} HTTP/1.1\r\nHost: client.example\r\n{header}{marker}\r\n".encode()


def expected_body(work, body_size=None, native_streaming=False):
    if native_streaming:
        # Distinct deterministic 4 KiB blocks expose truncation, duplication,
        # and reordering while remaining identical at nginx and Rut.
        blocks = []
        for block in range(NATIVE_BODY_SIZE // 4096):
            prefix = block.to_bytes(4, "big")
            blocks.append(prefix + bytes(((block * 17 + i * 29) & 255) for i in range(4092)))
        return b"".join(blocks)
    if body_size is not None:
        return b"x" * body_size
    return b"hello from nginx" if work == "static" else b"x" * 1024


def canonical_native_static_response(raw):
    head, body = raw.split(b"\r\n\r\n", 1)
    lines = head.split(b"\r\n")
    headers = {}
    for line in lines[1:]:
        key, value = line.split(b":", 1)
        headers[key.lower()] = value.strip()
    if headers.get(b"content-type") != b"text/plain; charset=utf-8":
        raise ValueError("native static response has unexpected Content-Type")
    # Engine identity and wall-clock metadata differ; all framing/content
    # headers and the complete body must still match between engines.
    headers.pop(b"server", None)
    headers.pop(b"date", None)
    return lines[0] + b"\r\n" + b"\r\n".join(
        key + b": " + value for key, value in sorted(headers.items())
    ) + b"\r\n\r\n" + body


def preflight_request_count(body_size):
    # Bound repeated full-body comparisons; retain three consecutive requests
    # even for MiB bodies so keepalive reuse crosses more than one boundary.
    return max(3, min(100, (1024 * 1024) // max(1, body_size)))


def response(sock, work, close, keepalive_header="explicit", body_size=None,
             native_streaming=False, preflight_id=None):
    sock.sendall(request_bytes(work, close, keepalive_header, preflight_id))
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = sock.recv(4096)
        if not chunk:
            raise ValueError("EOF before response header")
        data += chunk
        if len(data) > 8192:
            raise ValueError("oversized response")
    head, body = data.split(b"\r\n\r\n", 1)
    wanted = expected_body(work, body_size, native_streaming)
    length, server_close = response_head(head, len(wanted), native_streaming)
    chunks = [body]
    received = len(body)
    while received < length:
        chunk = sock.recv(min(65536, length - received))
        if not chunk:
            raise ValueError("EOF before complete body")
        chunks.append(chunk)
        received += len(chunk)
    body = b"".join(chunks)
    if received != length or body != wanted:
        raise ValueError("unexpected body")
    if (close or server_close) and sock.recv(1) != b"":
        raise ValueError("expected EOF after response")
    normalized = head if native_streaming else re.sub(rb"(?im)^Date: [^\r\n]+", b"Date: NORMALIZED", head)
    return normalized + b"\r\n\r\n" + body, server_close


def proc_usage(pid):
    """Parent + direct children; RSS can double-count nginx shared pages."""
    ids = [pid]
    ids += [
        int(p) for p in Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
    ]
    ticks = rss = 0
    for child in ids:
        fields = Path(f"/proc/{child}/stat").read_text().rsplit(")", 1)[1].split()
        ticks += int(fields[11]) + int(fields[12])
        rss += int(fields[21]) * os.sysconf("SC_PAGE_SIZE")
    return ticks / os.sysconf("SC_CLK_TCK"), rss


class Harness:
    def __init__(self, args):
        self.args = args
        self.out = args.output
        self.prefix = "rut-bench-" + uuid.uuid4().hex[:12]
        self.image = (ROOT / "tests/pinned-nginx-image.txt").read_text().strip()
        self.references = {}
        self.results = []
        self.commands = []
        self.tls_context = None
        if getattr(args, "tls_cert", None):
            self.tls_context = ssl.create_default_context(cafile=str(args.tls_cert))
            self.tls_context.set_alpn_protocols(["http/1.1"])
            self.tls_context.minimum_version = ssl.TLSVersion.TLSv1_3
            self.tls_context.maximum_version = ssl.TLSVersion.TLSv1_3

    def command(self, argv, *, timeout=20):
        argv = [str(v) for v in argv]
        self.commands.append(argv)
        save_json(self.out / "commands.json", self.commands)
        # Own a process group: interrupting GNU time must also stop its wrk child.
        with subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
        ) as process:
            try:
                stdout, stderr = process.communicate(timeout=timeout)
            except BaseException as error:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                stdout, stderr = process.communicate()
                (self.out / f"command-failure-{len(self.commands)}.log").write_text(
                    repr(error) + "\n" + stdout + stderr
                )
                raise
            if process.returncode:
                error = subprocess.CalledProcessError(
                    process.returncode, argv, stdout, stderr
                )
                (self.out / f"command-failure-{len(self.commands)}.log").write_text(
                    repr(error) + "\n" + stdout + stderr
                )
                raise error
            return subprocess.CompletedProcess(argv, process.returncode, stdout, stderr)

    def prepare(self):
        a = self.args
        first_engine = getattr(a, "first_engine", "nginx")
        body_size = getattr(a, "body_size", None)
        native_streaming = getattr(a, "proxy_profile", "converter-strict") == "native-streaming"
        if native_streaming:
            body_size = NATIVE_BODY_SIZE
        if (getattr(a, "static_profile", "converter-return") == "converter-return"
                and body_size is not None and body_size > STATIC_BODY_LIMIT
                and any(scenario.startswith("static-") for scenario in a.scenarios)):
            raise ValueError(
                f"unsupported static body: converter local_response is bounded to "
                f"{STATIC_BODY_LIMIT} bytes; this matrix cell has NOT passed"
            )
        context = self.command(["docker", "context", "inspect"]).stdout
        endpoint = (
            os.environ.get("DOCKER_HOST")
            or json.loads(context)[0]["Endpoints"]["docker"]["Host"]
        )
        if not endpoint.startswith("unix://"):
            raise ValueError(
                "this harness requires a local Docker daemon via a Unix socket"
            )
        self.command(["docker", "info", "--format", "{{.ServerVersion}}"])
        inspection = json.loads(
            self.command(["docker", "image", "inspect", self.image]).stdout
        )[0]
        metadata = {
            "harness_revision": self.command(
                ["git", "-C", ROOT, "rev-parse", "HEAD"]
            ).stdout.strip(),
            "harness_dirty": bool(
                self.command(["git", "-C", ROOT, "status", "--porcelain"]).stdout
            ),
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "arguments": {
                k: str(v) if isinstance(v, Path) else v for k, v in vars(a).items()
            },
            "static_profile": getattr(a, "static_profile", "converter-return"),
            "proxy_profile": {
                "name": getattr(a, "proxy_profile", "converter-strict"),
                "body_size": body_size,
                "origin_keepalive": "enabled; 60s idle timeout" if native_streaming else "disabled",
                "native_origin_reuse_observation": "conditional access log for marked preflight requests only" if native_streaming else None,
                "nginx_keepalive_requests": ({
                    "origin": 1000000000,
                    "upstream_idle_connection": 1000000000,
                    "frontend_downstream": 1000000000,
                } if native_streaming else None),
            },
            "engine_order_by_scenario_and_repeat": [
                {"scenario": scenario, "repeat": rep,
                 "engines": list(engine_order(first_engine, rep))}
                for scenario in a.scenarios
                for rep in range(1, a.repeats + 1)
            ] if a.mode == "benchmark" else [],
            "binaries_sha256": {str(p): sha256(p) for p in (a.rut, a.converter, a.wrk)},
            "nginx_image": self.image,
            "nginx_image_id": inspection["Id"],
            "kernel": list(os.uname()),
            "cpu_topology": self.command(["lscpu"]).stdout,
            "workers": a.workers,
            "server_cpus": a.server_cpus,
            "tcp_tw_reuse": Path("/proc/sys/net/ipv4/tcp_tw_reuse").read_text().strip(),
            "note": "Harness revision is not proof of binary source revision. Record build provenance separately.",
        }
        if self.tls_context:
            metadata["tls_profile"] = {
                "certificate_sha256": sha256(a.tls_cert),
                "protocol": "TLSv1.3",
                "cipher": "TLS_AES_256_GCM_SHA384",
                "reconnect": "full-handshake",
                "key_exchange": "X25519 (enforced by load client)",
                "listener_adaptation": "native source listener stripped; CLI configures TLS; wildcard IPv4 on both frontends" if native_streaming else "converter cleartext listener replaced by CLI TLS; wildcard IPv4 on both frontends",
            }
        save_json(self.out / "environment.json", metadata)
        origin_observation = ""
        origin_log = ""
        if native_streaming:
            payloads = self.out / "payloads"
            payloads.mkdir()
            (payloads / "proxy").write_bytes(expected_body("proxy", native_streaming=True))
            origin_location = ('location / { root /benchmark-payloads; default_type application/octet-stream; '
                               'etag off; max_ranges 0; add_header Last-Modified ""; }')
            origin_observation = ('map $http_x_rut_benchmark_preflight $benchmark_preflight { '
                                  'default 0; ~.+ 1; }\n'
                                  'log_format rut_preflight "marker=$http_x_rut_benchmark_preflight '
                                  'connection=$connection requests=$connection_requests";\n')
            origin_log = 'access_log /dev/stdout rut_preflight if=$benchmark_preflight;'
        elif body_size is None:
            origin_location = 'location / { default_type text/plain; return 200 "' + "x" * 1024 + '"; }'
        else:
            payloads = self.out / "payloads"
            payloads.mkdir()
            (payloads / "proxy").write_bytes(expected_body("proxy", body_size))
            origin_location = ('location / { root /benchmark-payloads; default_type text/plain; '
                               'etag off; max_ranges 0; add_header Last-Modified ""; }')
            origin_observation = ""
            origin_log = ""
        if not native_streaming:
            origin_observation = ""
        origin_keepalive = "keepalive_timeout 60;" if native_streaming else "keepalive_timeout 0;"
        (self.out / "origin.conf").write_text(self.nginx_config(
            f"server {{ listen 127.0.0.1:{a.origin_port}; {origin_keepalive} "
            f"{'keepalive_requests 1000000000;' if native_streaming else ''} {origin_log} {origin_location} }}",
            extra_http=origin_observation, workers=1,
        ))
        works = sorted({scenario.split("-")[0] for scenario in a.scenarios})
        for work in works:
            if work == "static" and getattr(a, "static_profile", "converter-return") == "native-body":
                body = expected_body(work, body_size)
                payloads = self.out / "payloads"
                payloads.mkdir(exist_ok=True)
                (payloads / "static").write_bytes(body)
                listener = f"listen 127.0.0.1:{a.front_port}\n"
                native = listener + 'route GET "/static" { return response(200, body: "' + body.decode() + '") }\n'
                (self.out / "static.source.rut").write_text(native)
                (self.out / "static.rut").write_text(native[len(listener):] if self.tls_context else native)
                listen = f"listen 127.0.0.1:{a.front_port};"
                if self.tls_context:
                    listen = (f"listen {a.front_port} ssl; "
                              "ssl_certificate /benchmark-cert.pem; ssl_certificate_key /benchmark-key.pem; "
                              "ssl_protocols TLSv1.3; ssl_conf_command Ciphersuites TLS_AES_256_GCM_SHA384; "
                              "ssl_ecdh_curve X25519; ssl_session_cache off;")
                server = (f"server {{ {listen} keepalive_requests 1000000000; "
                          'location = /static { root /benchmark-payloads; sendfile on; '
                          'open_file_cache max=1 inactive=1h; open_file_cache_valid 1h; '
                          'open_file_cache_min_uses 1; '
                          'default_type "text/plain; charset=utf-8"; '
                          'etag off; max_ranges 0; add_header Last-Modified ""; } }')
                (self.out / "static-nginx.conf").write_text(self.nginx_config(server, workers=self.args.workers))
                continue
            if native_streaming:
                native = (f'listen 127.0.0.1:{a.front_port}\n'
                          f'upstream backend at "127.0.0.1:{a.origin_port}"\n'
                          'route GET "/proxy" { return forward(backend) }\n')
                (self.out / (work + ".source.rut")).write_text(native)
                runnable = native
                if self.tls_context:
                    listener = f"listen 127.0.0.1:{a.front_port}\n"
                    if not runnable.startswith(listener):
                        raise ValueError("unexpected native listener; cannot adapt TLS transport")
                    runnable = runnable[len(listener):]
                (self.out / (work + ".rut")).write_text(runnable)
                # Rut's native frontend is streamed; nginx must use matching
                # response streaming and origin idle reuse semantics.
                upstream_name = "benchmark_origin"
                nginx_server = (f'server {{ listen 127.0.0.1:{a.front_port}; keepalive_requests 1000000000; '
                                f'location = /proxy {{ proxy_pass http://{upstream_name}; '
                                'proxy_http_version 1.1; proxy_buffering off; proxy_buffer_size 16k; '
                                'proxy_busy_buffers_size 16k; '
                                'proxy_set_header Host $http_host; proxy_set_header Connection ""; } }')
                nginx_http = (f'upstream {upstream_name} {{ server 127.0.0.1:{a.origin_port}; '
                              'keepalive 4096; keepalive_timeout 60s; keepalive_requests 1000000000; }\n')
                if self.tls_context:
                    nginx_server = nginx_server.replace(
                        f"listen 127.0.0.1:{a.front_port};",
                        f"listen {a.front_port} ssl; ssl_certificate /benchmark-cert.pem; "
                        "ssl_certificate_key /benchmark-key.pem; ssl_protocols TLSv1.3; "
                        "ssl_conf_command Ciphersuites TLS_AES_256_GCM_SHA384; "
                        "ssl_ecdh_curve X25519; ssl_session_cache off;")
                (self.out / (work + "-nginx.conf")).write_text(
                    self.nginx_config(nginx_server, extra_http=nginx_http, workers=self.args.workers))
                continue
            local = (
                'location = /static { return 200 "' + expected_body("static", body_size).decode() + '"; }'
                if work == "static"
                else ""
            )
            fragment = (
                f"server {{ listen 127.0.0.1:{a.front_port}; {local} "
                f"location / {{ proxy_pass http://127.0.0.1:{a.origin_port}; }} }}\n"
            )
            source = self.out / (work + ".conf")
            source.write_text(fragment)
            nginx_fragment = fragment
            if work == "proxy" and body_size == 1024 * 1024:
                nginx_fragment = nginx_fragment.replace(
                    f"proxy_pass http://127.0.0.1:{a.origin_port};",
                    f"proxy_pass http://127.0.0.1:{a.origin_port}; "
                    "proxy_buffer_size 16k; proxy_buffers 8 16k; "
                    "proxy_busy_buffers_size 32k;",
                )
            if self.tls_context:
                nginx_fragment = nginx_fragment.replace(
                    f"listen 127.0.0.1:{a.front_port};",
                    f"listen {a.front_port} ssl; "
                    "ssl_certificate /benchmark-cert.pem; ssl_certificate_key /benchmark-key.pem; "
                    "ssl_protocols TLSv1.3; ssl_conf_command Ciphersuites TLS_AES_256_GCM_SHA384; "
                    "ssl_ecdh_curve X25519; ssl_session_cache off;",
                )
            (self.out / (work + "-nginx.conf")).write_text(self.nginx_config(nginx_fragment, workers=self.args.workers))
            converted = self.command([a.converter, "--format", "server", source])
            program = converted.stdout
            if self.tls_context:
                # Source listeners currently describe cleartext only. Preserve
                # converter stdout, then select the existing CLI TLS listener.
                (self.out / (work + ".converted.rut")).write_text(program)
                listener = f"listen 127.0.0.1:{a.front_port}\n"
                if not program.startswith(listener):
                    raise ValueError("unexpected converter listener; cannot adapt TLS transport")
                program = program[len(listener):]
            (self.out / (work + ".rut")).write_text(program)
            (self.out / (work + "-converter.log")).write_text(converted.stderr)

    @staticmethod
    def nginx_config(server, extra_http="", workers=1):
        return (
            f"worker_processes {workers};\nerror_log /dev/stderr warn;\npid /tmp/nginx.pid;\n"
            "events { worker_connections 8192; }\nhttp { access_log off;\n"
            + extra_http + server
            + "\n}\n"
        )

    def ready(self, port, pid):
        for _ in range(100):
            if not Path(f"/proc/{pid}").exists():
                raise RuntimeError("server exited before readiness")
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.1):
                    return
            except OSError:
                time.sleep(0.1)
        raise RuntimeError(f"listener {port} did not become ready")

    @staticmethod
    def rut_shards_ready(log, pid, workers):
        # The binary under test clamps --shards to its own kMaxShards, so trust
        # its startup report rather than the checkout's source constant.
        pattern = re.compile(rb"^Listening on port \d+ with (\d+) shard\(s\)$", re.M)
        for _ in range(100):
            match = pattern.search(log.read_bytes())
            if match:
                if int(match[1]) != workers:
                    raise RuntimeError(
                        f"RUT started {int(match[1])} shard(s), expected {workers}")
                return
            if not Path(f"/proc/{pid}").exists():
                raise RuntimeError("RUT exited before reporting its shard count")
            time.sleep(0.1)
        raise RuntimeError("RUT did not report its shard count")

    @contextlib.contextmanager
    def nginx(self, name, config, cpu, port):
        # Capture the ID before start/inspect/readiness so failures still clean up.
        cid = self.command(
            [
                "docker",
                "create",
                "--pull=never",
                "--name",
                self.prefix + "-" + name,
                "--network",
                "host",
                "--cpuset-cpus",
                cpu,
                "--ulimit",
                "nofile=65536:65536",
                "--mount",
                f"type=bind,src={self.out / config},dst=/etc/nginx/nginx.conf,readonly",
                *(["--mount", f"type=bind,src={self.out / 'payloads'},dst=/benchmark-payloads,readonly"]
                  if (self.out / "payloads").exists() else []),
                *(["--mount", f"type=bind,src={self.args.tls_cert},dst=/benchmark-cert.pem,readonly",
                   "--mount", f"type=bind,src={self.args.tls_key},dst=/benchmark-key.pem,readonly"]
                  if self.tls_context else []),
                self.image,
                "nginx",
                "-g",
                "daemon off;",
            ]
        ).stdout.strip()
        if name == "origin":
            self.origin_container_id = cid
        try:
            self.command(["docker", "start", cid])
            pid = int(
                self.command(["docker", "inspect", "-f", "{{.State.Pid}}", cid]).stdout
            )
            self.ready(port, pid)
            yield pid
        finally:
            try:
                self.command(["docker", "stop", "-t", "2", cid])
            finally:
                try:
                    logs = self.command(["docker", "logs", cid])
                    (self.out / (name + "-server.stdout.log")).write_text(logs.stdout)
                    (self.out / (name + "-server.stderr.log")).write_text(logs.stderr)
                    (self.out / (name + "-server.log")).write_text(
                        logs.stdout + logs.stderr
                    )
                finally:
                    self.command(["docker", "rm", "-f", cid])

    @contextlib.contextmanager
    def frontend(self, engine, work, label):
        a = self.args
        self.active_label = label
        if engine == "nginx":
            with self.nginx(
                label, work + "-nginx.conf", a.server_cpus, a.front_port
            ) as pid:
                yield pid
            return
        argv = [
            "taskset",
            "-c",
            a.server_cpus,
            str(a.rut),
            str(self.out / (work + ".rut")),
            "--shards",
            str(a.workers),
            "--no-pin",
            "--drain",
            "1",
            "--opt",
            "2",
        ]
        if self.tls_context:
            argv += [str(a.front_port), "--tls-cert", str(a.tls_cert), "--tls-key", str(a.tls_key)]
        self.commands.append(argv)
        save_json(self.out / "commands.json", self.commands)
        server_log = self.out / (label + "-server.log")
        with server_log.open("w") as log:
            proc = subprocess.Popen(argv, stdout=log, stderr=log)
        try:
            self.ready(a.front_port, proc.pid)
            self.rut_shards_ready(server_log, proc.pid, a.workers)
            yield proc.pid
            if proc.poll() is not None:
                raise RuntimeError(f"RUT exited unexpectedly: {proc.returncode}")
        finally:
            if proc.poll() is None:
                proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)

    def validate(self, work, keepalive):
        native_streaming = getattr(self.args, "proxy_profile", "converter-strict") == "native-streaming"
        if native_streaming:
            self.validate_native_keepalive(work)
            return
        requests = preflight_request_count(len(expected_body(work, getattr(self.args, "body_size", None))))
        save_json(self.out / f"{self.active_label}-preflight.json", {
            "requests_per_connection_mode": requests, "full_body_comparison": True,
            "connection_modes": ["close", "keepalive"] if keepalive else ["close"],
        })
        for close in [True, False] if keepalive else [True]:
            sock = None
            try:
                for _ in range(requests):
                    if sock is None:
                        sock = socket.create_connection(
                            ("127.0.0.1", self.args.front_port), timeout=3
                        )
                        if self.tls_context:
                            sock = self.tls_context.wrap_socket(sock, server_hostname="localhost")
                            if sock.version() != "TLSv1.3" or sock.cipher()[0] != "TLS_AES_256_GCM_SHA384" or sock.session_reused:
                                raise ValueError("unexpected TLS protocol/cipher/session reuse")
                            save_json(self.out / f"{self.active_label}-tls.json", {
                                "version": sock.version(), "cipher": sock.cipher(),
                                "alpn": sock.selected_alpn_protocol(), "session_reused": sock.session_reused,
                            })
                    raw, server_close = response(
                        sock, work, close, self.args.keepalive_header,
                        getattr(self.args, "body_size", None),
                        False,
                        None,
                    )
                    comparison = canonical_native_static_response(raw) if (
                        work == "static" and getattr(self.args, "static_profile", "converter-return") == "native-body"
                    ) else raw
                    key = (work, close)
                    if key in self.references and self.references[key] != comparison:
                        raise ValueError(f"response mismatch for {key}")
                    self.references[key] = comparison
                    (
                        self.out
                        / f"{work}-{'close' if close else 'keepalive'}-response.txt"
                    ).write_bytes(raw)
                    if close or server_close:
                        sock.close()
                        sock = None
                        if not close:
                            raise ValueError(
                                f"keepalive preflight closed before {requests} requests"
                            )
            finally:
                if sock is not None:
                    sock.close()

    def validate_native_keepalive(self, work):
        sock = None
        try:
            sock = self.open_preflight_socket()
            slow_markers = [f"{self.active_label}-slow-{i}" for i in range(2)]
            self.slow_read_response(sock, work, slow_markers[0])
            raw, server_close = response(
                sock, work, False, "implicit", NATIVE_BODY_SIZE, True, slow_markers[1]
            )
            if server_close:
                raise ValueError("native slow-read preflight closed before successor response")
            self.save_native_response("slow-successor", raw)
            self.verify_origin_reuse(slow_markers)

            markers = [f"{self.active_label}-keepalive-{i}" for i in range(100)]
            request_evidence = []
            for index, marker in enumerate(markers):
                raw, server_close = response(
                    sock, work, False, "implicit", NATIVE_BODY_SIZE, True, marker
                )
                if server_close:
                    raise ValueError("native keepalive preflight closed before 100 responses")
                head, body = raw.split(b"\r\n\r\n", 1)
                request_evidence.append({
                    "marker": marker,
                    "response_sha256": hashlib.sha256(raw).hexdigest(),
                    "body_sha256": hashlib.sha256(body).hexdigest(),
                    "body_bytes": len(body),
                    "status_line": head.split(b"\r\n", 1)[0].decode("ascii"),
                })
                if index == 0:
                    self.save_native_response("keepalive-representative", raw)
            save_json(self.out / f"{self.active_label}-keepalive-responses.json", request_evidence)
            self.verify_origin_reuse(markers)
        finally:
            if sock is not None:
                sock.close()

    def open_preflight_socket(self):
        sock = socket.create_connection(("127.0.0.1", self.args.front_port), timeout=3)
        if self.tls_context:
            sock = self.tls_context.wrap_socket(sock, server_hostname="localhost")
            if (sock.version() != "TLSv1.3" or sock.cipher()[0] != "TLS_AES_256_GCM_SHA384"
                    or sock.session_reused):
                raise ValueError("unexpected TLS protocol/cipher/session reuse")
            save_json(self.out / f"{self.active_label}-tls.json", {
                "version": sock.version(), "cipher": sock.cipher(),
                "alpn": sock.selected_alpn_protocol(), "session_reused": sock.session_reused,
            })
        return sock

    def save_native_response(self, label, raw):
        path = self.out / f"{self.active_label}-{label}-response.bin"
        path.write_bytes(raw)

    def slow_read_response(self, sock, work, marker):
        started = time.monotonic()
        data = b""
        head = b""
        body = b""
        events = []
        declared_body_bytes = None
        try:
            sock.sendall(request_bytes(work, False, "implicit", marker))
            started = time.monotonic()
            while b"\r\n\r\n" not in data:
                chunk = sock.recv(4096)
                if not chunk:
                    events.append({"phase": "header", "bytes": 0, "elapsed_seconds": time.monotonic() - started})
                    raise ValueError("EOF before slow-read response header")
                data += chunk
                events.append({"phase": "header", "bytes": len(chunk), "elapsed_seconds": time.monotonic() - started})
                if len(data) > 8192:
                    raise ValueError("oversized slow-read response header")
            head, body = data.split(b"\r\n\r\n", 1)
            if body:
                events.append({"phase": "body-prefetch", "bytes": len(body), "elapsed_seconds": time.monotonic() - started})
            wanted = expected_body(work, native_streaming=True)
            length, server_close = response_head(head, len(wanted), native_streaming=True)
            declared_body_bytes = length
            if length != NATIVE_BODY_SIZE or server_close:
                raise ValueError("slow-read response has invalid length or closes keepalive")
            time.sleep(0.2)
            while len(body) < length:
                chunk = sock.recv(min(4096, length - len(body)))
                if not chunk:
                    events.append({"phase": "body", "bytes": 0, "elapsed_seconds": time.monotonic() - started})
                    raise ValueError("EOF during slow-read response body")
                body += chunk
                events.append({"phase": "body", "bytes": len(chunk), "elapsed_seconds": time.monotonic() - started})
                time.sleep(0.005)
            if len(body) != length or body != wanted:
                raise ValueError("slow-read response body mismatch")
            raw = head + b"\r\n\r\n" + body
            self.save_native_response("slow-read", raw)
            save_json(self.out / f"{self.active_label}-slow-read.json", {
                "preflight_marker": marker, "body_bytes": len(body),
                "header_delay_seconds": next(
                    (event["elapsed_seconds"] for event in events if event["phase"] in ("body-prefetch", "body")),
                    time.monotonic() - started,
                ),
                "read_events": events, "completed": True,
            })
        except Exception as error:
            received = data if b"\r\n\r\n" not in data else head + b"\r\n\r\n" + body
            self.save_slow_read_failure(marker, started, head, body, received,
                                        declared_body_bytes, events, error)
            raise

    def save_slow_read_failure(self, marker, started, head, body, received,
                               declared_body_bytes, events, error):
        raw_path = self.out / f"{self.active_label}-slow-read-failure-response.bin"
        metadata_path = self.out / f"{self.active_label}-slow-read-failure.json"
        try:
            raw_path.write_bytes(received)
            save_json(metadata_path, {
                "preflight_marker": marker,
                "exception_category": type(error).__name__,
                "exception": repr(error),
                "elapsed_seconds": time.monotonic() - started,
                "expected_body_bytes": NATIVE_BODY_SIZE,
                "declared_response_body_bytes": declared_body_bytes,
                "received_body_bytes": len(body),
                "received_wire_bytes": len(received),
                "response_head_bytes": len(head),
                "response_head_complete": bool(head),
                "read_events": events,
                "completed": False,
            })
        except OSError:
            # Preserve the original preflight failure if evidence storage fails.
            pass

    def verify_origin_reuse(self, expected_markers):
        logs = self.command(["docker", "logs", getattr(self, "origin_container_id", "")]).stdout
        marker_prefix = expected_markers[0].rsplit("-", 1)[0]
        (self.out / f"{marker_prefix}-origin-reuse.log").write_text(logs)
        records = origin_reuse_records(logs, expected_markers)
        if not valid_origin_reuse(records, expected_markers):
            raise ValueError(f"origin reuse preflight failed for markers {expected_markers!r}: got {records!r}")

    def wrk(self, work, close, concurrency, duration, label):
        a = self.args
        mode = connection_header(close, a.keepalive_header)
        lua = self.out / (label + ".lua")
        lua.write_text(
            f'wrk.method="GET"\nwrk.path="/{work}"\nwrk.headers["Host"]="client.example"\n'
            + (
                f'wrk.headers["Connection"]="{mode}"\n'
                if mode
                else 'wrk.headers["Connection"]=nil\n'
            )
            + 'done=function(s,l,r)\n print(string.format("METRICS %.0f %.0f %.0f %.0f %.0f %d %d %d %d %d",'
            "s.requests,s.duration,l:percentile(50),l:percentile(95),l:percentile(99),"
            "s.errors.connect,s.errors.read,s.errors.write,s.errors.status,s.errors.timeout))\nend\n"
        )
        cpu_file = self.out / (label + ".cpu")
        argv = [
            "/usr/bin/time",
            "-f",
            "%U %S",
            "-o",
            cpu_file,
            "taskset",
            "-c",
            a.client_cpus,
            a.wrk,
            f"-t{min(concurrency, len(a.client_cpus.split(',')))}",
            f"-c{concurrency}",
            f"-d{duration}s",
            "--latency",
            "--timeout",
            "2s",
            "-s",
            lua,
            f"{'https' if self.tls_context else 'http'}://127.0.0.1:{a.front_port}/{work}",
        ]
        result = self.command(argv, timeout=duration + 15)
        (self.out / (label + ".log")).write_text(result.stdout + result.stderr)
        if self.tls_context and "TLS_PROFILE TLSv1.3 TLS_AES_256_GCM_SHA384 X25519 full-handshake" not in result.stdout:
            raise ValueError("HTTPS requires the checked wrk-tls-full-handshake.patch client")
        match = re.search(r"^METRICS (.+)$", result.stdout, re.MULTILINE)
        if not match:
            raise ValueError(f"missing wrk metrics: {label}")
        values = [float(v) for v in match[1].split()]
        if len(values) != 10 or values[1] <= 0:
            raise ValueError("invalid wrk metrics")
        return {
            "requests": int(values[0]),
            "seconds": values[1] / 1e6,
            "rps": values[0] / (values[1] / 1e6),
            "p50_us": values[2],
            "p95_us": values[3],
            "p99_us": values[4],
            "errors": dict(zip(ERROR_NAMES, map(int, values[5:]))),
            "client_cpu_seconds": sum(map(float, cpu_file.read_text().split())),
        }

    def benchmark(self, origin_pid):
        first_engine = getattr(self.args, "first_engine", "nginx")
        for scenario in self.args.scenarios:
            work, mode = scenario.split("-")
            for rep in range(1, self.args.repeats + 1):
                for engine in engine_order(first_engine, rep):
                    label = f"{scenario}-{engine}-r{rep}"
                    with self.frontend(engine, work, label) as pid:
                        self.validate(work, mode == "keepalive")
                        print(label, "response preflight PASS", flush=True)
                        for concurrency in self.args.concurrency:
                            tag = label + f"-c{concurrency}"
                            warmup = self.wrk(
                                work,
                                mode == "close",
                                concurrency,
                                self.args.warmup,
                                tag + "-warmup",
                            )
                            before, _ = proc_usage(pid)
                            origin_before, _ = proc_usage(origin_pid)
                            result = self.wrk(
                                work,
                                mode == "close",
                                concurrency,
                                self.args.duration,
                                tag,
                            )
                            after, rss = proc_usage(pid)
                            origin_after, _ = proc_usage(origin_pid)
                            result.update(
                                workload=work,
                                proxy_profile=getattr(self.args, "proxy_profile", "converter-strict"),
                                static_profile=getattr(self.args, "static_profile", "converter-return"),
                                transport="https" if self.tls_context else "http",
                                body_size=len(expected_body(work, getattr(self.args, "body_size", None))),
                                connection=mode,
                                engine=engine,
                                rep=rep,
                                concurrency=concurrency,
                                workers=self.args.workers,
                                server_cpus=self.args.server_cpus,
                                warmup_errors=warmup["errors"],
                                server_cpu_pct=100
                                * (after - before)
                                / result["seconds"],
                                origin_cpu_pct=100
                                * (origin_after - origin_before)
                                / result["seconds"],
                                server_rss_bytes=rss,
                                valid=bool(result["requests"])
                                and not any(result["errors"].values())
                                and bool(warmup["requests"])
                                and not any(warmup["errors"].values()),
                            )
                            self.results.append(result)
                            save_json(self.out / "results.json", self.results)
                            print(json.dumps(result), flush=True)
        return all(r["valid"] for r in self.results)

    async def independent(self, work, close):
        counts = collections.Counter()
        examples = []
        deadline = time.monotonic() + self.args.duration

        async def worker():
            reader = writer = None

            async def disconnect():
                nonlocal writer
                if writer:
                    writer.close()
                    try:
                        await asyncio.wait_for(writer.wait_closed(), 3)
                    except (OSError, asyncio.TimeoutError):
                        pass
                    writer = None

            try:
                while time.monotonic() < deadline:
                    try:
                        if writer is None:
                            reader, writer = await asyncio.wait_for(
                                asyncio.open_connection(
                                    "127.0.0.1", self.args.front_port,
                                    ssl=self.tls_context,
                                    server_hostname="localhost" if self.tls_context else None,
                                ),
                                3,
                            )
                        writer.write(
                            request_bytes(work, close, self.args.keepalive_header)
                        )
                        await asyncio.wait_for(writer.drain(), 3)
                        head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 3)
                        wanted = expected_body(work, getattr(self.args, "body_size", None))
                        length, server_close = response_head(head, len(wanted))
                        body = await asyncio.wait_for(reader.readexactly(length), 3)
                        if body != wanted:
                            raise ValueError("unexpected response body")
                        if close or server_close:
                            if await asyncio.wait_for(reader.read(1), 3) != b"":
                                raise ValueError("expected EOF after response")
                            await disconnect()
                        counts["correct_responses"] += 1
                    except (
                        OSError,
                        ValueError,
                        asyncio.IncompleteReadError,
                        asyncio.LimitOverrunError,
                        asyncio.TimeoutError,
                    ) as error:
                        counts[type(error).__name__] += 1
                        if len(examples) < 5:
                            examples.append(repr(error))
                        await disconnect()
            finally:
                await disconnect()

        await asyncio.gather(*(worker() for _ in range(self.args.concurrency[0])))
        return {"counts": dict(counts), "examples": examples}

    def diagnose(self):
        for scenario in self.args.scenarios:
            work, mode = scenario.split("-")
            for engine in ("nginx", "rut"):
                label = f"diagnose-{scenario}-{engine}"
                with self.frontend(engine, work, label):
                    self.validate(work, mode == "keepalive")
                    load = self.wrk(
                        work,
                        mode == "close",
                        self.args.concurrency[0],
                        self.args.warmup,
                        label,
                    )
                    original_affinity = os.sched_getaffinity(0)
                    try:
                        os.sched_setaffinity(
                            0, set(map(int, self.args.client_cpus.split(",")))
                        )
                        result = asyncio.run(self.independent(work, mode == "close"))
                    finally:
                        os.sched_setaffinity(0, original_affinity)
                    result.update(scenario=scenario, engine=engine, prior_wrk=load)
                    result["valid"] = (
                        bool(result["counts"].get("correct_responses"))
                        and not any(
                            v
                            for k, v in result["counts"].items()
                            if k != "correct_responses"
                        )
                        and bool(load["requests"])
                        and not any(load["errors"].values())
                    )
                    self.results.append(result)
                    save_json(self.out / "diagnostics.json", self.results)
                    print(label, json.dumps(result), flush=True)
        return all(r["valid"] for r in self.results)


def positive(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return number


def origin_reuse_records(logs, expected_markers):
    expected = set(expected_markers)
    records = []
    for line in logs.splitlines():
        match = re.fullmatch(r'marker=(\S+) connection=(\d+) requests=(\d+)', line.strip())
        if match and match[1] in expected:
            records.append((match[1], int(match[2]), int(match[3])))
    return records


def valid_origin_reuse(records, expected_markers):
    if [record[0] for record in records] != list(expected_markers):
        return False
    if not records or any(connection <= 0 or requests <= 0 for _, connection, requests in records):
        return False
    connection = records[0][1]
    first_request = records[0][2]
    return all(
        record[1] == connection and record[2] == first_request + index
        for index, record in enumerate(records)
    )


def validate_proxy_profile(parser, args):
    if args.proxy_profile != "native-streaming":
        return
    if args.body_size not in (None, NATIVE_BODY_SIZE):
        parser.error("native-streaming requires a 256 KiB response")
    if args.scenarios != ["proxy-keepalive"]:
        parser.error("native-streaming supports only proxy-keepalive")
    if not args.concurrency or any(value not in (1, 32) for value in args.concurrency):
        parser.error("native-streaming supports only concurrency values 1 and 32")
    if args.keepalive_header != "implicit":
        parser.error("native-streaming requires --keepalive-header implicit")
    args.body_size = NATIVE_BODY_SIZE


def add_measurement_arguments(parser, full_duration):
    parser.add_argument(
        "--profile", choices=("acceptance", "quick", "full"), default="acceptance",
        help="acceptance (default): 1s warmup, 5s measurement, 3 repeats; quick: smoke only; full: original sampling budget",
    )
    parser.add_argument("--duration", type=positive, help=f"measurement seconds (full: {full_duration}); overrides profile")
    parser.add_argument("--warmup", type=positive, help="warmup seconds (full: 2); overrides profile")
    parser.add_argument("--repeats", type=positive, help="repeats (full: 3); overrides profile")
    parser.set_defaults(full_duration=full_duration)


def resolve_measurement_arguments(args):
    defaults = {"acceptance": (5, 1, 3), "quick": (2, 1, 1),
                "full": (args.full_duration, 2, 3)}[args.profile]
    for name, value in zip(("duration", "warmup", "repeats"), defaults):
        if getattr(args, name) is None:
            setattr(args, name, value)
    del args.full_duration


def print_measurement_budget(args, cells):
    repeats = args.repeats if getattr(args, "mode", "benchmark") == "benchmark" else 1
    seconds = cells * 2 * repeats * (args.warmup + args.duration)
    print(f"{args.profile} profile: {cells} cells, {repeats} repeat(s), "
          f"{args.warmup}s warmup + {args.duration}s measurement per engine; "
          f"load budget {seconds}s ({seconds / 60:.1f} min), plus startup/validation/cleanup",
          flush=True)


def add_cpu_arguments(parser):
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--server-cpu", type=int, help="legacy single server CPU")
    group.add_argument("--server-cpus", help="comma-separated server CPU mask")
    parser.add_argument("--workers", type=positive, default=1,
                        help="frontend worker/shard count; must match --server-cpus")
    parser.add_argument("--origin-cpu", type=int, required=True)
    parser.add_argument("--client-cpus", required=True,
                        help="comma-separated CPU IDs on distinct physical cores")


def normalize_cpu_arguments(parser, args):
    """Canonicalize the worker mask; the Rut shard cap is checked at startup."""
    if type(args.workers) is not int or args.workers < 1:
        parser.error("workers must be a positive integer")
    try:
        server_cpus = ([args.server_cpu] if args.server_cpu is not None else
                       [int(cpu) for cpu in args.server_cpus.split(",")])
    except (AttributeError, ValueError):
        parser.error("server-cpus must be comma-separated integer CPU IDs")
    if not server_cpus or len(set(server_cpus)) != len(server_cpus):
        parser.error("server-cpus must contain unique CPU IDs")
    if args.server_cpu is not None and args.workers != 1:
        parser.error("--workers greater than one requires --server-cpus")
    if args.workers != len(server_cpus):
        parser.error("workers must equal the number of server CPUs")
    args.server_cpus = ",".join(map(str, server_cpus))
    args.server_cpu = server_cpus[0]
    return args


def validate_cpu_topology(parser, args):
    try:
        clients = [int(cpu) for cpu in args.client_cpus.split(",")]
    except (AttributeError, ValueError):
        parser.error("client-cpus must be comma-separated integer CPU IDs")
    cpus = [*map(int, args.server_cpus.split(",")), args.origin_cpu, *clients]
    if (not clients or len(set(cpus)) != len(cpus)
            or not set(cpus) <= os.sched_getaffinity(0)):
        parser.error("CPU IDs must be available and disjoint")
    cores = []
    try:
        for cpu in cpus:
            topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
            cores.append(((topology / "physical_package_id").read_text(),
                          (topology / "core_id").read_text()))
    except OSError as error:
        parser.error(f"cannot read CPU topology: {error}")
    if len(set(cores)) != len(cores):
        parser.error("choose distinct physical cores, not SMT siblings")
    args.client_cpus = ",".join(map(str, clients))
    return args


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rut", type=Path, required=True)
    parser.add_argument("--converter", type=Path, required=True)
    parser.add_argument("--wrk", type=Path, required=True)
    parser.add_argument(
        "--output", type=Path, required=True, help="new or empty directory; no resume"
    )
    parser.add_argument(
        "--mode", choices=("benchmark", "diagnose"), default="benchmark"
    )
    add_cpu_arguments(parser)
    parser.add_argument(
        "--keepalive-header",
        choices=("explicit", "implicit"),
        default="explicit",
        help="explicit preserves the original workload; implicit uses HTTP/1.1 default persistence",
    )
    parser.add_argument("--body-size", type=positive, help="exact response body bytes (max 1 MiB); omitted preserves legacy bodies")
    parser.add_argument("--static-profile", choices=("converter-return", "native-body"),
                        default="converter-return", help="native-body compares a pinned Rut body with an nginx static file; separate from converter acceptance")
    parser.add_argument("--proxy-profile", choices=("converter-strict", "native-streaming"),
                        default="converter-strict", help="proxy implementation profile; default preserves converter behavior")
    parser.add_argument("--tls-cert", type=Path, help="PEM certificate with localhost SAN; enables HTTPS")
    parser.add_argument("--tls-key", type=Path)
    parser.add_argument("--front-port", type=int, default=8087)
    parser.add_argument("--origin-port", type=int, default=9087)
    parser.add_argument("--concurrency", nargs="+", type=positive, default=[1, 32, 128])
    add_measurement_arguments(parser, full_duration=8)
    add_first_engine_argument(parser)
    parser.add_argument(
        "--scenarios", nargs="+", choices=SCENARIOS, default=list(SCENARIOS)
    )
    args = parser.parse_args()
    resolve_measurement_arguments(args)
    if args.body_size is not None and args.body_size > 1048576:
        parser.error("body-size must be <= 1048576")
    validate_proxy_profile(parser, args)
    if bool(args.tls_cert) != bool(args.tls_key):
        parser.error("tls-cert and tls-key must be supplied together")
    if args.tls_cert:
        args.tls_cert = args.tls_cert.resolve()
        args.tls_key = args.tls_key.resolve()
        if not args.tls_cert.is_file() or not args.tls_key.is_file():
            parser.error("TLS certificate and key must exist")
    if args.mode == "diagnose" and len(args.concurrency) != 1:
        parser.error("diagnose requires one --concurrency value")
    if args.mode == "diagnose" and args.proxy_profile == "native-streaming":
        parser.error("diagnose mode does not support native-streaming response validation")
    if len(set(args.concurrency)) != len(args.concurrency) or len(
        set(args.scenarios)
    ) != len(args.scenarios):
        parser.error("duplicate concurrency or scenario")
    for attr in ("rut", "converter", "wrk"):
        path = getattr(args, attr).resolve()
        if not path.is_file() or not os.access(path, os.X_OK):
            parser.error(f"{attr} must name an executable file")
        setattr(args, attr, path)
    args.output = args.output.resolve()
    if args.output.exists() and (
        not args.output.is_dir() or any(args.output.iterdir())
    ):
        parser.error(
            "output must be new or empty; existing evidence is never overwritten"
        )
    normalize_cpu_arguments(parser, args)
    validate_cpu_topology(parser, args)
    if args.front_port == args.origin_port or any(
        not 1024 <= p <= 9999 for p in (args.front_port, args.origin_port)
    ):
        parser.error("ports must be distinct unprivileged four-digit ports")
    for port in (args.front_port, args.origin_port):
        try:
            with socket.socket() as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("127.0.0.1", port))
        except OSError as error:
            parser.error(f"port {port} unavailable: {error}")
    for tool in ("docker", "taskset", "lscpu", "git", "/usr/bin/time"):
        if not shutil.which(tool):
            parser.error(f"required tool missing: {tool}")
    args.output.mkdir(parents=True, exist_ok=True)
    return args


def main():
    args = arguments()
    status = {"complete": False, "valid": False}

    def interrupt(_signum, _frame):
        raise KeyboardInterrupt

    previous_sigterm = signal.signal(signal.SIGTERM, interrupt)
    try:
        harness = Harness(args)
        print_measurement_budget(args, len(args.scenarios) * len(args.concurrency))
        harness.prepare()
        with harness.nginx(
            "origin", "origin.conf", args.origin_cpu, args.origin_port
        ) as origin_pid:
            valid = (
                harness.benchmark(origin_pid)
                if args.mode == "benchmark"
                else harness.diagnose()
            )
        status.update(complete=True, valid=valid)
        return 0 if valid else 1
    except (Exception, KeyboardInterrupt) as error:  # noqa: BLE001 - persist incomplete evidence on any failure
        status["error"] = repr(error)
        print(repr(error), file=sys.stderr)
        return 2
    finally:
        signal.signal(signal.SIGTERM, previous_sigterm)
        save_json(args.output / "status.json", status)


if __name__ == "__main__":
    sys.exit(main())
