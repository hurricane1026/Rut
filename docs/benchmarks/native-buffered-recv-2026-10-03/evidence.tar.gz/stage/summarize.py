#!/usr/bin/env python3
import json,statistics,sys
from pathlib import Path
stage=Path(__file__).resolve().parent
label=sys.argv[1] if len(sys.argv)>1 else 'primary'
plan=json.loads((stage/f'{label}-plan.json').read_text())
rows=[]
for e in plan:
 out=Path(e['output'])
 status=json.loads((out/'status.json').read_text())
 if status != {'complete':True,'valid':True}: raise ValueError(status)
 samples=json.loads((out/'results.json').read_text())
 for r in samples:
  if not r['valid'] or any(r['errors'].values()) or any(r['warmup_errors'].values()): raise ValueError(r)
  r.update(control_index=e['index'],variant=e['variant'])
 rows+=samples
summary=[]
for c,mode in sorted({(r['concurrency'],r['connection']) for r in rows}):
 groups=[]
 for i in range(4):
  engines={}
  for eng in ['rut','nginx']:
   rs=[r for r in rows if r['concurrency']==c and r['connection']==mode and r['control_index']==i and r['engine']==eng]
   if len(rs)!=3: raise ValueError((i,c,mode,eng,len(rs)))
   engines[eng]={k:statistics.median(r[k] for r in rs) for k in ['rps','p99_us','server_cpu_pct','server_rss_bytes']}
   engines[eng]['cpu_us_per_request']=statistics.median(r['server_cpu_pct']/100/r['rps']*1e6 for r in rs)
  groups.append(engines)
 changes=[]
 for b,k in [(0,1),(3,2)]:
  changes.append({'rps_pct':(groups[k]['rut']['rps']/groups[b]['rut']['rps']-1)*100,'normalized_rps_pct':((groups[k]['rut']['rps']/groups[k]['nginx']['rps'])/(groups[b]['rut']['rps']/groups[b]['nginx']['rps'])-1)*100,'p99_pct':(groups[k]['rut']['p99_us']/groups[b]['rut']['p99_us']-1)*100,'cpu_per_request_pct':(groups[k]['rut']['cpu_us_per_request']/groups[b]['rut']['cpu_us_per_request']-1)*100})
 summary.append(dict(concurrency=c,connection=mode,groups=groups,changes=changes))
(stage/f'{label}-all-results.json').write_text(json.dumps(rows,indent=2)+'\n')
(stage/f'{label}-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
