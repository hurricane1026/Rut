#!/usr/bin/env python3
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/hurricane/private/code/Rut')
STAGE=Path(__file__).resolve().parent
WRK=Path('/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk')
p=argparse.ArgumentParser()
p.add_argument('--body',type=int,default=1048576)
p.add_argument('--concurrency',nargs='+',default=['32'])
p.add_argument('--label',default='primary')
p.add_argument('--tls-cert',type=Path)
p.add_argument('--tls-key',type=Path)
a=p.parse_args()
if bool(a.tls_cert) != bool(a.tls_key):
 p.error('--tls-cert and --tls-key must be supplied together')
plan=[]
for i,variant in enumerate(['baseline','candidate','candidate','baseline']):
 out=STAGE/f'{a.label}-{i}-{variant}'
 cmd=[sys.executable,str(ROOT/'scripts/nginx_benchmark/run.py'),'--rut',str(STAGE/variant/'rut'),'--converter',str(STAGE/variant/'rut-nginx-convert'),'--wrk',str(WRK),'--output',str(out),'--server-cpu','2','--origin-cpu','3','--client-cpus','4,5','--keepalive-header','implicit','--body-size',str(a.body),'--concurrency',*a.concurrency,'--scenarios','proxy-close','proxy-keepalive','--warmup','1','--duration','5','--repeats','3','--first-engine','nginx' if i%2==0 else 'rut']
 if a.tls_cert:
  cmd.extend(['--tls-cert',str(a.tls_cert),'--tls-key',str(a.tls_key)])
 plan.append(dict(index=i,variant=variant,command=cmd,output=str(out)))
(STAGE/f'{a.label}-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
status=[]
for entry in plan:
 print(entry['index'],entry['variant'],flush=True)
 with (STAGE/f"{a.label}-{entry['index']}.log").open('w') as log:
  result=subprocess.run(entry['command'],stdout=log,stderr=subprocess.STDOUT)
 status.append(dict(index=entry['index'],returncode=result.returncode))
 (STAGE/f'{a.label}-status.json').write_text(json.dumps(status,indent=2)+'\n')
 if result.returncode: sys.exit(result.returncode)
