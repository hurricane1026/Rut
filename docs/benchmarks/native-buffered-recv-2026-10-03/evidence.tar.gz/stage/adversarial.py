#!/usr/bin/env python3
"""Staged Content-Length atomicity probe for the Rut baseline/candidate binaries.

The origin sends a 1 MiB response in 32 KiB pieces, stopping after byte N-1.
The client proves that the proxy has published no response bytes, then releases
the origin to send either the exact final byte or that byte plus one surplus
byte. The exact/surplus/exact sequence runs three times in one Rut process.
Only the Python standard library is used.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import select
import signal
import socket
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from queue import Empty, Queue


STAGE = Path(__file__).resolve().parent
SMOKE = STAGE / "candidate-smoke"
BODY_SIZE = 1 << 20
BODY_CHUNK = 32 * 1024
BODY_BYTE = b"R"
SEGMENT_DELAY = 0.002
SEQUENCE = ("exact", "surplus", "exact") * 3


class ProbeError(RuntimeError):
    pass


class PrefixGate:
    def __init__(self, case: str) -> None:
        self.case = case
        self.release = threading.Event()
        self.done = threading.Event()
        self.ready_at: float | None = None


class FragmentedOrigin:
    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind((host, port))
        self.listener.listen(32)
        self.listener.settimeout(0.2)
        self.stop = threading.Event()
        self.gates: Queue[PrefixGate] = Queue()
        self.errors: Queue[str] = Queue()
        self.threads: list[threading.Thread] = []
        self.thread = threading.Thread(target=self._accept_loop, name="adversarial-origin")
        self.thread.start()

    def _read_request(self, conn: socket.socket) -> bytes:
        data = bytearray()
        while b"\r\n\r\n" not in data:
            part = conn.recv(4096)
            if not part:
                raise ProbeError("proxy closed before completing its upstream request")
            data.extend(part)
            if len(data) > 64 * 1024:
                raise ProbeError("upstream request headers exceeded 64 KiB")
        return bytes(data)

    def _serve(self, conn: socket.socket) -> None:
        gate: PrefixGate | None = None
        try:
            conn.settimeout(10.0)
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self._read_request(conn)
            header = (
                b"HTTP/1.1 200 OK\r\n"
                b"Content-Type: application/octet-stream\r\n"
                + f"Content-Length: {BODY_SIZE}\r\n".encode("ascii")
                + b"Connection: close\r\n\r\n"
            )
            conn.sendall(header)
            time.sleep(0.030)
            left = BODY_SIZE - 1
            chunk = BODY_BYTE * BODY_CHUNK
            while left:
                take = min(left, len(chunk))
                conn.sendall(chunk[:take])
                left -= take
                time.sleep(SEGMENT_DELAY)

            # Publish this gate only after every prefix byte has been accepted
            # by sendall(). The client checks the downstream socket before it
            # opens the gate, then the origin sends the final one or two bytes.
            gate = PrefixGate("unknown")
            self.gates.put(gate)
            if not gate.release.wait(10.0):
                raise ProbeError("client did not release the origin final-byte gate")
            final = BODY_BYTE if gate.case == "exact" else BODY_BYTE * 2
            conn.sendall(final)
            if not gate.done.wait(10.0):
                raise ProbeError("client did not finish observing the final response")
            try:
                conn.shutdown(socket.SHUT_WR)
            except OSError:
                pass
        except (OSError, ProbeError) as exc:
            self.errors.put(f"origin connection: {exc}")
            if gate is not None:
                gate.release.set()
        finally:
            conn.close()

    def _accept_loop(self) -> None:
        while not self.stop.is_set():
            try:
                conn, _ = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                if self.stop.is_set():
                    return
                self.errors.put("origin listener failed")
                return
            worker = threading.Thread(target=self._serve, args=(conn,), daemon=True)
            self.threads.append(worker)
            worker.start()

    def next_gate(self, timeout: float) -> PrefixGate:
        try:
            gate = self.gates.get(timeout=timeout)
        except Empty as exc:
            raise ProbeError("origin did not reach the N-1 body-byte gate") from exc
        if not self.errors.empty():
            gate.release.set()
            gate.done.set()
            raise ProbeError(self.errors.get())
        return gate

    def close(self) -> None:
        self.stop.set()
        while True:
            try:
                gate = self.gates.get_nowait()
            except Empty:
                break
            gate.release.set()
            gate.done.set()
        self.listener.close()
        self.thread.join(timeout=2.0)
        for worker in self.threads:
            worker.join(timeout=2.0)
        alive = sum(worker.is_alive() for worker in self.threads)
        if alive:
            self.errors.put(f"{alive} origin worker thread(s) did not stop")

    def take_error(self) -> str | None:
        try:
            return self.errors.get_nowait()
        except Empty:
            return None


def check_no_published_bytes(sock: socket.socket, quiet_seconds: float) -> None:
    readable, _, _ = select.select([sock], [], [], quiet_seconds)
    if not readable:
        return
    try:
        first = sock.recv(1, socket.MSG_PEEK)
    except ConnectionResetError:
        raise ProbeError("proxy reset the client before the origin final-byte gate")
    if first == b"":
        raise ProbeError("proxy closed the client before the origin final-byte gate")
    raise ProbeError(f"proxy published {len(first)} byte(s) before body completion")


def read_to_terminal(sock: socket.socket, timeout: float) -> bytes:
    deadline = time.monotonic() + timeout
    chunks: list[bytes] = []
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ProbeError("client connection did not close after the final origin bytes")
        sock.settimeout(remaining)
        try:
            part = sock.recv(64 * 1024)
        except ConnectionResetError:
            return b"".join(chunks)
        except socket.timeout as exc:
            raise ProbeError("client connection timed out waiting for close") from exc
        if not part:
            return b"".join(chunks)
        chunks.append(part)


def read_exact_body_and_terminal(
    sock: socket.socket, gate: PrefixGate, timeout: float
) -> bytes:
    deadline = time.monotonic() + timeout
    wire = bytearray()
    body_start: int | None = None
    body_length: int | None = None
    while body_length is None or len(wire) - body_start < body_length:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ProbeError("timed out waiting for the exact Content-Length body")
        sock.settimeout(remaining)
        try:
            part = sock.recv(64 * 1024)
        except ConnectionResetError as exc:
            raise ProbeError("proxy reset before delivering the exact body") from exc
        except socket.timeout as exc:
            raise ProbeError("timed out waiting for the exact Content-Length body") from exc
        if not part:
            raise ProbeError("proxy closed before delivering the exact body")
        wire.extend(part)
        if body_start is None:
            marker = wire.find(b"\r\n\r\n")
            if marker >= 0:
                _, body_length = parse_response_headers(bytes(wire))
                body_start = marker + 4
        if body_length is not None and len(wire) - body_start > body_length:
            raise ProbeError("exact case delivered bytes beyond the declared body")

    # Let the origin close only after the declared payload has reached the
    # client; EOF then remains a separately observed terminal condition.
    gate.done.set()
    wire.extend(read_to_terminal(sock, max(0.001, deadline - time.monotonic())))
    return bytes(wire)


def parse_response_headers(wire: bytes) -> tuple[bytes, int]:
    marker = b"\r\n\r\n"
    end = wire.find(marker)
    if end < 0:
        raise ProbeError("response did not contain a complete header block")
    header = wire[:end]
    lines = header.split(b"\r\n")
    if not lines or not lines[0].startswith(b"HTTP/1.1 200 "):
        raise ProbeError(f"unexpected response status: {lines[0] if lines else b'<empty>'!r}")
    lengths = []
    for line in lines[1:]:
        name, sep, value = line.partition(b":")
        if sep and name.lower() == b"content-length":
            lengths.append(int(value.strip()))
    if lengths != [BODY_SIZE]:
        raise ProbeError(f"expected one Content-Length={BODY_SIZE}, got {lengths}")
    return wire[end + len(marker) :], BODY_SIZE


def run_case(
    proxy_port: int,
    origin: FragmentedOrigin,
    case: str,
    timeout: float,
    quiet_window: float,
) -> dict:
    client = socket.create_connection(("127.0.0.1", proxy_port), timeout=timeout)
    client.settimeout(timeout)
    request = (
        b"GET / HTTP/1.1\r\n"
        b"Host: adversarial.local\r\n"
        b"Connection: close\r\n\r\n"
    )
    started = time.monotonic()
    gate: PrefixGate | None = None
    prefix_quiet = False
    final_write_len = 1 if case == "exact" else 2
    try:
        client.sendall(request)
        gate = origin.next_gate(timeout)
        gate.case = case
        check_no_published_bytes(client, quiet_seconds=quiet_window)
        prefix_quiet = True
        gate.ready_at = time.monotonic()
        gate.release.set()

        if case == "exact":
            wire = read_exact_body_and_terminal(client, gate, timeout)
        else:
            wire = read_to_terminal(client, timeout)
            gate.done.set()
        elapsed = time.monotonic() - started
        if case == "exact":
            body, declared = parse_response_headers(wire)
            if len(body) != declared:
                raise ProbeError(f"exact case returned {len(body)} body bytes, expected {declared}")
            if body != BODY_BYTE * BODY_SIZE:
                raise ProbeError("exact case body bytes differ from the origin body")
            return {
                "case": case,
                "ok": True,
                "prefix_no_downstream": prefix_quiet,
                "final_write_len": final_write_len,
                "wire_bytes": len(wire),
                "body_bytes": len(body),
                "body_sha256": hashlib.sha256(body).hexdigest(),
                "elapsed_seconds": elapsed,
            }
        if wire:
            raise ProbeError(f"surplus case leaked {len(wire)} downstream byte(s)")
        return {
            "case": case,
            "ok": True,
            "prefix_no_downstream": prefix_quiet,
            "final_write_len": final_write_len,
            "wire_bytes": 0,
            "body_bytes": 0,
            "elapsed_seconds": elapsed,
        }
    finally:
        if gate is not None:
            gate.release.set()
            gate.done.set()
        client.close()


def wait_for_listener(process: subprocess.Popen[bytes], host: str, port: int, timeout: float) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise ProbeError(f"Rut exited during startup with status {process.returncode}")
        try:
            probe = socket.create_connection((host, port), timeout=0.2)
            probe.close()
            return
        except OSError:
            time.sleep(0.05)
    raise ProbeError(f"Rut did not listen on {host}:{port} within {timeout:g}s")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=("baseline", "candidate"), required=True)
    parser.add_argument("--front-port", type=int, default=18087)
    parser.add_argument("--origin-port", type=int, default=19087)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--ready-timeout", type=float, default=10.0)
    parser.add_argument("--quiet-window", type=float, default=0.15)
    parser.add_argument("--config", type=Path, default=SMOKE / "adversarial-proxy.rut")
    parser.add_argument("--label", default="")
    parser.add_argument("--json-out", type=Path)
    args = parser.parse_args()

    if args.front_port != 18087 or args.origin_port != 19087:
        raise ProbeError("staged config fixes ports at 18087 and 19087")

    binary = STAGE / args.variant / "rut"
    config = args.config.resolve()
    log_name = f"adversarial-{args.label}-{args.variant}.log" if args.label else f"adversarial-{args.variant}.log"
    log_path = STAGE / log_name
    if not binary.is_file():
        raise ProbeError(f"missing {args.variant} binary: {binary}")
    if not config.is_file():
        raise ProbeError(f"missing staged Rut config: {config}")

    origin = FragmentedOrigin("127.0.0.1", args.origin_port)
    proc: subprocess.Popen[bytes] | None = None
    samples: list[dict] = []
    started_at = datetime.now(timezone.utc).isoformat()
    binary_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
    error: str | None = None
    server_running_before_shutdown = False
    try:
        with log_path.open("wb") as server_log:
            proc = subprocess.Popen(
                [str(binary), str(config), "--shards", "1", "--no-pin", "--drain", "1", "--opt", "2"],
                stdout=server_log,
                stderr=subprocess.STDOUT,
            )
            wait_for_listener(proc, "127.0.0.1", args.front_port, args.ready_timeout)
            for index, case in enumerate(SEQUENCE, start=1):
                sample = run_case(args.front_port, origin, case, args.timeout, args.quiet_window)
                sample["index"] = index
                samples.append(sample)
                origin_error = origin.take_error()
                if origin_error is not None:
                    raise ProbeError(origin_error)
        server_running_before_shutdown = proc is not None and proc.poll() is None
        if not server_running_before_shutdown:
            raise ProbeError("Rut exited before controlled shutdown")
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        origin.close()
        if proc is not None and proc.poll() is None:
            proc.send_signal(signal.SIGTERM)
            try:
                proc.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2.0)

    origin_error = origin.take_error()
    if origin_error is not None and error is None:
        error = origin_error

    try:
        server_output = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        server_output = ""
    backend_confirmed = "Backend: io_uring" in server_output

    report = {
        "variant": args.variant,
        "binary": str(binary),
        "binary_sha256": binary_hash,
        "config": str(config),
        "label": args.label,
        "front_port": args.front_port,
        "origin_port": args.origin_port,
        "body_size": BODY_SIZE,
        "segment_size": BODY_CHUNK,
        "segment_delay_seconds": SEGMENT_DELAY,
        "sequence": list(SEQUENCE),
        "started_at": started_at,
        "server_log": str(log_path),
        "server_returncode": proc.returncode if proc is not None else None,
        "server_running_before_shutdown": server_running_before_shutdown,
        "backend": "io_uring" if backend_confirmed else "unconfirmed",
        "backend_confirmed": backend_confirmed,
        "samples": samples,
        "complete": len(samples) == len(SEQUENCE),
        "error": error,
        "valid": len(samples) == len(SEQUENCE) and all(sample["ok"] for sample in samples)
        and backend_confirmed and error is None and server_running_before_shutdown
        and proc is not None and proc.returncode == 0,
    }
    encoded = json.dumps(report, indent=2) + "\n"
    print(encoded, end="")
    if args.json_out:
        args.json_out.write_text(encoded, encoding="utf-8")
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
