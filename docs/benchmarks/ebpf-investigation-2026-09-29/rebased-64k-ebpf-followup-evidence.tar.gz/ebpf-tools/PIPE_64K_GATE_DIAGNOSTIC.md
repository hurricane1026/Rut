# Frozen 64 KiB pipe admission diagnostic (2026-09-29)

The rejected 64 KiB admission candidate is preserved as `rut-pipe-64k`, SHA256
`1b7d574ba70f6d7a88550552aaf6e7e9f226c6956fd7e877ef71eb5895804094`.
Its prior usable trace recorded zero `tcp_splice_read` and `splice_to_socket`
calls at HTTP 64 KiB proxy c1, even after the declared-body threshold was
lowered from 128 KiB to 64 KiB. The zero calls prove no splice entered the
kernel in that run; they do not identify the rejecting condition.

The candidate's `try_admit_response_body_pipe` disassembly has a shared reject
return at `0x423de6`. Ordered instruction addresses give the following gates:

| Probe | Address | Reaching it proves |
|---|---:|---|
| attempt | `0x423c40` | admission function entered |
| before_header_sent | `0x423ccc` | basic protocol/phase gates passed; about to check `bounded_header_sent` |
| header_sent | `0x423cd9` | `bounded_header_sent` passed |
| body_size | `0x423ce9` | declared body size passed the candidate's 64 KiB threshold |
| stable_state | `0x423cfc` | post-commit stable-state check passed |
| send_owner | `0x423dcc` | current send ownership allows allocation |
| allocation | `0x424160` | allocation function entered |
| splice_submit | `0x482470` | backend splice submission function entered |

`make_pipe_64k_gate_trace.py` checks the exact binary hash and instruction
boundaries before writing PID-filtered bpftrace probes. Run it against a live
candidate PID and invoke the SYS_ADMIN-capable bpftrace wrapper with
`-B line -f json` and the generated `.bt` file. A `GATE_TRACE_READY` marker,
successful tracer termination, valid exact-body load and zero errors are
required before interpreting counts. Compare each stage's count with the
preceding one: a large drop identifies where admission stops. An allocation
call can still fail, so `allocation` and `splice_submit` are separate probes.

The current frozen post-rebase production binary still has the 128 KiB
threshold; this diagnostic is **only** for explaining the older rejected
candidate. The current sandbox denies local sockets and the Docker API, so
these new probes have been hash/disassembly/syntax-checked but not attached.
No throughput benefit or current-binary admission result is claimed.
