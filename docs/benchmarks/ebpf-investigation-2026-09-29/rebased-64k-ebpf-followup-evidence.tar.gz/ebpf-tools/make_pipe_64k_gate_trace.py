#!/usr/bin/env python3
"""Generate address probes for the frozen, rejected 64 KiB pipe candidate."""

import argparse
import hashlib
import pathlib
import subprocess

BINARY = pathlib.Path('/tmp/rut-bounded-followup-20260928/ebpf-tools/rut-pipe-64k')
SHA256 = '1b7d574ba70f6d7a88550552aaf6e7e9f226c6956fd7e877ef71eb5895804094'
STAGES = {
    'attempt': 0x423c40,
    'before_header_sent': 0x423ccc,
    'header_sent': 0x423cd9,
    'body_size': 0x423ce9,
    'stable_state': 0x423cfc,
    'send_owner': 0x423dcc,
    'allocation': 0x424160,
    'splice_submit': 0x482470,
}

parser = argparse.ArgumentParser()
parser.add_argument('pid', type=int, help='PID of the candidate Rut worker')
parser.add_argument('output', type=pathlib.Path)
args = parser.parse_args()
if args.pid <= 0:
    parser.error('pid must be positive')
actual = hashlib.sha256(BINARY.read_bytes()).hexdigest()
if actual != SHA256:
    parser.error(f'binary hash changed: {actual}')
disassembly = subprocess.check_output(['objdump', '-d', str(BINARY)], text=True)
for name, address in STAGES.items():
    if f'  {address:x}:' not in disassembly:
        parser.error(f'{name}: 0x{address:x} is not an instruction start')

lines = ['BEGIN { printf("GATE_TRACE_READY\\n"); }']
for name, address in STAGES.items():
    lines.append(f'uprobe:{BINARY}:0x{address:x} /pid == {args.pid}/ '
                 f'{{ @gate_{name} = count(); }}')
args.output.write_text('\n'.join(lines) + '\n')
print(args.output)
