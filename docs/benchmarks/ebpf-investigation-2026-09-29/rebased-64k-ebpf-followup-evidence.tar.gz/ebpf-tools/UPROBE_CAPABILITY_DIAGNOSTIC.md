# Bounded hold-timer uprobe follow-up (2026-09-29)

The frozen post-rebase Rut binary is `rut-rebased-main-733`, SHA256
`f98ae490e57774dae6adb9ceb20db84e13804bdd57409e4dd8020e0230b22c2d`.
The original temporary bpftrace container had BPF, PERFMON, SYS_PTRACE,
SYS_RESOURCE and SYSLOG capabilities. It repeatedly failed to attach both
symbolic and address-based uprobes with `Unable to attach probe` before any
load; these failures are not zero event counts.

Adding only `SYS_ADMIN` to that container command allowed an address-based
uprobe to report `Attached 1 probe` under the earlier unrestricted execution
environment. No sysctl, host service, huge-page setting or runtime binary was
changed. `bpftrace-uprobe-sysadmin.py` is the minimal capability variant;
`trace_rebased_bounded_hold.py` now uses it and waits for a BPF `TRACE_READY`
marker after a 2-second warmup and before the measured load. It records
exact-body preflight, zero-error 8-second 64 KiB proxy keepalive load, timer
entry calls during that load, and calls per completed measured request. The
script creates a fresh output directory to avoid reusing stale trace results.

The current workspace-write execution sandbox blocks `sg docker` at its audit
interface, denies `/var/run/docker.sock`, and denies creating a local TCP
socket. The trace driver was syntax-checked but cannot be exercised or timed
inside that sandbox. No timer hit-rate or throughput inference is made.

When Docker/local sockets are available again, run:

```bash
sg docker -c 'flock /tmp/rut-clean-bench/bench.lock python3 /tmp/rut-bounded-followup-20260928/ebpf-tools/trace_rebased_bounded_hold.py'
```

Inspect `rebased-bounded-hold-trace-r3/result.json` and `trace.log`. A usable
result requires `trace_valid=true`, exact body, zero errors and the recorded
request count. A missing timer map after a successful trace is interpreted as
zero calls; an attachment failure is not. The uprobe records calls entering
the timer-arm function, not whether each call successfully armed a timer.
