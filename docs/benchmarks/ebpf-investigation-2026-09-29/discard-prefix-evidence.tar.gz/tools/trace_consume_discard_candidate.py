import http.client, json, pathlib, socket, subprocess, time, signal, sys
root=pathlib.Path('/tmp/rut-bounded-followup-20260928')
mode=sys.argv[1];out=root/sys.argv[2];out.mkdir()
ev=root/'rebased-main-733-unmet-r1'/f'http-65536-proxy-{mode}'
binary=root/'ebpf-tools/rut-discard-bounded-header-prefix'
image=pathlib.Path('/home/hurricane/private/code/Rut-s1/tests/pinned-nginx-image.txt').read_text().strip()
wrk='/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk'
def ready(port):
 for _ in range(100):
  try:
   with socket.create_connection(('127.0.0.1',port),.1):return
  except OSError:time.sleep(.05)
 raise RuntimeError('port not ready')
def metrics(raw):
 m=next(l for l in raw.splitlines() if l.startswith('METRICS ')).split()[1:]
 assert not any(map(int,m[5:])),m
 return int(m[0]),int(m[1])/1e6
origin=None;server=None;trace=None
try:
 origin=subprocess.check_output(['docker','run','-d','--rm','--network','host','--cpuset-cpus','3','--mount',f'type=bind,src={ev}/origin.conf,dst=/etc/nginx/nginx.conf,readonly','--mount',f'type=bind,src={ev}/payloads,dst=/benchmark-payloads,readonly',image,'nginx','-g','daemon off;'],text=True).strip()
 ready(9987)
 with (out/'server.log').open('w') as log:server=subprocess.Popen(['taskset','-c','2',str(binary),str(ev/'proxy.rut'),'--shards','1','--no-pin','--drain','1','--opt','2'],stdout=log,stderr=log)
 ready(8987)
 with socket.create_connection(('127.0.0.1',8987),timeout=3) as client:
  client.sendall(b'GET /proxy HTTP/1.1\r\nHost: client.example\r\n\r\n')
  r=http.client.HTTPResponse(client);r.begin();assert r.status==200 and r.read()==b'x'*65536
 lua=ev/f'proxy-{mode}-rut-r1-c1.lua'
 load=['taskset','-c','4,5',wrk,'-t1','-c1','-s',str(lua),'--timeout','2s','http://127.0.0.1:8987/proxy']
 warm=subprocess.check_output(load+['-d2s'],text=True);(out/'warmup.log').write_text(warm);metrics(warm)
 code=f'''BEGIN {{ printf("TRACE_READY\\n"); }}
uretprobe:{binary}:_ZN3rut21consume_upstream_sentERNS_14ConnectionBaseE /pid == {server.pid}/ {{ @calls = count(); @remaining = hist(retval); @bytes = sum(retval); }}'''
 (out/'trace.bt').write_text(code+'\n')
 with (out/'trace.log').open('w') as log:trace=subprocess.Popen(['python3',str(root/'ebpf-tools/bpftrace-uprobe-sysadmin.py'),'-B','line','-e',code],stdout=log,stderr=log)
 for _ in range(100):
  if trace.poll() is not None:raise RuntimeError('trace exited early: '+(out/'trace.log').read_text())
  if 'TRACE_READY' in (out/'trace.log').read_text():break
  time.sleep(.1)
 else:raise RuntimeError('trace not ready')
 raw=subprocess.check_output(load+['-d8s'],text=True);(out/'wrk.log').write_text(raw);n,sec=metrics(raw)
 (out/'result.json').write_text(json.dumps({'requests':n,'seconds':sec,'rps':n/sec,'exact_body':True,'zero_errors':True,'binary':str(binary),'server_pid':server.pid},indent=2)+'\n')
 print('load',n,sec,n/sec,flush=True)
finally:
 if trace and trace.poll() is None:trace.send_signal(signal.SIGINT);trace.wait(timeout=15)
 if (out/'result.json').exists():
  import re
  result=json.loads((out/'result.json').read_text())
  trace_text=(out/'trace.log').read_text()
  result['counts']={k:int(v) for k,v in re.findall(r'@(calls|bytes):\s*(\d+)',trace_text)}
  result['trace_ready']='TRACE_READY' in trace_text
  result['trace_exit_code']=trace.returncode if trace else None
  result['trace_valid']=result['trace_ready'] and result['trace_exit_code'] in (0,130)
  result['per_request']={k:v/result['requests'] for k,v in result['counts'].items()}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 if server and server.poll() is None:server.terminate();server.wait(timeout=10)
 if origin:subprocess.run(['docker','stop',origin],stdout=subprocess.DEVNULL)
