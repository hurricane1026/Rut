#!/usr/bin/env python3
"""Three-way diagnostic for the post-rebase 64 KiB proxy keepalive c1 case."""

import hashlib
import http.client
import json
import os
from pathlib import Path
import socket
import statistics
import subprocess
import time

root = Path('/tmp/rut-bounded-followup-20260928')
case = root/'rebased-main-733-unmet-r1/http-65536-proxy-keepalive'
out = root/'rebased-backend-64k-r1'
out.mkdir()
image = Path('/home/hurricane/private/code/Rut-s1/tests/pinned-nginx-image.txt').read_text().strip()
binary = root/'ebpf-tools/rut-rebased-main-733'
epoll_wrapper = root/'ebpf-tools/force_epoll'
wrk = '/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk'
lua = case/'proxy-keepalive-rut-r1-c1.lua'

def ready(port):
    for _ in range(200):
        try:
            with socket.create_connection(('127.0.0.1', port), 0.1): return
        except OSError: time.sleep(0.05)
    raise RuntimeError(f'port {port} not ready')

def metrics(raw):
    vals = next(line.split()[1:] for line in raw.splitlines() if line.startswith('METRICS '))
    assert not any(map(int, vals[5:])), vals
    return int(vals[0]), int(vals[1])/1e6

def preflight():
    conn = http.client.HTTPConnection('127.0.0.1', 8987, timeout=5)
    try:
        conn.request('GET', '/proxy', headers={'Host': 'client.example'})
        response = conn.getresponse()
        assert response.status == 200 and response.read() == b'x'*65536
    finally: conn.close()

def start_container(conf, cpu, user=False):
    args = ['docker','run','-d','--rm','--network','host','--cpuset-cpus',str(cpu)]
    if user:
        args += ['--user',f'{os.getuid()}:{os.getgid()}',
                 '--tmpfs',f'/var/cache/nginx:uid={os.getuid()},gid={os.getgid()},mode=0755']
    args += ['--mount',f'type=bind,src={case}/{conf},dst=/etc/nginx/nginx.conf,readonly',
             '--mount',f'type=bind,src={case}/payloads,dst=/benchmark-payloads,readonly',
             image,'nginx','-g','daemon off;']
    return subprocess.check_output(args,text=True).strip()

load = ['taskset','-c','4,5',wrk,'-t1','-c1','-s',str(lua),'--timeout','2s',
        'http://127.0.0.1:8987/proxy']
rows=[]
origin=None
try:
    origin=start_container('origin.conf',3);ready(9987)
    for iteration, order in enumerate((('nginx','uring','epoll'),
                                       ('epoll','uring','nginx'),
                                       ('uring','nginx','epoll')),1):
        for engine in order:
            dest=out/f'{iteration}-{engine}';dest.mkdir()
            server=None;container=None
            try:
                if engine=='nginx':
                    container=start_container('proxy-nginx.conf',2,True)
                else:
                    command=['taskset','-c','2']
                    if engine=='epoll': command.append(str(epoll_wrapper))
                    command += [str(binary),str(case/'proxy.rut'),'--shards','1',
                                '--no-pin','--drain','1','--opt','2']
                    with (dest/'server.log').open('w') as log:
                        server=subprocess.Popen(command,stdout=log,stderr=log)
                ready(8987);preflight()
                warm=subprocess.check_output(load+['-d2s'],text=True)
                (dest/'warmup.log').write_text(warm)
                metrics(warm)
                raw=subprocess.check_output(load+['-d5s'],text=True)
                (dest/'wrk.log').write_text(raw)
                requests, seconds=metrics(raw)
                if server:
                    backend=(dest/'server.log').read_text()
                    assert ('Backend: epoll' if engine=='epoll' else 'Backend: io_uring') in backend,backend
                row={'iteration':iteration,'engine':engine,'requests':requests,
                     'seconds':seconds,'rps':requests/seconds,'exact_body':True,
                     'zero_errors':True}
                rows.append(row);print(row,flush=True)
            finally:
                if server and server.poll() is None:
                    server.terminate();server.wait(timeout=10)
                if container: subprocess.run(['docker','stop',container],check=True,
                                              stdout=subprocess.DEVNULL)
    summary={'scenario':'HTTP 65536 proxy keepalive c1',
             'rut_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
             'epoll_wrapper_sha256':hashlib.sha256(epoll_wrapper.read_bytes()).hexdigest(),
             'nginx_image':image,'rows':rows,
             'median_rps':{engine:statistics.median(x['rps'] for x in rows if x['engine']==engine)
                           for engine in ('nginx','uring','epoll')}}
    summary['ratios']={engine:summary['median_rps'][engine]/summary['median_rps']['nginx']
                       for engine in ('uring','epoll')}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
finally:
    if origin: subprocess.run(['docker','stop',origin],check=True,stdout=subprocess.DEVNULL)
