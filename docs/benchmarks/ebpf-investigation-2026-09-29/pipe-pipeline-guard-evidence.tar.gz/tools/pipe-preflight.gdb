set pagination off
set confirm off
set print thread-events off
set $n = 0
break *0x47c7c7
commands
silent
if $n < 12
printf "PREFLIGHT profile=%u pipeline_stable=%u tls_ok=%u policy=%u bodypending=%u pendingpolicy=%u bodymode=%u remaining=%u buffered=%u recvlen=%u initiallen=%u depth=%u generation=%u method=%u route_method=%u\n", *(unsigned char*)($rsp+0x30), *(unsigned char*)($rsp+0x20), *(unsigned char*)($rsp+0x18), *(unsigned short*)($rbx+0xb40), *(unsigned char*)($rbx+0xb42), *(unsigned short*)($rbx+0xb46), *(unsigned char*)($rbx+0xc07), *(unsigned int*)($rbx+0xc08), *(unsigned char*)($rbx+0xb4e), *(unsigned int*)($rbx+0xd98), *(unsigned int*)($rbx+0xb34), *(unsigned short*)($rbx+0xb20), *(unsigned int*)($rbx+0xb24), *(unsigned char*)($rbx+0xccc), *(unsigned char*)($r13+0x84)
end
set $n = $n + 1
continue
end
run
