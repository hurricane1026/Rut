set pagination off
set confirm off
set print thread-events off
set $n = 0
break *0x420330
commands
silent
if $n < 20
printf "DEADLINE=%u\n", *(unsigned char*)($rsi+0x8bf)
printf "CLOSE seq=%u phase=%u declared=%u received=%u send=%u recv=%u direct=%u pipe=%p\n", $n, *(unsigned char*)($rsi+0x94c), *(unsigned int*)($rsi+0x95c), *(unsigned int*)($rsi+0x980), *(unsigned char*)($rsi+0xc35), *(unsigned char*)($rsi+0xc37), *(unsigned char*)($rsi+0xe3c), *(void**)($rsi+0xe30)
set $p = *(char**)($rsi+0xe30)
if $p != 0
printf "PIPE bytes=%u completed=%u disabled=%u fallback=%u stopping=%u input=%u output=%u inputready=%u outputready=%u\n", *(unsigned int*)($p+12), *(unsigned int*)($p+52), *(unsigned char*)($p+131), *(unsigned char*)($p+132), *(unsigned char*)($p+133), *(unsigned int*)($p+96), *(unsigned int*)($p+100), *(unsigned int*)($p+104), *(unsigned int*)($p+108)
end
bt 6
end
set $n = $n + 1
continue
end
run
