#define _GNU_SOURCE
#include <linux/io_uring.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
int main(void) {
 struct io_uring_params p={0};
 p.flags=IORING_SETUP_R_DISABLED|IORING_SETUP_SINGLE_ISSUER|IORING_SETUP_DEFER_TASKRUN|IORING_SETUP_COOP_TASKRUN|IORING_SETUP_TASKRUN_FLAG;
 int fd=syscall(__NR_io_uring_setup,8,&p);
 if(fd<0){perror("setup");return 1;}
 void *mem=aligned_alloc(4096,4096); if(!mem)return 2; memset(mem,0,4096);
 struct io_uring_buf_reg reg={0};reg.ring_addr=(unsigned long long)mem;reg.ring_entries=8;reg.bgid=3;
 int rc=syscall(__NR_io_uring_register,fd,IORING_REGISTER_PBUF_RING,&reg,1);
 printf("pbuf before enable: rc=%d errno=%d\n",rc,errno);
 int ok=(rc==0);
 rc=syscall(__NR_io_uring_register,fd,IORING_REGISTER_ENABLE_RINGS,NULL,0);
 printf("enable: rc=%d errno=%d\n",rc,errno);
 close(fd);free(mem);return ok&&rc==0?0:3;
}
