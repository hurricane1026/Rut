import http.client, json, os, pathlib, re, signal, socket, subprocess, time
root=pathlib.Path('/tmp/rut-bounded-followup-20260928')
out=root/'rebased-nginx-event-syscall-trace-r1';out.mkdir(exist_ok=True)
ev=root/'rebased-main-733-unmet-r1/http-65536-proxy-keepalive'
image=pathlib.Path('/home/hurricane/private/code/Rut-s1/tests/pinned-nginx-image.txt').read_text().strip()
wrk='/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk'
def ready(port):
 for _ in range(100):
  try:
   with socket.create_connection(('127.0.0.1',port),.1):return
  except OSError:time.sleep(.05)
 raise RuntimeError('port not ready')
def metrics(raw):
 m=next(l for l in raw.splitlines() if l.startswith('METRICS ')).split()[1:]
 assert not any(map(int,m[5:])),m
 return int(m[0]),int(m[1])/1e6
origin=server=trace=None
try:
 origin=subprocess.check_output(['docker','run','-d','--rm','--network','host','--cpuset-cpus','3','--mount',f'type=bind,src={ev}/origin.conf,dst=/etc/nginx/nginx.conf,readonly','--mount',f'type=bind,src={ev}/payloads,dst=/benchmark-payloads,readonly',image,'nginx','-g','daemon off;'],text=True).strip()
 ready(9987)
 server=subprocess.check_output(['docker','run','-d','--rm','--network','host','--cpuset-cpus','2','--user',f'{os.getuid()}:{os.getgid()}','--tmpfs',f'/var/cache/nginx:uid={os.getuid()},gid={os.getgid()},mode=0755','--mount',f'type=bind,src={ev}/proxy-nginx.conf,dst=/etc/nginx/nginx.conf,readonly','--mount',f'type=bind,src={ev}/payloads,dst=/benchmark-payloads,readonly',image,'nginx','-g','daemon off;'],text=True).strip()
 master=int(subprocess.check_output(['docker','inspect','-f','{{.State.Pid}}',server],text=True))
 for _ in range(100):
  children=pathlib.Path(f'/proc/{master}/task/{master}/children').read_text().split()
  if children:break
  time.sleep(.05)
 pid=int(children[0]);ready(8987)
 with socket.create_connection(('127.0.0.1',8987),timeout=3) as client:
  client.sendall(b'GET /proxy HTTP/1.1\r\nHost: client.example\r\n\r\n')
  r=http.client.HTTPResponse(client);r.begin();assert r.status==200 and r.read()==b'x'*65536
 lua=ev/'proxy-keepalive-rut-r1-c1.lua'
 load=['taskset','-c','4,5',wrk,'-t1','-c1','-s',str(lua),'--timeout','2s','http://127.0.0.1:8987/proxy']
 warm=subprocess.check_output(load+['-d2s'],text=True);(out/'warmup.log').write_text(warm);metrics(warm)
 names=['epoll_wait','epoll_pwait','epoll_pwait2','read','readv','recvfrom','recvmsg','write','writev','sendto','sendmsg','connect','socket','close']
 code='BEGIN { printf("TRACE_READY\\n"); }\n'+''.join(f'tracepoint:syscalls:sys_enter_{name} /pid == {pid}/ {{ @syscalls["{name}"] = count(); }}\n' for name in names)
 (out/'trace.bt').write_text(code)
 with (out/'trace.log').open('w') as log:trace=subprocess.Popen(['python3',str(root/'ebpf-tools/bpftrace-uprobe-sysadmin.py'),'-B','line','-e',code],stdout=log,stderr=log)
 for _ in range(100):
  if trace.poll() is not None:raise RuntimeError('trace failed: '+(out/'trace.log').read_text())
  if 'TRACE_READY' in (out/'trace.log').read_text():break
  time.sleep(.1)
 else:raise RuntimeError('trace not ready')
 raw=subprocess.check_output(load+['-d8s'],text=True);(out/'wrk.log').write_text(raw);n,sec=metrics(raw)
 (out/'result.json').write_text(json.dumps({'requests':n,'seconds':sec,'rps':n/sec,'exact_body':True,'zero_errors':True,'worker_pid':pid},indent=2)+'\n')
 print('load',n,sec,n/sec,flush=True)
finally:
 if trace and trace.poll() is None:trace.send_signal(signal.SIGINT);trace.wait(timeout=15)
 if (out/'result.json').exists():
  result=json.loads((out/'result.json').read_text());s=(out/'trace.log').read_text()
  result['syscalls']={k:int(v) for k,v in re.findall(r'@syscalls\[(\w+)\]:\s*(\d+)',s)}
  result['trace_ready']='TRACE_READY' in s;result['trace_exit_code']=trace.returncode if trace else None
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 if server:subprocess.run(['docker','stop',server],stdout=subprocess.DEVNULL)
 if origin:subprocess.run(['docker','stop',origin],stdout=subprocess.DEVNULL)
