import json, subprocess, sys
from pathlib import Path
root=Path('/tmp/rut-bounded-followup-20260928')
out=root/sys.argv[1]
out.mkdir()
base=['python3',str(root/'ebpf-tools/accept_buffered_more_guarded.py'),'--rut',str(root/'ebpf-tools/rut-rebased-main-733'),'--converter',str(root/'ebpf-tools/rut-nginx-convert-rebased-main-733'),'--wrk','/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk','--server-cpu','2','--origin-cpu','3','--client-cpus','4,5','--front-port','8987','--origin-port','9987','--keepalive-header','implicit','--first-engine','nginx','--proxy-profile','converter-strict','--profile','acceptance','--static-profile','native-body','--duration','5','--warmup','2','--repeats','3']
cases=[('http',16,'proxy-close',[1]),('http',16,'proxy-keepalive',[1]),('http',1024,'proxy-close',[1]),('http',1024,'proxy-keepalive',[1]),('http',65536,'proxy-close',[1]),('http',65536,'proxy-keepalive',[1]),('http',65536,'static-close',[1]),('http',1048576,'static-keepalive',[1,32,128]),('https',65536,'proxy-keepalive',[1]),('https',1048576,'proxy-close',[128])]
for transport,size,scenario,conc in cases:
 name=f'{transport}-{size}-{scenario}'
 dest=out/name
 cmd=base+['--output',str(dest),'--body-size',str(size),'--scenarios',scenario,'--concurrency',*map(str,conc)]
 if transport=='https':cmd+=['--tls-cert','/tmp/rut-clean-bench/tls2/cert.pem','--tls-key','/tmp/rut-clean-bench/tls2/key.pem']
 with (out/f'{name}.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=log).returncode
 try:
  status=json.loads((dest/'status.json').read_text());rows=json.loads((dest/'results.json').read_text())
 except (OSError,ValueError) as e:
  print(name,'invalid launch',type(e).__name__,rc,flush=True);sys.exit(1)
 print(name,'exit',rc,'status',status.get('complete'),status.get('valid'),'samples',len(rows),flush=True)
 if rc not in (0,1) or not status.get('complete') or not status.get('valid') or len(rows)!=6*len(conc):sys.exit(1)
