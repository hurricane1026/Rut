#!/usr/bin/env bash
set -euo pipefail
root=/tmp/rut-bounded-followup-20260928
lab="$root/ebpf-tools"
sg docker -c "flock /tmp/rut-clean-bench/bench.lock python3 $lab/matrix_guarded.py \
  --output $root/post-rebase-pinned-cache-full-r1 \
  --rut $lab/rut-pinned-parser-cache \
  --converter $lab/rut-nginx-convert-rebased-main-733 \
  --wrk /tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk \
  --server-cpu 2 --origin-cpu 3 --client-cpus 4,5 \
  --front-port 8987 --origin-port 9987 \
  --keepalive-header implicit --first-engine nginx \
  --profile acceptance --duration 5 --warmup 2 --repeats 3 \
  --static-profile native-body --proxy-profile converter-strict \
  --tls-cert /tmp/rut-clean-bench/tls2/cert.pem \
  --tls-key /tmp/rut-clean-bench/tls2/key.pem \
  --transports http https --body-sizes 16 1024 65536 1048576 \
  --scenarios static-close static-keepalive proxy-close proxy-keepalive \
  --concurrency 1 32 128"
