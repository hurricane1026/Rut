from pathlib import Path
import http.client, os, signal, socket, subprocess, time
root=Path('/tmp/rut-bounded-followup-20260928');out=root/'pipe-admission-debug-r2';out.mkdir();case=root/'combined-fin-full-acceptance/http-1048576-proxy-keepalive';repo=Path('/home/hurricane/private/code/Rut-s1');image=(repo/'tests/pinned-nginx-image.txt').read_text().strip();origin=None;proc=None;inferior=None
def ready(port):
 for _ in range(200):
  try:
   with socket.create_connection(('127.0.0.1',port),.1):return
  except OSError:time.sleep(.05)
 raise RuntimeError('not ready')
try:
 origin=subprocess.check_output(['docker','run','-d','--rm','--network','host','--cpuset-cpus','3','--mount',f'type=bind,src={case}/origin.conf,dst=/etc/nginx/nginx.conf,readonly','--mount',f'type=bind,src={case}/payloads,dst=/benchmark-payloads,readonly',image,'nginx','-g','daemon off;'],text=True).strip();ready(9987)
 with (out/'gdb.log').open('w') as f:proc=subprocess.Popen(['taskset','-c','2','gdb','--batch','-x',str(root/'ebpf-tools/pipe-admission.gdb'),'--args',str(root/'ebpf-tools/rut-pipe-input-r1'),str(case/'proxy.rut'),'--shards','1','--no-pin','--drain','1','--opt','2'],stdout=f,stderr=f,env=dict(os.environ,DEBUGINFOD_URLS=''))
 ready(8987);children=Path(f'/proc/{proc.pid}/task/{proc.pid}/children').read_text().split();assert len(children)==1,children;inferior=int(children[0])
 for i in range(3):
  c=http.client.HTTPConnection('127.0.0.1',8987,timeout=10);c.request('GET','/proxy',headers={'Host':'client.example','Connection':'close'});r=c.getresponse();assert r.status==200 and r.read()==b'x'*1048576;c.close()
 print('three exact-body requests passed',flush=True)
finally:
 if inferior:
  try:os.kill(inferior,signal.SIGTERM)
  except ProcessLookupError:pass
 if proc:
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=5)
 if origin:subprocess.run(['docker','stop',origin],check=True,stdout=subprocess.DEVNULL)
