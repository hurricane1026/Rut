set pagination off
set confirm off
set print thread-events off
break *0x423c40
commands
silent
printf "ADMIT enabled=%u pipe=%p tls=%u protocol=%u buffering=%u phase=%u class=%u header=%u declared=%u received=%u send=%u recv=%u direct=%u\n", *(unsigned char*)($rdi+0x6114), *(void**)($rsi+0xe30), *(unsigned char*)($rsi+0xa55), *(unsigned char*)($rsi+0xa57), *(unsigned char*)($rsi+0x8bb), *(unsigned char*)($rsi+0x94c), *(unsigned char*)($rsi+0x960), *(unsigned char*)($rsi+0x99c), *(unsigned int*)($rsi+0x95c), *(unsigned int*)($rsi+0x980), *(unsigned char*)($rsi+0xc35), *(unsigned char*)($rsi+0xc37), *(unsigned char*)($rsi+0xe3c)
continue
end
break *0x423cd9
commands
silent
printf "STABLE=%u\n", $al
continue
end
break *0x424150
commands
silent
printf "ALLOC capacity=%u memory_send=%u\n", $edx, $ecx
continue
end
break *0x48243d
commands
silent
printf "IOWQ_AFF_RESULT=%d\n", $eax
continue
end
run
