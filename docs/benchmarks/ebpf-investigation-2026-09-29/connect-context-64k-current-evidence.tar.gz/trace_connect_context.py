import sys
sys.path.insert(0, '/home/hurricane/private/code/Rut-s1/scripts/ebpf_trace')
import trace
original=trace.generate
trace.GROUPS+=('connect-context',)
def generate(*args):
 return original(*args)+'''
fentry:tcp_v4_connect /@targets[pid]/ {
 @connect_comm[comm]=count();
 @connect_tid[tid]=count();
 @connect_cpu[cpu]=count();
}
fexit:tcp_recvmsg /@targets[pid] && retval>0/ {
 if (args.sk->__sk_common.skc_num==8987) {
  @front_comm[comm]=count();
  @front_tid[tid]=count();
  @front_cpu[cpu]=count();
 }
}
fentry:tcp_sendmsg /@targets[pid]/ {
 if (bswap(args.sk->__sk_common.skc_dport)==9987) {
  @upsend_comm[comm]=count();
  @upsend_tid[tid]=count();
  @upsend_cpu[cpu]=count();
 }
}
'''
trace.generate=generate
sys.exit(trace.main())
