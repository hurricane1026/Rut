import json, subprocess, sys
from pathlib import Path
root=Path('/tmp/rut-bounded-followup-20260928')
out=root/sys.argv[1]
out.mkdir()
base=['python3',str(root/'ebpf-tools/accept_buffered_more_guarded.py'),'--rut',str(root/'ebpf-tools/rut-pipe-pipeline-guard'),'--converter',str(root/'rut-nginx-convert-baseline'),'--wrk','/tmp/pr-watchdog/hurricane1026_Rut_687/wrk-boringssl-src2/wrk','--server-cpu','2','--origin-cpu','3','--client-cpus','4,5','--front-port','8987','--origin-port','9987','--keepalive-header','implicit','--first-engine','nginx','--proxy-profile','converter-strict','--profile','acceptance','--static-profile','native-body','--body-size','65536','--concurrency','1','--duration','5','--warmup','2','--repeats','3']
for scenario in ['proxy-close','proxy-keepalive']:
 dest=out/scenario
 cmd=base+['--output',str(dest),'--scenarios',scenario]
 with (out/f'{scenario}.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=log).returncode
 status=json.loads((dest/'status.json').read_text())
 rows=json.loads((dest/'results.json').read_text())
 print(scenario,'exit',rc,'status',status.get('complete'),status.get('valid'),'samples',len(rows),flush=True)
 if rc not in (0,1) or not status.get('complete') or not status.get('valid') or len(rows)!=6:sys.exit(1)
