wrk.method="GET"
wrk.path="/proxy"
wrk.headers["Host"]="client.example"
wrk.headers["Connection"]=nil
done=function(s,l,r)
 print(string.format("METRICS %.0f %.0f %.0f %.0f %.0f %d %d %d %d %d",s.requests,s.duration,l:percentile(50),l:percentile(95),l:percentile(99),s.errors.connect,s.errors.read,s.errors.write,s.errors.status,s.errors.timeout))
end
