import json,pathlib,statistics
root=pathlib.Path(__file__).resolve().parent
out=[]
for p in sorted(root.glob('paths2-*/results.json')):
 rows=json.loads(p.read_text())
 for engine in ['rut','nginx']:
  for conn in ['close','keepalive']:
   for c in [1,128]:
    xs=[x for x in rows if x['engine']==engine and x['connection']==conn and x['concurrency']==c]
    if not xs:continue
    out.append(dict(group=p.parent.name,engine=engine,connection=conn,concurrency=c,n=len(xs),valid=all(x.get('valid',False) for x in xs),rps=statistics.median(x['rps'] for x in xs),p99_ms=statistics.median(x['p99_us'] for x in xs)/1000,cpu_pct=statistics.median(x['server_cpu_pct'] for x in xs),rss_bytes=statistics.median(x['server_rss_bytes'] for x in xs)))
(root/'paths-summary.json').write_text(json.dumps(out,indent=2))
for x in out:
 if x['engine']=='rut':print(x['group'],x['connection'],x['concurrency'],x['n'],x['valid'],round(x['rps']),round(x['p99_ms'],3),round(x['cpu_pct'],1))
