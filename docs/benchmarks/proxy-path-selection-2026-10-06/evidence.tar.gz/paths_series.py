import subprocess,json,os
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for profile in ['native-streaming','converter-strict','converter-bounded']:
 for variant in ['base','candidate']:
  name='paths2-'+profile+'-'+variant
  binary='/tmp/rut-paths-base-bin/rut' if variant=='base' else '/tmp/rut-paths-candidate-bin/rut'
  env=os.environ.copy();env['RUT_BENCH_RELAY_STATS']='1'
  rc=subprocess.run(['python3',str(root/'path_run.py'),name,profile,'rut' if variant=='base' else 'nginx','2','5','on',binary],env=env).returncode
  results.append(dict(profile=profile,variant=variant,group=name,rc=rc))
  (root/'paths-series.json').write_text(json.dumps(results,indent=2))
  if rc: raise SystemExit(rc)
