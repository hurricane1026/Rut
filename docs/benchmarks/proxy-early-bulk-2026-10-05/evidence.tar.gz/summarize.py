import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
lines=['group,c,baseline_rps,candidate_rps,rps_change_pct,cpu_per_request_change_pct,p99_change_pct,baseline_p99_us,candidate_p99_us']
for p in sorted(root.glob('ab-early-*/results.json')):
 if not (p.parent/'status.json').exists() or not json.loads((p.parent/'status.json').read_text()).get('complete'): continue
 rows=json.loads(p.read_text())
 for c in sorted(set(r['concurrency'] for r in rows)):
  parts={e:[r for r in rows if r['engine']==e and r['concurrency']==c] for e in ('nginx','rut')}
  assert all(r['valid'] and not any(r['errors'].values()) and not any(r['warmup_errors'].values()) for r in rows)
  med=lambda e,k:statistics.median(r[k] for r in parts[e])
  cpu=lambda e:statistics.median(r['server_cpu_pct']*10000/r['rps'] for r in parts[e])
  a,b=med('nginx','rps'),med('rut','rps');x,y=med('nginx','p99_us'),med('rut','p99_us')
  vals=[p.parent.name,c,a,b,(b/a-1)*100,(cpu('rut')/cpu('nginx')-1)*100,(y/x-1)*100,x,y]
  lines.append(','.join(map(str,vals)))
(root/'summary.csv').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
