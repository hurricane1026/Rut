import json,subprocess,sys,shlex,os
from pathlib import Path
root=Path(__file__).resolve().parent
variant,group,transport,first=sys.argv[1:5]
out=root/group;out.mkdir(exist_ok=False)
subprocess.run(['chcon','-t','container_file_t',str(out)],check=True)
argv=['python3',str(root/'compare_harness.py'),'--rut',str(root/(variant+'-bin')/'rut'),'--converter',str(root/(variant+'-bin')/'rut-nginx-convert'),'--wrk','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/wrk-boringssl-src2','--output',str(out),'--server-cpu','2','--origin-cpu','3','--client-cpus','4,5','--body-size',os.environ.get('BENCH_BODY_SIZE','1048576'),'--keepalive-header','implicit','--scenarios','proxy-close','--concurrency']
argv+=['1','128'] if transport=='http' else ['128']
argv+=['--warmup','2','--duration',os.environ.get('BENCH_DURATION','8'),'--repeats','3','--first-engine',first,'--front-port','8427','--origin-port','8527']
if transport=='tls':
 argv+=['--tls-cert','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/private-tls/localhost_cert.pem','--tls-key','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/private-tls/localhost_key.pem']
(root/(group+'-command.json')).write_text(json.dumps(argv,indent=2)+'\n')
env=os.environ.copy();env['TMPDIR']=str(root/'tmp')
with (root/(group+'.log')).open('w') as log:
 result=subprocess.run(['sg','docker','-c',shlex.join(argv)],stdout=log,stderr=subprocess.STDOUT,env=env)
print(group,result.returncode,flush=True)
sys.exit(result.returncode)
