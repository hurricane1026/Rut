import http.server,http.client,socket,subprocess,tempfile,threading,time,signal,json
from pathlib import Path
body=bytes(range(251))*4177+bytes(range(149));assert len(body)==1048576
records=[];counter=0
class Origin(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def setup(self):
  global counter
  super().setup();counter+=1;self.conn_id=counter
 def do_GET(self):
  records.append(self.conn_id);self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Origin);server.daemon_threads=True
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
s=socket.socket();s.bind(('127.0.0.1',0));front=s.getsockname()[1];s.close()
root=Path('/tmp/rut-window-study');program=root/'epoll-workspace-check.rut';program.write_text(f'listen 127.0.0.1:{front}\nupstream origin at "127.0.0.1:{server.server_port}"\nroute GET "/proxy" {{ return forward(origin) }}\n')
logpath=root/'epoll-workspace-http-check.log'
with logpath.open('w') as log:
 proc=subprocess.Popen(['/home/hurricane/private/code/Rut/build/src/rut',str(program),'--backend','epoll','--shards','1','--no-pin','--drain','1'],stdout=log,stderr=log)
 try:
  deadline=time.monotonic()+10
  while True:
   if proc.poll() is not None:raise AssertionError(logpath.read_text())
   try:s=socket.create_connection(('127.0.0.1',front),.1);s.close();break
   except OSError:
    if time.monotonic()>deadline:raise
    time.sleep(.05)
  for _ in range(3):
   client=http.client.HTTPConnection('127.0.0.1',front,timeout=5);client.request('GET','/proxy',headers={'Connection':'close'});response=client.getresponse();assert response.status==200 and response.read()==body;client.close()
  begin=len(records);client=http.client.HTTPConnection('127.0.0.1',front,timeout=5)
  for _ in range(10):
   client.request('GET','/proxy');response=client.getresponse();assert response.status==200 and response.read()==body
  client.close();assert len(set(records[begin:]))==1,records
  proc.send_signal(signal.SIGTERM);assert proc.wait(timeout=5)==0
  assert 'Backend: epoll\n' in logpath.read_text()
  result={'short_responses':3,'keepalive_responses':10,'body_size':len(body),'full_byte_comparison':True,'origin_connection_ids':records,'backend':'epoll','exit_code':proc.returncode};(root/'epoll-workspace-http-check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
 finally:
  if proc.poll() is None:proc.kill();proc.wait()
  server.shutdown();server.server_close()
