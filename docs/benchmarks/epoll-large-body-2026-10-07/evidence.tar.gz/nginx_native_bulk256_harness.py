# Reuse the repository harness with actual nginx and Rut frontends.
# Add process CPU accounting; do not substitute either frontend binary.
import contextlib, importlib.util, sys, json, os
from pathlib import Path
root=Path(__file__).resolve().parent
source=Path('/tmp/rut-window-study/src/scripts/nginx_benchmark/run.py')
sys.path.insert(0,str(source.parent))
spec=importlib.util.spec_from_file_location('rut_compare_harness',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.engine_order=lambda first,rep: ("nginx",)
frontend=module.Harness.frontend
active={}
original_configs={}
@contextlib.contextmanager
def measured_frontend(self,engine,work,label):
 config=self.out/(work+'-nginx.conf')
 original=original_configs.setdefault(str(config),config.read_text().replace('proxy_buffer_size 16k; proxy_busy_buffers_size 16k;','proxy_buffer_size 256k; proxy_buffers 8 256k; proxy_busy_buffers_size 256k;'))
 config.write_text(original)
 if label.startswith('proxy-close-'):
  config.write_text(original.replace('keepalive 4096; keepalive_timeout 60s; keepalive_requests 1000000000; ','keepalive 0; '))
 if engine=='nginx':(self.out/(label+'-actual-nginx.conf')).write_text(config.read_text())
 with frontend(self,engine,work,label) as pid:
  active.update(pid=pid,label=label,out=self.out)
  try: yield pid
  finally: active.clear()
module.Harness.frontend=measured_frontend
verify=module.Harness.verify_origin_reuse
def verify_origin(self,markers,fresh_downstream=False):
 verify(self,markers,fresh_downstream)
 if fresh_downstream and self.active_label.startswith('proxy-close-nginx-'):
  logs=self.command(['docker','logs',self.origin_container_id]).stdout
  records=module.origin_reuse_records(logs,markers)
  assert len({r[1] for r in records})==len(records) and all(r[2]==1 for r in records),records
module.Harness.verify_origin_reuse=verify_origin
usage=module.proc_usage
active={}
def profile_usage(pid):
 result=usage(pid)
 ids=[pid]+[int(x) for x in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 totals=dict(user_ticks=0,kernel_ticks=0,minor_faults=0,major_faults=0)
 for child in ids:
  f=Path(f'/proc/{child}/stat').read_text().rsplit(')',1)[1].split()
  for k,i in [('user_ticks',11),('kernel_ticks',12),('minor_faults',7),('major_faults',9)]:totals[k]+=int(f[i])
 host_cpu = {line.split()[0]: [int(v) for v in line.split()[1:]] for line in Path('/proc/stat').read_text().splitlines() if line.startswith('cpu')}
 row=dict(host_cpu=host_cpu,label=active['label'],role='server' if pid==active['pid'] else 'origin',pid=pid,clock_ticks=os.sysconf('SC_CLK_TCK'),**totals)
 with (active['out']/'cpu-split.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
 return result
module.proc_usage=profile_usage
sys.exit(module.main())
