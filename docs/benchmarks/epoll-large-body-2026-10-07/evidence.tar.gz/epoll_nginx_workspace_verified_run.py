import os,json,subprocess,shlex,threading,time
from pathlib import Path
root=Path('/tmp/rut-window-study'); binary=root/'bin-epoll-workspace/rut'
env=os.environ.copy()
for k in ['SEND_ZC','ZC_PUSH','BODY_ALIGNMENT','RECV_STEP_KIB','BODY_WINDOW_KIB','ALIGN_RECV','SMALL_TAIL','HEADER_CORK','PUBLISHED_CORK','RECYCLE_TWO','PHYSICAL_BLOCK_LIMIT','SMALL_BODY_CORK']:env.pop('RUT_STUDY_'+k,None)
for k in ['BODY_POOL_REUSE','SELECTIVE_VECTOR','DIRECT_BODY_SEND','DIRECT_CLOSE_ONLY','ADAPTIVE_CACHE','BODY_POOL_LOG']:env['RUT_STUDY_'+k]='1'
env['RUT_STUDY_BULK_CACHE_MIB']='16';env['TMPDIR']=str(root/'tmp')
for key in list(env):
 if key.startswith('RUT_STUDY_'):env.pop(key,None)
observations=[];stop=threading.Event();run=''
def monitor():
 while not stop.wait(1):
  active=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    comm=(p/'comm').read_text().strip();fields=(p/'stat').read_text().rsplit(')',1)[1].split()
    if comm in {'rustc','cargo','clang','clang++','gcc','g++','cc1','cc1plus'} and fields[0]!='Z':active.append({'pid':p.name,'comm':comm,'state':fields[0],'cpu':fields[36]})
   except (OSError,IndexError):pass
  observations.append({'time':time.time(),'run':run,'compilers':active})
t=threading.Thread(target=monitor);t.start()
try:
 for c,d in [(128,20)]:
  run=f'epoll-nginx-workspace-verified-20261007-c{c}';out=root/run;out.mkdir(exist_ok=False)
  subprocess.run(['chcon','-t','container_file_t',str(out)],check=True)
  args=['python3',str(root/'epoll_nginx_matched_harness.py'),'--rut',str(binary),'--converter','/home/hurricane/private/code/rut-perf-runtime-next-build/src/rut-nginx-convert','--wrk','/home/hurricane/private/code/rut-nginx-gap-next-bench-20261004/wrk-boringssl-src2','--output',str(out),'--server-cpu','2','--origin-cpu','3','--client-cpus','5,7','--body-size','1048576','--proxy-profile','native-streaming','--native-origin-reuse','on','--keepalive-header','implicit','--scenarios','proxy-close','proxy-keepalive','--concurrency',str(c),'--warmup','5','--duration',str(d),'--repeats','2','--first-engine','nginx','--front-port','8428','--origin-port','8528']
  (root/(run+'-command.json')).write_text(json.dumps({'args':args,'study_env':{k:v for k,v in env.items() if k.startswith('RUT_STUDY_')}},indent=2))
  with (root/(run+'.log')).open('w') as f:r=subprocess.run(['sg','docker','-c',shlex.join(args)],env=env,stdout=f,stderr=subprocess.STDOUT)
  print(run,r.returncode,flush=True)
  if r.returncode:break
finally:
 stop.set();t.join();(root/'epoll-nginx-workspace-verified-20261007-load-monitor.json').write_text(json.dumps(observations,indent=2))
